( function ( wp ) {
	var el = wp.element.createElement, __ = wp.i18n.__;
	var InspectorControls = wp.blockEditor.InspectorControls, PanelBody = wp.components.PanelBody, SelectControl = wp.components.SelectControl, RangeControl = wp.components.RangeControl, ToggleControl = wp.components.ToggleControl;
	var SSR = wp.serverSideRender;

	wp.blocks.updateCategory && wp.blocks.getCategories().some( function ( c ) { return c.slug === 'westons'; } ) || wp.blocks.setCategories( [ { slug: 'westons', title: 'Westons' } ].concat( wp.blocks.getCategories() ) );

	wp.blocks.registerBlockType( 'westons/product-grid', {
		edit: function ( props ) {
			var a = props.attributes;
			return el( wp.element.Fragment, {},
				el( InspectorControls, {}, el( PanelBody, { title: __( 'กริดการ์ดสินค้า', 'westons-site' ) },
					el( SelectControl, { label: 'กลุ่มสินค้า', value: a.group, options: [
						{ label: 'ผลิตภัณฑ์อาบน้ำและดูแลผิว', value: 'bath-body' },
						{ label: 'ผลิตภัณฑ์เฉพาะโอกาส', value: 'special-care' },
						{ label: 'ของใช้และชุดจัดรวม', value: 'amenity-kits' },
						{ label: 'รองเท้า', value: 'slippers' },
						{ label: 'บรรจุภัณฑ์และการเติม', value: 'packaging' },
						{ label: 'แบรนด์นำเข้า', value: 'imported-brands' },
						{ label: 'สินค้าพร้อมส่ง ไม่ติดโลโก้', value: 'ready-line' },
						{ label: 'ทุกกลุ่ม', value: '' } ], onChange: function ( v ) { props.setAttributes( { group: v } ); } } ),
					el( SelectControl, { label: 'เฉพาะที่ติ๊ก “ใช้ในหน้าเฉพาะ”', value: a.useIn, options: [ { label: 'ไม่กรอง', value: '' }, { label: 'โรงแรม', value: 'hotel' }, { label: 'โรงพยาบาล', value: 'hospital' } ], onChange: function ( v ) { props.setAttributes( { useIn: v } ); } } ),
					el( RangeControl, { label: 'จำนวนคอลัมน์ (คอมพิวเตอร์)', value: a.columns, min: 2, max: 6, onChange: function ( v ) { props.setAttributes( { columns: v } ); } } )
				) ),
				el( 'div', wp.blockEditor.useBlockProps(), el( SSR, { block: 'westons/product-grid', attributes: a } ) )
			);
		},
		save: function () { return null; }
	} );

	wp.blocks.registerBlockType( 'westons/contact-buttons', {
		edit: function ( props ) {
			return el( wp.element.Fragment, {},
				el( InspectorControls, {}, el( PanelBody, { title: 'รูปแบบ' },
					el( SelectControl, { label: 'รูปแบบ', value: props.attributes.variant, options: [ { label: 'รายการ (ไอคอน + ข้อความ)', value: 'list' }, { label: 'ปุ่มเรียงแถว', value: 'inline' }, { label: 'ข้อความสั้น (footer)', value: 'inline-text' }, { label: 'QR LINE (คอมพิวเตอร์)', value: 'qr' }, { label: 'แถบล่างมือถือ', value: 'bar' } ], onChange: function ( v ) { props.setAttributes( { variant: v } ); } } ) ) ),
				el( 'div', wp.blockEditor.useBlockProps(), el( SSR, { block: 'westons/contact-buttons', attributes: props.attributes } ) )
			);
		},
		save: function () { return null; }
	} );

	wp.blocks.registerBlockType( 'westons/jump-links', {
		edit: function () { return el( 'div', wp.blockEditor.useBlockProps(), el( 'p', { style: { padding: '8px 12px', border: '1px dashed #999', borderRadius: 8 } }, 'ลิงก์ข้ามหัวข้อ — สร้างอัตโนมัติจาก H2 ที่มี HTML anchor เมื่อแสดงผลจริง' ) ); },
		save: function () { return null; }
	} );

	wp.blocks.registerBlockType( 'westons/lang-switcher', {
		edit: function () { return el( 'span', wp.blockEditor.useBlockProps(), 'EN/ไทย (แสดงเมื่อมีคู่แปล)' ); },
		save: function () { return null; }
	} );

	wp.blocks.registerBlockType( 'westons/mega-nav', {
		edit: function ( props ) {
			var a = props.attributes, TextControl = wp.components.TextControl, TextareaControl = wp.components.TextareaControl;
			return el( wp.element.Fragment, {},
				el( InspectorControls, {}, el( PanelBody, { title: 'เมนูหลักแบบมีรูป' },
					el( SelectControl, { label: 'ภาษา', value: a.lang, options: [ { label: 'ไทย', value: 'th' }, { label: 'English', value: 'en' } ], onChange: function ( v ) { props.setAttributes( { lang: v } ); } } ),
					el( ToggleControl, { label: 'แสดงแถบติดต่อด้านบน (โทร/อีเมล/LINE จาก Settings)', checked: !! a.topbar, onChange: function ( v ) { props.setAttributes( { topbar: v } ); } } ),
					el( TextControl, { label: 'ข้อความปุ่มขวา', value: a.ctaLabel, onChange: function ( v ) { props.setAttributes( { ctaLabel: v } ); } } ),
					el( TextControl, { label: 'ลิงก์ปุ่มขวา', value: a.ctaUrl, onChange: function ( v ) { props.setAttributes( { ctaUrl: v } ); } } ),
					el( TextareaControl, { label: 'รายการเมนู (JSON) — ว่าง = ค่าเริ่มต้น', help: 'รูปแบบ: [{"label":"สินค้า","url":"/products/","children":"groups","images":["group:bath-body"]}] · children เป็น "groups" (กลุ่มสินค้าอัตโนมัติ) หรือรายการ [{"label","url"}] · images ใช้ "group:slug", "page:slug" หรือเลข attachment', rows: 10, value: a.items, onChange: function ( v ) { props.setAttributes( { items: v } ); } } )
				) ),
				el( 'div', wp.blockEditor.useBlockProps(), el( SSR, { block: 'westons/mega-nav', attributes: a } ) )
			);
		},
		save: function () { return null; }
	} );

	/* "แสดงบนเว็บ" สำหรับ Group */
	wp.hooks.addFilter( 'blocks.registerBlockType', 'westons/show-attr', function ( settings, name ) {
		if ( name !== 'core/group' ) { return settings; }
		settings.attributes = Object.assign( {}, settings.attributes, { wtShow: { type: 'boolean', default: true } } );
		return settings;
	} );
	wp.hooks.addFilter( 'editor.BlockEdit', 'westons/show-control', wp.compose.createHigherOrderComponent( function ( BlockEdit ) {
		return function ( props ) {
			if ( props.name !== 'core/group' ) { return el( BlockEdit, props ); }
			return el( wp.element.Fragment, {}, el( BlockEdit, props ),
				el( InspectorControls, {}, el( PanelBody, { title: 'Westons', initialOpen: true },
					el( ToggleControl, { label: 'แสดงบนเว็บ', help: props.attributes.wtShow === false ? 'ปิดอยู่: ส่วนนี้จะไม่ถูกส่งออกใน HTML เลย' : 'เปิดอยู่', checked: props.attributes.wtShow !== false, onChange: function ( v ) { props.setAttributes( { wtShow: v } ); } } ) ) ) );
		};
	}, 'wtShowControl' ) );
} )( window.wp );
