<?php
/**
 * Plugin Name: Westons Site
 * Description: โค้ดของโปรเจกต์เว็บ Westons — การ์ดสินค้า กลุ่มสินค้า ข้อมูลติดต่อกลาง บล็อกแสดงผล และ GA4 (แยกจากธีมเพื่อให้ข้อมูลอยู่ครบแม้เปลี่ยนธีม)
 * Version: 0.13.0
 * Author: Westons (Thai) Co., Ltd.
 * Text Domain: westons-site
 * Requires at least: 6.6
 * Requires PHP: 8.1
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'WT_SITE_VERSION', '0.13.0' );
define( 'WT_SITE_DIR', plugin_dir_path( __FILE__ ) );
define( 'WT_SITE_URL', plugin_dir_url( __FILE__ ) );

require_once WT_SITE_DIR . 'includes/post-types.php';
require_once WT_SITE_DIR . 'includes/settings.php';
require_once WT_SITE_DIR . 'includes/blocks.php';
require_once WT_SITE_DIR . 'includes/collections.php';
require_once WT_SITE_DIR . 'includes/frontend.php';
require_once WT_SITE_DIR . 'includes/seo.php';
require_once WT_SITE_DIR . 'includes/demo-content.php';

/* อัปเดตปลั๊กอินแล้ว URL ใหม่ (/products/<กลุ่ม>/) ต้องรีเฟรชกฎ URL หนึ่งครั้ง */
add_action( 'init', function () {
	if ( get_option( 'wt_rewrite_ver' ) !== WT_SITE_VERSION ) { flush_rewrite_rules( false ); update_option( 'wt_rewrite_ver', WT_SITE_VERSION ); }
}, 99 );

register_activation_hook( __FILE__, function () {
	wt_register_post_types();
	wt_insert_default_terms();
	flush_rewrite_rules();
} );
