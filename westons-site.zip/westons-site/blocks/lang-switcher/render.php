<?php
if ( ! is_singular() ) { return; }
$en = get_post_meta( get_queried_object_id(), 'wt_en_url', true );
$is_en = 'en' === get_post_meta( get_queried_object_id(), 'wt_lang', true );
if ( ! $en && ! $is_en ) { return; }
$target = $is_en ? get_post_meta( get_queried_object_id(), 'wt_th_url', true ) : $en;
if ( ! $target ) { return; }
echo '<a class="wt-lang-switch" href="' . esc_url( $target ) . '" hreflang="' . ( $is_en ? 'th' : 'en' ) . '" lang="' . ( $is_en ? 'th' : 'en' ) . '">' . ( $is_en ? 'ไทย' : 'EN' ) . '</a>';
