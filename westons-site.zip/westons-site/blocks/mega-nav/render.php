<?php
/**
 * เมนูหลักแบบมีรูป (mega menu) — server-rendered
 * items = JSON: [{label,url,children:"groups"|[{label,url}],images:["group:bath-body","page:hotels",123]}]
 * ว่าง = ใช้ค่าเริ่มต้นตามภาษา
 */
$lang  = ( $attributes['lang'] ?? 'th' ) === 'en' ? 'en' : 'th';
$en    = 'en' === $lang;
$items = json_decode( (string) ( $attributes['items'] ?? '' ), true );
if ( ! is_array( $items ) || empty( $items ) ) { $items = wt_mega_nav_defaults( $lang ); }
$contact = wt_contact();
$uid = 'wtnav' . wp_unique_id();

/* รูป: "group:slug" → รูปการ์ดสินค้าใบแรกของกลุ่ม, "page:slug" → featured image ของหน้า, ตัวเลข → attachment id */
/* v0.15: "media:eco/eco-x.jpg|คำบรรยาย|/url/" → รูปตัวอย่างที่นำเข้าไว้ (demo/images), "card:ชื่อการ์ด|คำบรรยาย|/url/" → รูปการ์ดสินค้าใบนั้น; คำบรรยายและลิงก์ใส่หรือไม่ก็ได้ */
$img = function ( $ref ) use ( $en ) {
	$id = 0; $link = ''; $cap = '';
	$parts = explode( '|', (string) $ref ); $ref = trim( $parts[0] ); $cap_o = isset( $parts[1] ) ? trim( $parts[1] ) : ''; $link_o = isset( $parts[2] ) ? trim( $parts[2] ) : '';
	if ( is_numeric( $ref ) ) { $id = (int) $ref; }
	elseif ( 0 === strpos( $ref, 'media:' ) ) { $seed = get_option( 'wt_seed_media', array() ); $id = (int) ( $seed[ substr( $ref, 6 ) ] ?? 0 ); }
	elseif ( 0 === strpos( $ref, 'card:' ) ) { $cq = get_posts( array( 'post_type' => 'wt_product_card', 'title' => substr( $ref, 5 ), 'posts_per_page' => 1, 'post_status' => 'publish' ) ); $c = $cq ? $cq[0] : null; if ( $c ) { $id = get_post_thumbnail_id( $c ); $cap = $en && get_post_meta( $c->ID, 'wt_title_en', true ) ? get_post_meta( $c->ID, 'wt_title_en', true ) : $c->post_title; $t = get_the_terms( $c, 'wt_product_group' ); $link = $t && ! is_wp_error( $t ) ? wt_collection_url( $t[0], $en ) : ''; } }
	elseif ( 0 === strpos( $ref, 'page:' ) ) {
		$p = get_page_by_path( substr( $ref, 5 ) );
		if ( $p ) { $id = get_post_thumbnail_id( $p ); $link = get_permalink( $p ); $cap = get_the_title( $p ); }
	} elseif ( 0 === strpos( $ref, 'group:' ) ) {
		$slug = substr( $ref, 6 );
		$q = get_posts( array( 'post_type' => 'wt_product_card', 'posts_per_page' => 1, 'orderby' => 'menu_order', 'order' => 'ASC', 'meta_key' => '_thumbnail_id',
			'tax_query' => array( array( 'taxonomy' => 'wt_product_group', 'field' => 'slug', 'terms' => $slug ) ) ) );
		if ( $q ) { $id = get_post_thumbnail_id( $q[0] ); $t = get_term_by( 'slug', $slug, 'wt_product_group' ); $cap = $t ? ( $en ? ( wt_group_name_en( $slug ) ?: $t->name ) : $t->name ) : ''; $link = $t ? wt_collection_url( $t, $en ) : ( $en ? '/en/products/' : '/products/' ); }
	}
	if ( $cap_o ) { $cap = $cap_o; } if ( $link_o ) { $link = $link_o; }
	if ( ! $id ) { return ''; }
	$html = wp_get_attachment_image( $id, 'medium_large', false, array( 'loading' => 'lazy' ) );
	if ( ! $html ) { return ''; }
	return '<a class="wt-mega-img" href="' . esc_url( $link ?: '#' ) . '">' . $html . ( $cap ? '<span>' . esc_html( $cap ) . '</span>' : '' ) . '</a>';
};

/* v0.16: รายการย่อยแต่ละข้อมีรูปของตัวเอง (child 'img' = media:/card:/group:; กลุ่มสินค้าใช้รูปการ์ดใบแรกของกลุ่ม) → hover แล้วรูปขวาเปลี่ยนตาม */
$children_html = function ( $children, &$sub_imgs ) use ( $en, $img ) {
	$out = ''; $i = 0; $sub_imgs = '';
	if ( 'groups' === $children ) {
		$terms = get_terms( array( 'taxonomy' => 'wt_product_group', 'hide_empty' => false ) );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$label = $en ? ( wt_group_name_en( $t->slug ) ?: $t->name ) : $t->name;
				$im = $img( 'group:' . $t->slug ); if ( $im ) { $sub_imgs .= str_replace( '<a class="wt-mega-img"', '<a class="wt-mega-img is-sub" data-i="' . $i . '"', $im ); }
				$out .= '<li data-i="' . $i . '"' . ( $im ? ' class="has-img"' : '' ) . '><a href="' . esc_url( wt_collection_url( $t, $en ) ) . '">' . esc_html( $label ) . '</a></li>'; $i++;
			}
		}
	} elseif ( is_array( $children ) ) {
		foreach ( $children as $c ) {
			if ( empty( $c['label'] ) ) { continue; }
			$im = ! empty( $c['img'] ) ? $img( $c['img'] ) : '';
			if ( $im ) { $sub_imgs .= str_replace( '<a class="wt-mega-img"', '<a class="wt-mega-img is-sub" data-i="' . $i . '"', $im ); }
			$out .= '<li data-i="' . $i . '"' . ( $im ? ' class="has-img"' : '' ) . '><a href="' . esc_url( $c['url'] ?? '#' ) . '">' . esc_html( $c['label'] ) . '</a></li>'; $i++;
		}
	}
	return $out;
};

ob_start(); ?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'wt-mega', 'id' => $uid ) ); ?>>
	<?php if ( ! empty( $attributes['topbar'] ) && ( $contact['phone'] || $contact['email'] || $contact['line_url'] ) ) : ?>
	<div class="wt-mega-topbar"><div class="wt-mega-inner">
		<?php if ( $contact['phone'] ) : ?><a href="tel:<?php echo esc_attr( $contact['phone'] ); ?>"><?php echo wt_icon( 'phone' ); ?><?php echo esc_html( $contact['phone_display'] ?: $contact['phone'] ); ?></a><?php endif; ?>
		<?php if ( $contact['email'] ) : ?><a href="mailto:<?php echo esc_attr( $contact['email'] ); ?>"><?php echo wt_icon( 'mail' ); ?><?php echo esc_html( $contact['email'] ); ?></a><?php endif; ?>
		<?php if ( $contact['line_url'] ) : ?><a href="<?php echo esc_url( $contact['line_url'] ); ?>" target="_blank" rel="noopener"><?php echo wt_icon( 'line' ); ?><?php echo esc_html( $en ? 'Chat on LINE' : $contact['line_label'] ); ?></a><?php endif; ?>
	</div></div>
	<?php endif; ?>
	<div class="wt-mega-bar"><div class="wt-mega-inner">
		<a class="wt-mega-logo" href="<?php echo esc_url( $en ? home_url( '/en/' ) : home_url( '/' ) ); ?>" rel="home">
			<?php if ( has_custom_logo() ) { echo get_custom_logo(); } else { ?><span class="wt-mega-wordmark"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span><span class="wt-mega-tagline">HOSPITALITY AMENITIES · SINCE 1990</span><?php } ?>
		</a>
		<button class="wt-mega-toggle" aria-expanded="false" aria-controls="<?php echo esc_attr( $uid ); ?>-nav" aria-label="<?php echo esc_attr( $en ? 'Menu' : 'เมนู' ); ?>"><span></span><span></span><span></span></button>
		<nav class="wt-mega-nav" id="<?php echo esc_attr( $uid ); ?>-nav" aria-label="<?php echo esc_attr( $en ? 'Main menu' : 'เมนูหลัก' ); ?>">
			<ul class="wt-mega-list">
			<?php foreach ( $items as $i => $it ) :
				$has = ! empty( $it['children'] ) || ! empty( $it['images'] );
				$pid = $uid . '-p' . $i; ?>
				<li class="wt-mega-item<?php echo $has ? ' has-panel' : ''; ?>">
					<a href="<?php echo esc_url( $it['url'] ?? '#' ); ?>"<?php echo $has ? ' aria-haspopup="true" aria-expanded="false" aria-controls="' . esc_attr( $pid ) . '"' : ''; ?>><?php echo esc_html( $it['label'] ?? '' ); ?><?php if ( $has ) : ?><svg class="wt-mega-caret" width="10" height="10" viewBox="0 0 10 10" aria-hidden="true"><path d="M1 3l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.4"/></svg><?php endif; ?></a>
					<?php if ( $has ) : ?>
					<div class="wt-mega-panel" id="<?php echo esc_attr( $pid ); ?>"><div class="wt-mega-inner">
						<?php $sub = ''; $links = $children_html( $it['children'] ?? array(), $sub ); if ( $links ) : ?><ul class="wt-mega-links"><?php echo $links; ?><?php if ( ! empty( $it['url'] ) && ! empty( $it['all'] ) ) : ?><li class="is-all"><a href="<?php echo esc_url( $it['url'] ); ?>"><?php echo esc_html( $it['all'] ); ?></a></li><?php endif; ?></ul><?php endif; ?>
						<?php $imgs = ''; foreach ( (array) ( $it['images'] ?? array() ) as $ref ) { $imgs .= str_replace( '<a class="wt-mega-img"', '<a class="wt-mega-img is-default"', $img( $ref ) ); } if ( $imgs || $sub ) : ?><div class="wt-mega-images"><?php echo $imgs . $sub; ?></div><?php endif; ?>
					</div></div>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
			</ul>
			<div class="wt-mega-actions">
				<?php echo render_block( array( 'blockName' => 'westons/lang-switcher', 'attrs' => array(), 'innerBlocks' => array(), 'innerHTML' => '', 'innerContent' => array() ) ); ?>
				<?php if ( ! empty( $attributes['ctaLabel'] ) ) : ?><a class="wt-mega-cta wp-element-button" href="<?php echo esc_url( $attributes['ctaUrl'] ?: '/contact/' ); ?>"><?php echo esc_html( $attributes['ctaLabel'] ); ?></a><?php endif; ?>
			</div>
		</nav>
	</div></div>
</div>
<script>(function(){var r=document.getElementById('<?php echo esc_js( $uid ); ?>');if(!r)return;var t=r.querySelector('.wt-mega-toggle'),n=r.querySelector('.wt-mega-nav');t.addEventListener('click',function(){var o=r.classList.toggle('is-open');t.setAttribute('aria-expanded',o?'true':'false');});r.querySelectorAll('.has-panel > a').forEach(function(a){a.addEventListener('click',function(e){if(window.matchMedia('(max-width: 1199px)').matches||a.getAttribute('aria-expanded')!=='true'&&!window.matchMedia('(hover: hover)').matches){e.preventDefault();var li=a.parentNode,o=li.classList.toggle('is-open');r.querySelectorAll('.has-panel.is-open').forEach(function(x){if(x!==li){x.classList.remove('is-open');x.firstElementChild.setAttribute('aria-expanded','false');}});a.setAttribute('aria-expanded',o?'true':'false');}});});document.addEventListener('keydown',function(e){if(e.key==='Escape'){r.querySelectorAll('.is-open').forEach(function(x){x.classList.remove('is-open');});}});
r.querySelectorAll('.wt-mega-panel').forEach(function(p){var imgs=p.querySelector('.wt-mega-images');if(!imgs)return;var subs=imgs.querySelectorAll('.is-sub');if(!subs.length)return;var dflt=imgs.querySelectorAll('.is-default');var set=function(i){imgs.classList.toggle('is-swapped',i!==null);subs.forEach(function(s){s.classList.toggle('is-on',s.getAttribute('data-i')===i);});};p.querySelectorAll('.wt-mega-links > li.has-img').forEach(function(li){li.addEventListener('mouseenter',function(){set(li.getAttribute('data-i'));});li.addEventListener('focusin',function(){set(li.getAttribute('data-i'));});});p.querySelector('.wt-mega-links').addEventListener('mouseleave',function(){set(null);});});
r.querySelectorAll('.wt-mega-item a').forEach(function(a){a.addEventListener('click',function(){var li=a.closest('.wt-mega-item');if(!li)return;li.classList.add('is-closed');li.classList.remove('is-open');r.classList.remove('is-open');t.setAttribute('aria-expanded','false');li.addEventListener('mouseleave',function(){li.classList.remove('is-closed');},{once:true});});});
var mark=function(){var path=location.pathname.replace(/\/$/,'')||'/';var h=(location.hash||'').replace(/^#/,'');r.querySelectorAll('.wt-mega-item').forEach(function(li){var a=li.querySelector(':scope > a');var u=(a.getAttribute('href')||'').replace(/^https?:\/\/[^/]+/,'').split('#')[0].replace(/\/$/,'')||'/';var cur=(u!=='/'&&u!=='/en'&&(path===u||path.indexOf(u+'/')===0))||(h&&h.indexOf(u.replace(/^\//,'').replace(/\//g,'-'))===0&&u!=='/');li.classList.toggle('is-current',!!cur);});};mark();window.addEventListener('hashchange',mark);
})();</script>
<?php echo ob_get_clean();
