<?php echo wt_render_product_grid( $attributes ); ?>
