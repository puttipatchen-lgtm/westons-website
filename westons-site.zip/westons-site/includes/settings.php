<?php
/**
 * ตั้งค่ากลาง: ข้อมูลติดต่อ Westons (LINE / โทร / อีเมล / ที่อยู่ / QR / GA4 / โหมดเว็บจริง)
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

function wt_contact_defaults() {
	return array(
		'line_url'      => '',
		'line_label'    => 'คุยทาง LINE',
		'phone'         => '',
		'phone_display' => '',
		'email'         => '',
		'address'       => '',
		'qr_image'      => '',
		'reply_time'    => '',
		'ga4_id'        => '',
		'og_image'      => '',
		'production'    => 0,
	);
}

function wt_contact( $key = null ) {
	$opt = wp_parse_args( (array) get_option( 'wt_contact', array() ), wt_contact_defaults() );
	return null === $key ? $opt : ( $opt[ $key ] ?? '' );
}

add_action( 'admin_menu', function () {
	add_options_page( __( 'ข้อมูลติดต่อ Westons', 'westons-site' ), __( 'ข้อมูลติดต่อ Westons', 'westons-site' ), 'edit_pages', 'wt-contact', 'wt_contact_settings_page' );
} );

add_action( 'admin_init', function () {
	register_setting( 'wt_contact_group', 'wt_contact', array(
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$out = wt_contact_defaults();
			$out['line_url']      = esc_url_raw( $in['line_url'] ?? '' );
			$out['line_label']    = sanitize_text_field( $in['line_label'] ?? 'คุยทาง LINE' );
			$out['phone']         = preg_replace( '/[^0-9+]/', '', $in['phone'] ?? '' );
			$out['phone_display'] = sanitize_text_field( $in['phone_display'] ?? '' );
			$out['email']         = sanitize_email( $in['email'] ?? '' );
			$out['address']       = sanitize_textarea_field( $in['address'] ?? '' );
			$out['qr_image']      = esc_url_raw( $in['qr_image'] ?? '' );
			$out['reply_time']    = sanitize_text_field( $in['reply_time'] ?? '' );
			$out['ga4_id']        = sanitize_text_field( $in['ga4_id'] ?? '' );
			$out['og_image']      = esc_url_raw( $in['og_image'] ?? '' );
			update_option( 'wt_default_og_image', $out['og_image'] );
			$out['production']    = empty( $in['production'] ) ? 0 : 1;
			return $out;
		},
	) );
} );

function wt_contact_settings_page() {
	$o = wt_contact();
	$field = function ( $key, $label, $type = 'text', $help = '' ) use ( $o ) {
		printf( '<tr><th scope="row"><label for="wt_%1$s">%2$s</label></th><td>', esc_attr( $key ), esc_html( $label ) );
		if ( 'textarea' === $type ) {
			printf( '<textarea id="wt_%1$s" name="wt_contact[%1$s]" rows="3" class="large-text">%2$s</textarea>', esc_attr( $key ), esc_textarea( $o[ $key ] ) );
		} elseif ( 'checkbox' === $type ) {
			printf( '<label><input type="checkbox" id="wt_%1$s" name="wt_contact[%1$s]" value="1" %2$s> %3$s</label>', esc_attr( $key ), checked( $o[ $key ], 1, false ), esc_html( $help ) );
			$help = '';
		} else {
			printf( '<input type="%3$s" id="wt_%1$s" name="wt_contact[%1$s]" value="%2$s" class="regular-text">', esc_attr( $key ), esc_attr( $o[ $key ] ), esc_attr( $type ) );
		}
		if ( $help ) { printf( '<p class="description">%s</p>', esc_html( $help ) ); }
		echo '</td></tr>';
	};
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'ข้อมูลติดต่อ Westons', 'westons-site' ); ?></h1>
		<p><?php esc_html_e( 'ค่าที่กรอกที่นี่ใช้กับปุ่ม LINE โทร อีเมล และแถบติดต่อทุกจุดบนเว็บ เปลี่ยนที่เดียวอัปเดตทั้งเว็บ', 'westons-site' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'wt_contact_group' ); ?>
			<table class="form-table" role="presentation">
				<?php
				$field( 'line_url', 'ลิงก์ LINE Official Account', 'url', 'เช่น https://lin.ee/xxxxx (ต้องยืนยัน D-06)' );
				$field( 'line_label', 'ข้อความปุ่ม LINE' );
				$field( 'phone', 'เบอร์โทร (สำหรับกดโทร)', 'text', 'ตัวเลขล้วน เช่น 024154826 (ต้องยืนยัน D-04)' );
				$field( 'phone_display', 'เบอร์โทร (แบบแสดงผล)', 'text', 'เช่น 02-415-4826' );
				$field( 'email', 'อีเมลรับเรื่อง', 'email', 'ต้องยืนยัน D-05' );
				$field( 'address', 'ที่อยู่บริษัท', 'textarea', 'ต้องยืนยัน D-03' );
				$field( 'qr_image', 'URL รูป QR LINE', 'url', 'แสดงเฉพาะบนคอมพิวเตอร์' );
				$field( 'reply_time', 'ระยะเวลาติดต่อกลับ', 'text', 'เช่น ภายใน 1 วันทำการ (ต้องยืนยัน C-12)' );
				$field( 'ga4_id', 'GA4 Measurement ID', 'text', 'เช่น G-XXXXXXX — ใส่เมื่อรู้ว่าใครถือบัญชี' );
				$field( 'og_image', 'URL รูปแชร์เริ่มต้น (OG image 1200×630)', 'url', 'ใช้เมื่อหน้านั้นไม่มีรูป' );
				$field( 'production', 'โหมดเว็บจริง', 'checkbox', 'เปิดเมื่อขึ้นเว็บจริง: ซ่อนป้าย “ต้องยืนยัน/ขาด” และการ์ดสินค้าสถานะ “รอยืนยัน” ทั้งหมด' );
				?>
			</table>
			<?php submit_button( __( 'บันทึก', 'westons-site' ) ); ?>
		</form>
	</div>
	<?php
}
