<?php
/**
 * การ์ดสินค้า (wt_product_card) + กลุ่มสินค้า (wt_product_group) + ช่องข้อมูล
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** สถานะเผยแพร่ของการ์ด */
function wt_product_statuses() {
	return array(
		'available' => __( 'มีจำหน่าย', 'westons-site' ),
		'codev'     => __( 'ร่วมพัฒนาได้', 'westons-site' ),
		'pending'   => __( 'รอยืนยัน (แสดงเฉพาะเว็บทดลอง)', 'westons-site' ),
		'hidden'    => __( 'ซ่อน', 'westons-site' ),
	);
}

/** กลุ่มสินค้าเริ่มต้น */
function wt_default_groups() {
	return array(
		'bath-body'       => __( 'ผลิตภัณฑ์อาบน้ำและดูแลผิว', 'westons-site' ),
		'special-care'    => __( 'ผลิตภัณฑ์เฉพาะโอกาส', 'westons-site' ),
		'amenity-kits'    => __( 'ของใช้และชุดจัดรวม', 'westons-site' ),
		'slippers'        => __( 'รองเท้าโรงแรมและโรงพยาบาล', 'westons-site' ),
		'packaging'       => __( 'บรรจุภัณฑ์และการเติม', 'westons-site' ),
		'imported-brands' => __( 'แบรนด์นำเข้า (Of the Islands, Margy\'s)', 'westons-site' ),
	);
}

function wt_register_post_types() {
	register_post_type( 'wt_product_card', array(
		'labels' => array(
			'name'               => __( 'การ์ดสินค้า', 'westons-site' ),
			'singular_name'      => __( 'การ์ดสินค้า', 'westons-site' ),
			'add_new'            => __( 'เพิ่มสินค้า', 'westons-site' ),
			'add_new_item'       => __( 'เพิ่มการ์ดสินค้าใหม่', 'westons-site' ),
			'edit_item'          => __( 'แก้ไขการ์ดสินค้า', 'westons-site' ),
			'all_items'          => __( 'การ์ดสินค้าทั้งหมด', 'westons-site' ),
			'featured_image'     => __( 'รูปสินค้า', 'westons-site' ),
			'set_featured_image' => __( 'เลือกรูปสินค้า', 'westons-site' ),
			'menu_name'          => __( 'การ์ดสินค้า', 'westons-site' ),
		),
		'public'             => false,
		'publicly_queryable' => false,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'show_in_rest'       => true,
		'has_archive'        => false,
		'rewrite'            => false,
		'menu_icon'          => 'dashicons-products',
		'menu_position'      => 21,
		'supports'           => array( 'title', 'thumbnail', 'excerpt', 'page-attributes', 'custom-fields' ),
		'taxonomies'         => array( 'wt_product_group' ),
	) );

	register_taxonomy( 'wt_product_group', 'wt_product_card', array(
		'labels' => array(
			'name'          => __( 'กลุ่มสินค้า', 'westons-site' ),
			'singular_name' => __( 'กลุ่มสินค้า', 'westons-site' ),
			'menu_name'     => __( 'กลุ่มสินค้า', 'westons-site' ),
		),
		'public'            => false,
		'show_ui'           => true,
		'show_in_rest'      => true,
		'show_admin_column' => true,
		'hierarchical'      => true,
		'rewrite'           => false,
	) );

	$meta = array(
		'wt_status'       => array( 'type' => 'string', 'default' => 'pending' ),
		'wt_adjustable'   => array( 'type' => 'string', 'default' => '' ),
		'wt_use_hotel'    => array( 'type' => 'boolean', 'default' => false ),
		'wt_use_hospital' => array( 'type' => 'boolean', 'default' => false ),
		'wt_note'         => array( 'type' => 'string', 'default' => '' ),
	);
	foreach ( $meta as $key => $args ) {
		register_post_meta( 'wt_product_card', $key, array_merge( $args, array(
			'single'        => true,
			'show_in_rest'  => true,
			'auth_callback' => function () { return current_user_can( 'edit_posts' ); },
		) ) );
	}
}
add_action( 'init', 'wt_register_post_types' );

function wt_insert_default_terms() {
	foreach ( wt_default_groups() as $slug => $name ) {
		if ( ! term_exists( $slug, 'wt_product_group' ) ) {
			wp_insert_term( $name, 'wt_product_group', array( 'slug' => $slug ) );
		}
	}
}

/* ---------- Meta box ให้ทีมกรอก ---------- */
add_action( 'add_meta_boxes', function () {
	add_meta_box( 'wt_card_fields', __( 'ข้อมูลการ์ดสินค้า', 'westons-site' ), 'wt_card_fields_box', 'wt_product_card', 'normal', 'high' );
} );

function wt_card_fields_box( $post ) {
	wp_nonce_field( 'wt_card_fields', 'wt_card_fields_nonce' );
	$status     = get_post_meta( $post->ID, 'wt_status', true ) ?: 'pending';
	$adjustable = get_post_meta( $post->ID, 'wt_adjustable', true );
	$hotel      = (bool) get_post_meta( $post->ID, 'wt_use_hotel', true );
	$hospital   = (bool) get_post_meta( $post->ID, 'wt_use_hospital', true );
	$note       = get_post_meta( $post->ID, 'wt_note', true );
	?>
	<style>.wt-mb p{margin:0 0 14px}.wt-mb label b{display:block;margin-bottom:4px}.wt-mb input[type=text]{width:100%}.wt-mb .desc{color:#666;font-size:12px}</style>
	<div class="wt-mb">
		<p><label><b><?php esc_html_e( 'สถานะเผยแพร่', 'westons-site' ); ?></b>
			<select name="wt_status">
				<?php foreach ( wt_product_statuses() as $k => $label ) : ?>
					<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $status, $k ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select></label>
			<span class="desc"><?php esc_html_e( '“ซ่อน” = ไม่แสดงทุกที่แม้กด Publish · “รอยืนยัน” = แสดงพร้อมป้ายเฉพาะเว็บทดลอง', 'westons-site' ); ?></span></p>
		<p><label><b><?php esc_html_e( 'ปรับได้ (ข้อความสั้น)', 'westons-site' ); ?></b>
			<input type="text" name="wt_adjustable" value="<?php echo esc_attr( $adjustable ); ?>" placeholder="กลิ่น · สี · ขนาด"></label></p>
		<p><b><?php esc_html_e( 'ใช้ในหน้าเฉพาะ', 'westons-site' ); ?></b><br>
			<label><input type="checkbox" name="wt_use_hotel" value="1" <?php checked( $hotel ); ?>> <?php esc_html_e( 'โรงแรม', 'westons-site' ); ?></label> &nbsp;
			<label><input type="checkbox" name="wt_use_hospital" value="1" <?php checked( $hospital ); ?>> <?php esc_html_e( 'โรงพยาบาล', 'westons-site' ); ?></label></p>
		<p><label><b><?php esc_html_e( 'บันทึกภายใน (ไม่แสดงบนเว็บ)', 'westons-site' ); ?></b>
			<input type="text" name="wt_note" value="<?php echo esc_attr( $note ); ?>" placeholder="เช่น รอยืนยัน P-06"></label></p>
		<p class="desc"><?php esc_html_e( 'คำอธิบายสั้นใส่ในช่อง “เกริ่นนำ (Excerpt)” ไม่เกิน 90 ตัวอักษร · ลำดับใส่ในช่อง “ลำดับ” (Order) · ห้ามใส่ราคา สูตร หรือต้นทุน', 'westons-site' ); ?></p>
	</div>
	<?php
}

add_action( 'save_post_wt_product_card', function ( $post_id ) {
	if ( ! isset( $_POST['wt_card_fields_nonce'] ) || ! wp_verify_nonce( $_POST['wt_card_fields_nonce'], 'wt_card_fields' ) ) { return; }
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
	if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }
	$status = isset( $_POST['wt_status'] ) && array_key_exists( $_POST['wt_status'], wt_product_statuses() ) ? $_POST['wt_status'] : 'pending';
	update_post_meta( $post_id, 'wt_status', $status );
	update_post_meta( $post_id, 'wt_adjustable', sanitize_text_field( $_POST['wt_adjustable'] ?? '' ) );
	update_post_meta( $post_id, 'wt_use_hotel', ! empty( $_POST['wt_use_hotel'] ) );
	update_post_meta( $post_id, 'wt_use_hospital', ! empty( $_POST['wt_use_hospital'] ) );
	update_post_meta( $post_id, 'wt_note', sanitize_text_field( $_POST['wt_note'] ?? '' ) );
} );

/* คอลัมน์สถานะในรายการ */
add_filter( 'manage_wt_product_card_posts_columns', function ( $cols ) {
	$new = array();
	foreach ( $cols as $k => $v ) {
		$new[ $k ] = $v;
		if ( 'title' === $k ) { $new['wt_status'] = __( 'สถานะ', 'westons-site' ); $new['wt_order'] = __( 'ลำดับ', 'westons-site' ); }
	}
	return $new;
} );
add_action( 'manage_wt_product_card_posts_custom_column', function ( $col, $post_id ) {
	if ( 'wt_status' === $col ) { echo esc_html( wt_product_statuses()[ get_post_meta( $post_id, 'wt_status', true ) ?: 'pending' ] ); }
	if ( 'wt_order' === $col ) { echo (int) get_post_field( 'menu_order', $post_id ); }
}, 10, 2 );
