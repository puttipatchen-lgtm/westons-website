<?php
/**
 * SEO technical: canonical, Open Graph, JSON-LD (Organization, WebSite, BreadcrumbList, FAQPage),
 * hreflang (เมื่อมีคู่หน้าภาษาอังกฤษ), robots ตามโหมดเว็บจริง
 * ใช้จนกว่าจะติดตั้ง Yoast/Rank Math — ถ้าติดตั้งแล้ว ปิดส่วนนี้ด้วย filter 'wt_seo_enabled'
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

function wt_seo_enabled() {
	$has_seo_plugin = defined( 'WPSEO_VERSION' ) || class_exists( 'RankMath' );
	return apply_filters( 'wt_seo_enabled', ! $has_seo_plugin );
}

/** ข้อมูลองค์กร (ค่าจากตั้งค่ากลาง; ยังไม่ยืนยัน = ไม่ใส่) */
function wt_org_schema() {
	$c = wt_contact();
	$org = array(
		'@type' => 'Organization',
		'@id'   => home_url( '/#organization' ),
		'name'  => 'Westons (Thai) Co., Ltd.',
		'alternateName' => 'Westons Thai',
		'url'   => home_url( '/' ),
		'description' => 'ผู้พัฒนาและผลิตผลิตภัณฑ์ดูแลตัวและชุด amenity สำหรับโรงแรม รีสอร์ต โรงพยาบาล และสปา ในประเทศไทย',
		'areaServed' => 'TH',
	);
	if ( $c['phone'] ) { $org['telephone'] = '+66' . ltrim( $c['phone'], '0' ); }
	if ( $c['email'] ) { $org['email'] = $c['email']; }
	if ( $c['address'] && $c['production'] ) { $org['address'] = array( '@type' => 'PostalAddress', 'streetAddress' => $c['address'], 'addressCountry' => 'TH' ); }
	if ( $c['line_url'] ) { $org['sameAs'] = array( $c['line_url'] ); }
	$logo = get_theme_mod( 'custom_logo' ) ? wp_get_attachment_image_url( get_theme_mod( 'custom_logo' ), 'full' ) : '';
	if ( $logo ) { $org['logo'] = $logo; }
	return $org;
}

add_action( 'wp_head', function () {
	if ( ! wt_seo_enabled() ) { return; }
	$c = wt_contact();

	// canonical: WordPress core ใส่ให้แล้ว (rel_canonical)

	// hreflang: คู่หน้าภาษาอังกฤษ (ใส่ URL ในช่อง "หน้าคู่ภาษาอังกฤษ" ของหน้า) — เปิดเฉพาะเมื่อมีคู่แปลจริง
	if ( is_singular() && ( $en_url = get_post_meta( get_queried_object_id(), 'wt_en_url', true ) ) ) {
		echo '<link rel="alternate" hreflang="th" href="' . esc_url( get_permalink() ) . '">' . "\n";
		echo '<link rel="alternate" hreflang="en" href="' . esc_url( $en_url ) . '">' . "\n";
		echo '<link rel="alternate" hreflang="x-default" href="' . esc_url( get_permalink() ) . '">' . "\n";
	} elseif ( is_singular() && wt_is_en() && ( $th_url = get_post_meta( get_queried_object_id(), 'wt_th_url', true ) ) ) {
		echo '<link rel="alternate" hreflang="en" href="' . esc_url( get_permalink() ) . '">' . "\n";
		echo '<link rel="alternate" hreflang="th" href="' . esc_url( $th_url ) . '">' . "\n";
		echo '<link rel="alternate" hreflang="x-default" href="' . esc_url( $th_url ) . '">' . "\n";
	}

	// Open Graph / Twitter
	$title = wp_get_document_title();
	$desc  = is_singular() ? get_post_meta( get_queried_object_id(), 'wt_meta_description', true ) : get_bloginfo( 'description' );
	$img   = '';
	if ( is_singular() && has_post_thumbnail() ) { $img = get_the_post_thumbnail_url( null, 'large' ); }
	if ( ! $img && is_singular() && preg_match( '/<img[^>]+src="([^"]+)"/', get_post()->post_content, $m ) ) { $img = $m[1]; }
	if ( ! $img && ( $og = get_option( 'wt_default_og_image' ) ) ) { $img = $og; }
	echo '<meta property="og:site_name" content="Westons Thai">' . "\n";
	$lang = wt_is_en() ? 'en' : 'th';
	echo '<meta property="og:locale" content="' . ( 'en' === $lang ? 'en_US' : 'th_TH' ) . '">' . "\n";
	echo '<meta property="og:type" content="website">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
	if ( $desc ) { echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n"; }
	echo '<meta property="og:url" content="' . esc_url( is_singular() ? get_permalink() : home_url( '/' ) ) . '">' . "\n";
	if ( $img ) { echo '<meta property="og:image" content="' . esc_url( $img ) . '">' . "\n"; }
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";

	// JSON-LD
	$graph = array( wt_org_schema() );
	$graph[] = array( '@type' => 'WebSite', '@id' => home_url( '/#website' ), 'url' => home_url( '/' ), 'name' => 'Westons Thai', 'inLanguage' => $lang, 'publisher' => array( '@id' => home_url( '/#organization' ) ) );
	if ( is_singular( 'page' ) && ! is_front_page() ) {
		$items = array( array( '@type' => 'ListItem', 'position' => 1, 'name' => 'en' === $lang ? 'Home' : 'หน้าแรก', 'item' => home_url( 'en' === $lang ? '/en/' : '/' ) ) );
		$post = get_post(); $pos = 2;
		if ( $post->post_parent ) {
			$items[] = array( '@type' => 'ListItem', 'position' => $pos++, 'name' => get_post_meta( $post->post_parent, 'wt_nav_title', true ) ?: get_the_title( $post->post_parent ), 'item' => get_permalink( $post->post_parent ) );
		}
		$items[] = array( '@type' => 'ListItem', 'position' => $pos, 'name' => get_post_meta( $post->ID, 'wt_nav_title', true ) ?: get_the_title( $post ), 'item' => get_permalink( $post ) );
		$graph[] = array( '@type' => 'BreadcrumbList', 'itemListElement' => $items );
		$graph[] = array( '@type' => 'WebPage', '@id' => get_permalink() . '#webpage', 'url' => get_permalink(), 'name' => $title, 'inLanguage' => $lang, 'isPartOf' => array( '@id' => home_url( '/#website' ) ), 'description' => $desc );
	}
	// FAQPage จากบล็อก Details (เฉพาะคำตอบที่ไม่มีป้าย ต้องยืนยัน/ขาด — กันคำตอบเปล่าขึ้น Google)
	if ( is_singular() && preg_match_all( '/<details[^>]*>\s*<summary>(.*?)<\/summary>(.*?)<\/details>/su', get_post()->post_content, $faqs, PREG_SET_ORDER ) ) {
		$qa = array();
		foreach ( $faqs as $f ) {
			$a = trim( wp_strip_all_tags( $f[2] ) );
			if ( ! $a || strpos( $f[2], 'wt-flag' ) !== false ) { continue; }
			$qa[] = array( '@type' => 'Question', 'name' => wp_strip_all_tags( $f[1] ), 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $a ) );
		}
		if ( $qa ) { $graph[] = array( '@type' => 'FAQPage', 'mainEntity' => $qa ); }
	}
	if ( is_singular( 'post' ) ) {
		$graph[] = array( '@type' => 'Article', 'headline' => get_the_title(), 'datePublished' => get_the_date( 'c' ), 'dateModified' => get_the_modified_date( 'c' ), 'inLanguage' => 'th', 'author' => array( '@id' => home_url( '/#organization' ) ), 'publisher' => array( '@id' => home_url( '/#organization' ) ), 'mainEntityOfPage' => get_permalink() );
	}
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
}, 3 );

/** ช่อง "หน้าคู่ภาษาอังกฤษ" ในกล่อง SEO ของหน้า */
add_action( 'save_post_page', function ( $post_id ) {
	if ( isset( $_POST['wt_seo_nonce'] ) && wp_verify_nonce( $_POST['wt_seo_nonce'], 'wt_seo' ) && current_user_can( 'edit_post', $post_id ) ) {
		update_post_meta( $post_id, 'wt_en_url', esc_url_raw( $_POST['wt_en_url'] ?? '' ) );
	}
}, 20 );

/** robots.txt: ชี้ sitemap และกันหลังบ้าน */
add_filter( 'robots_txt', function ( $output ) {
	return $output . "Sitemap: " . home_url( '/wp-sitemap.xml' ) . "\n";
} );

/** ตัด attachment pages / author / feed ที่ไม่มีเนื้อหาออกจากดัชนี */
add_action( 'template_redirect', function () {
	if ( is_attachment() || is_author() ) { wp_safe_redirect( home_url( '/' ), 301 ); exit; }
} );
add_filter( 'wp_sitemaps_add_provider', function ( $provider, $name ) { return 'users' === $name ? false : $provider; }, 10, 2 );

/* ---------- v0.14: /llms.txt สรุปเว็บให้ระบบ AI อ่านง่าย (เปิดเฉพาะโหมดเว็บจริง) ---------- */
add_action( 'template_redirect', function () {
	$path = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
	$base = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( $base && 0 === strpos( $path, $base ) ) { $path = trim( substr( $path, strlen( $base ) ), '/' ); }
	if ( 'llms.txt' !== $path ) { return; }
	if ( ! wt_contact( 'production' ) ) { status_header( 404 ); exit; }
	$pages = array( '' => 'หน้าแรก', 'ready-to-ship' => 'ของใช้ในโรงแรมและโรงพยาบาล พร้อมส่ง', 'products' => 'สินค้าทั้งหมด', 'hotels' => 'สำหรับโรงแรม สปา และโรงพยาบาล', 'product-development' => 'ร่วมพัฒนาผลิตภัณฑ์ / OEM', 'about' => 'เกี่ยวกับเรา', 'contact' => 'ติดต่อ ขอใบเสนอราคา' );
	$o  = "# Westons Thai\n\n> ผู้พัฒนาและผลิตแชมพู ครีมอาบน้ำ ครีมนวด โลชัน และชุด Amenity สำหรับโรงแรม รีสอร์ต สปา และโรงพยาบาลในประเทศไทย มีสินค้าพร้อมส่งไม่ติดโลโก้ และรับทำชุดติดโลโก้/พัฒนาสินค้าภายใต้แบรนด์ลูกค้า\n\n## หน้าหลัก\n";
	foreach ( $pages as $slug => $label ) {
		$pg = $slug ? get_page_by_path( $slug ) : get_post( get_option( 'page_on_front' ) );
		if ( ! $pg ) { continue; }
		$o .= '- [' . $label . '](' . get_permalink( $pg ) . ')' . ( get_post_meta( $pg->ID, 'wt_meta_description', true ) ? ': ' . get_post_meta( $pg->ID, 'wt_meta_description', true ) : '' ) . "\n";
	}
	$o .= "\n## หมวดสินค้า\n";
	foreach ( get_terms( array( 'taxonomy' => 'wt_product_group', 'hide_empty' => false ) ) as $t ) {
		$o .= '- [' . html_entity_decode( $t->name ) . '](' . wt_collection_url( $t ) . ')' . ( get_term_meta( $t->term_id, 'wt_intro', true ) ? ': ' . preg_replace( '/\s*\[[^\]]*\]/u', '', get_term_meta( $t->term_id, 'wt_intro', true ) ) : '' ) . "\n";
	}
	header( 'Content-Type: text/plain; charset=utf-8' );
	echo $o;
	exit;
}, 0 );
