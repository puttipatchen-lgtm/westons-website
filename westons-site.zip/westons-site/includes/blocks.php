<?php
/**
 * บล็อกแสดงผล (server-rendered): product-grid, contact-buttons, jump-links
 * + ตัวเลือก "แสดงบนเว็บ" ของ Group block
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'init', function () {
	register_block_type( WT_SITE_DIR . 'blocks/product-grid' );
	register_block_type( WT_SITE_DIR . 'blocks/contact-buttons' );
	register_block_type( WT_SITE_DIR . 'blocks/jump-links' );
	register_block_type( WT_SITE_DIR . 'blocks/lang-switcher' );
	register_block_type( WT_SITE_DIR . 'blocks/mega-nav' );
	register_block_type( 'westons/auto-part', array( 'api_version' => 3, 'attributes' => array( 'part' => array( 'type' => 'string', 'default' => 'header' ) ), 'render_callback' => 'wt_render_auto_part', 'supports' => array( 'html' => false, 'inserter' => false ) ) );
	register_block_type( 'westons/collection', array( 'api_version' => 3, 'title' => 'หน้าคอลเลกชัน (Westons)', 'category' => 'westons', 'icon' => 'images-alt2', 'description' => 'เนื้อหาหน้ากลุ่มสินค้า: hero เรื่องราว แกลเลอรี รูปแบบ/ขนาด สินค้า FAQ ติดต่อ — ใช้ในเทมเพลตกลุ่มสินค้าเท่านั้น', 'render_callback' => 'wt_render_collection', 'supports' => array( 'html' => false, 'align' => array( 'full' ) ) ) );
} );

/* ---------- mega-nav: ค่าเริ่มต้นของเมนู (แก้ได้ในบล็อกผ่านช่อง JSON) ---------- */
function wt_group_name_en( $slug ) {
	$m = array( 'bath-body' => 'Bath & skin care', 'special-care' => 'Special-occasion products', 'amenity-kits' => 'Amenities & kits', 'slippers' => 'Slippers', 'packaging' => 'Packaging & refill options', 'imported-brands' => 'Imported brands', 'ready-line' => 'Ready-to-ship, unbranded' );
	return $m[ $slug ] ?? '';
}
function wt_mega_nav_defaults( $lang = 'th' ) {
	if ( 'en' === $lang ) {
		return array(
			array( 'label' => 'Products', 'url' => '/en/products/', 'children' => 'groups', 'all' => 'View all products', 'images' => array( 'group:bath-body', 'group:amenity-kits' ) ),
			array( 'label' => 'Hotels', 'url' => '/en/hotels/', 'children' => array( array( 'label' => 'Scent & colour directions', 'url' => '/en/hotels/#scents' ), array( 'label' => 'Small items & amenity kits', 'url' => '/en/hotels/#small-items' ), array( 'label' => 'In-room placement, refill & dispensers', 'url' => '/en/hotels/#placement' ), array( 'label' => 'Imported brands: Of the Islands / Margy\'s', 'url' => '/en/products/imported-brands/' ), array( 'label' => 'Ready-to-ship, unbranded — for small properties', 'url' => '/en/products/ready-line/' ) ), 'images' => array( 'group:bath-body', 'group:imported-brands' ) ),
			array( 'label' => 'Hospitals', 'url' => '/en/hospitals/', 'children' => array( array( 'label' => 'Patient-room care sets', 'url' => '/en/hospitals/#kits' ), array( 'label' => 'Personal care, gentle formulas', 'url' => '/en/hospitals/#personal-care' ), array( 'label' => 'Slippers & hygiene items', 'url' => '/en/hospitals/#slippers' ) ), 'images' => array( 'group:amenity-kits', 'group:slippers' ) ),
			array( 'label' => 'Co-development', 'url' => '/en/product-development/', 'children' => array( array( 'label' => 'How we work together', 'url' => '/en/product-development/#process' ), array( 'label' => 'Briefs we can take: scent, colour, texture', 'url' => '/en/product-development/#briefs' ), array( 'label' => 'Before you start (OEM, minimums, lead time)', 'url' => '/en/product-development/#limits' ) ), 'images' => array( 'group:special-care' ) ),
			array( 'label' => 'About', 'url' => '/en/about/' ),
		);
	}
	return array(
		array( 'label' => 'สินค้า', 'url' => '/products/', 'children' => 'groups', 'all' => 'ดูสินค้าทั้งหมด', 'images' => array( 'group:bath-body', 'group:amenity-kits' ) ),
		array( 'label' => 'โรงแรม', 'url' => '/hotels/', 'children' => array( array( 'label' => 'แนวกลิ่นและสีสำหรับห้องพัก', 'url' => '/hotels/#scents' ), array( 'label' => 'ของชิ้นเล็กและชุด amenity', 'url' => '/hotels/#small-items' ), array( 'label' => 'การจัดวางในห้องพัก ขวดเติมและหัวจ่าย', 'url' => '/hotels/#placement' ), array( 'label' => 'แบรนด์นำเข้า Of the Islands / Margy\'s', 'url' => '/products/imported-brands/' ), array( 'label' => 'สินค้าพร้อมส่ง ไม่ติดโลโก้ สำหรับที่พักขนาดเล็ก', 'url' => '/products/ready-line/' ) ), 'images' => array( 'group:bath-body', 'group:imported-brands' ) ),
		array( 'label' => 'โรงพยาบาล', 'url' => '/hospitals/', 'children' => array( array( 'label' => 'ชุดของใช้สำหรับห้องผู้ป่วย', 'url' => '/hospitals/#kits' ), array( 'label' => 'ผลิตภัณฑ์ดูแลตัว สูตรอ่อนโยน', 'url' => '/hospitals/#personal-care' ), array( 'label' => 'รองเท้าและของใช้เพื่อสุขอนามัย', 'url' => '/hospitals/#slippers' ) ), 'images' => array( 'group:amenity-kits', 'group:slippers' ) ),
		array( 'label' => 'ร่วมพัฒนาผลิตภัณฑ์', 'url' => '/product-development/', 'children' => array( array( 'label' => 'ขั้นตอนการทำงานร่วมกัน', 'url' => '/product-development/#process' ), array( 'label' => 'โจทย์ที่เราคุยได้: กลิ่น สี เนื้อผลิตภัณฑ์', 'url' => '/product-development/#briefs' ), array( 'label' => 'สิ่งที่ควรรู้ก่อนเริ่ม (OEM ขั้นต่ำ ระยะเวลา)', 'url' => '/product-development/#limits' ) ), 'images' => array( 'group:special-care' ) ),
		array( 'label' => 'เกี่ยวกับเรา', 'url' => '/about/' ),
	);
}

/* ---------- ภาษาของหน้าปัจจุบัน ---------- */
function wt_is_en() {
	if ( function_exists( 'pll_current_language' ) ) { return 'en' === pll_current_language(); }
	if ( is_tax( 'wt_product_group' ) ) { return (bool) get_query_var( 'wt_en' ); }
	return is_singular() && 'en' === get_post_meta( get_queried_object_id(), 'wt_lang', true );
}
function wt_t( $th, $en ) { return wt_is_en() ? $en : $th; }

/* ---------- ไอคอน (inline SVG) ---------- */
function wt_icon( $name ) {
	$paths = array(
		'line'  => '<path d="M21 12a8 8 0 0 1-8 8H8l-5 3 1.5-4.5A8 8 0 1 1 21 12z"/>',
		'phone' => '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/>',
		'mail'  => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
		'pin'   => '<path d="M12 21s7-6.5 7-11.5A7 7 0 0 0 5 9.5C5 14.5 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
	);
	return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ( $paths[ $name ] ?? '' ) . '</svg>';
}

/* ---------- product-grid ---------- */
function wt_render_product_grid( $attrs ) {
	$group   = sanitize_key( $attrs['group'] ?? '' );
	$cols    = max( 2, min( 6, (int) ( $attrs['columns'] ?? 4 ) ) );
	$use     = sanitize_key( $attrs['useIn'] ?? '' ); // hotel|hospital|''
	$limit   = (int) ( $attrs['limit'] ?? 24 );
	$prod    = (bool) wt_contact( 'production' );

	$args = array(
		'post_type'      => 'wt_product_card',
		'post_status'    => 'publish',
		'posts_per_page' => $limit,
		'orderby'        => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
		'no_found_rows'  => true,
		'meta_query'     => array( array( 'key' => 'wt_status', 'value' => $prod ? array( 'hidden', 'pending' ) : array( 'hidden' ), 'compare' => 'NOT IN' ) ),
	);
	if ( $group ) { $args['tax_query'] = array( array( 'taxonomy' => 'wt_product_group', 'field' => 'slug', 'terms' => $group ) ); }
	if ( in_array( $use, array( 'hotel', 'hospital' ), true ) ) { $args['meta_query'][] = array( 'key' => 'wt_use_' . $use, 'value' => '1' ); }

	$q = new WP_Query( $args );
	if ( ! $q->have_posts() ) { return ''; } // กลุ่มว่าง → ไม่ส่ง HTML

	$statuses = wt_product_statuses();
	$no_link  = ! empty( $attrs['noLink'] ) || is_tax( 'wt_product_group' );
	$out = '<div class="wt-product-grid" style="--wt-cols:' . $cols . '">';
	foreach ( $q->posts as $p ) {
		$status = get_post_meta( $p->ID, 'wt_status', true ) ?: 'pending';
		$adj    = get_post_meta( $p->ID, 'wt_adjustable', true );
		$en      = wt_is_en();
		$title   = ( $en && get_post_meta( $p->ID, 'wt_title_en', true ) ) ? get_post_meta( $p->ID, 'wt_title_en', true ) : $p->post_title;
		$excerpt = ( $en && get_post_meta( $p->ID, 'wt_excerpt_en', true ) ) ? get_post_meta( $p->ID, 'wt_excerpt_en', true ) : $p->post_excerpt;
		$adj     = ( $en && get_post_meta( $p->ID, 'wt_adjustable_en', true ) ) ? get_post_meta( $p->ID, 'wt_adjustable_en', true ) : $adj;
		$img    = has_post_thumbnail( $p ) ? get_the_post_thumbnail( $p, 'medium_large', array( 'loading' => 'lazy' ) ) : '<div class="wt-placeholder">' . wt_t( 'ภาพ: ', 'Image: ' ) . esc_html( $title ) . '</div>';
		$full   = has_post_thumbnail( $p ) ? wp_get_attachment_image_url( get_post_thumbnail_id( $p ), 'large' ) : '';
		$terms  = get_the_terms( $p, 'wt_product_group' );
		$col    = ( ! $no_link && $terms && ! is_wp_error( $terms ) && function_exists( 'wt_collection_url' ) ) ? wt_collection_url( $terms[0], $en ) : '';
		$out .= '<article class="wt-product-card' . ( $full ? ' has-lightbox' : '' ) . '"' . ( $full ? ' data-full="' . esc_url( $full ) . '" data-title="' . esc_attr( $title ) . '" data-excerpt="' . esc_attr( $excerpt ) . '" data-adjust="' . esc_attr( $adj ? wt_t( 'ปรับได้: ', 'Adjustable: ' ) . $adj : '' ) . '" data-cta="' . esc_attr( wt_t( 'ขอตัวอย่าง / สอบถาม', 'Request a sample' ) ) . '" data-cta-url="' . esc_url( home_url( $en ? '/en/contact/' : '/contact/' ) ) . '"' . ( $col ? ' data-col="' . esc_url( $col ) . '" data-col-label="' . esc_attr( wt_t( 'ดูคอลเลกชัน', 'View collection' ) ) . '"' : '' ) . ' tabindex="0" role="button" aria-label="' . esc_attr( wt_t( 'ดูรูปใหญ่: ', 'View larger: ' ) . $title ) . '"' : '' ) . '>' . $img;
		$out .= '<h3 class="wt-product-title">' . esc_html( $title ) . '</h3>';
		if ( $excerpt ) { $out .= '<p class="wt-product-excerpt">' . esc_html( $excerpt ) . '</p>'; }
		if ( $adj ) { $out .= '<p class="wt-product-adjust">' . wt_t( 'ปรับได้: ', 'Adjustable: ' ) . esc_html( $adj ) . '</p>'; }
		if ( 'codev' === $status ) { $out .= '<span class="wt-product-status is-codev">' . wt_t( $statuses['codev'], 'Co-development' ) . '</span>'; }
		if ( 'pending' === $status ) { $out .= '<span class="wt-product-status is-pending">' . wt_t( 'รอยืนยัน', 'To be confirmed' ) . ( get_post_meta( $p->ID, 'wt_note', true ) ? ' · ' . esc_html( get_post_meta( $p->ID, 'wt_note', true ) ) : '' ) . '</span>'; }
		if ( $col ) { $out .= '<a class="wt-product-collink" href="' . esc_url( $col ) . '">' . wt_t( 'ดูคอลเลกชัน', 'View collection' ) . ' →</a>'; }
		$out .= '</article>';
	}
	wp_reset_postdata();
	return $out . '</div>';
}

/* ---------- contact-buttons ---------- */
function wt_render_contact_buttons( $attrs ) {
	$c = wt_contact();
	$v = $attrs['variant'] ?? 'list';
	$line  = $c['line_url'] ?: '#line-oa';
	$tel   = $c['phone'] ? 'tel:' . $c['phone'] : '#tel';
	$mail  = $c['email'] ? 'mailto:' . $c['email'] : '#email';
	$en = wt_is_en();
	$line_label = $en ? 'Chat on LINE' : $c['line_label'];
	$phone_txt = $c['phone_display'] ?: ( $c['phone'] ?: wt_t( '[เบอร์โทร ต้องยืนยัน D-04]', '[Phone — VERIFY D-04]' ) );
	$mail_txt  = $c['email'] ?: wt_t( '[อีเมล ต้องยืนยัน D-05]', '[Email — VERIFY D-05]' );
	$line_txt  = $c['line_url'] ? $line_label : $line_label . wt_t( ' [LINE OA ขาด D-06]', ' [LINE OA — MISSING D-06]' );
	$contact_url = home_url( $en ? '/en/contact/' : '/contact/' );

	if ( 'bar' === $v ) {
		return '<div class="wt-sticky-bar"><a class="is-line" href="' . esc_url( $line ) . '" data-wt-event="line_click">' . wt_icon( 'line' ) . esc_html( $line_label ) . '</a><a class="is-brief" href="' . esc_url( $contact_url ) . '">' . wt_t( 'เล่าโจทย์', 'Get in touch' ) . '</a></div>';
	}
	if ( 'inline' === $v ) {
		return '<div class="wt-contact-inline"><a class="wp-block-button__link wp-element-button is-style-outline" href="' . esc_url( $line ) . '" data-wt-event="line_click">' . esc_html( $line_label ) . '</a><a class="wp-block-button__link wp-element-button is-style-outline" href="' . esc_url( $tel ) . '" data-wt-event="phone_click">' . wt_t( 'โทร ', 'Call ' ) . esc_html( $phone_txt ) . '</a></div>';
	}
	if ( 'inline-text' === $v ) {
		return '<p class="has-small-font-size"><a href="' . esc_url( $tel ) . '" data-wt-event="phone_click">' . esc_html( $phone_txt ) . '</a> · <a href="' . esc_url( $mail ) . '" data-wt-event="email_click">' . esc_html( $mail_txt ) . '</a></p>';
	}
	if ( 'qr' === $v ) {
		$img = $c['qr_image'] ? '<img src="' . esc_url( $c['qr_image'] ) . '" alt="QR LINE Official Account Westons" width="96" height="96">' : '<div class="wt-placeholder" style="min-height:96px;width:96px;font-size:11px">QR LINE</div>';
		return '<div class="wt-desktop-only" style="gap:1rem;align-items:center;padding:1rem 1.25rem;border-radius:12px;background:var(--wp--preset--color--base)">' . $img . '<span class="has-small-font-size wt-muted">' . wt_t( 'สแกนเพื่อคุยทาง LINE<br>(แสดงเฉพาะคอมพิวเตอร์)', 'Scan to chat on LINE<br>(desktop only)' ) . '</span></div>';
	}
	// list
	$out  = '<ul class="wt-contact-list">';
	$out .= '<li><span class="wt-ico">' . wt_icon( 'line' ) . '</span><a href="' . esc_url( $line ) . '" data-wt-event="line_click">' . esc_html( $line_txt ) . '</a></li>';
	$out .= '<li><span class="wt-ico">' . wt_icon( 'phone' ) . '</span><a href="' . esc_url( $tel ) . '" data-wt-event="phone_click">' . wt_t( 'โทร ', 'Call ' ) . esc_html( $phone_txt ) . '</a></li>';
	$out .= '<li><span class="wt-ico">' . wt_icon( 'mail' ) . '</span><a href="' . esc_url( $mail ) . '" data-wt-event="email_click">' . esc_html( $mail_txt ) . '</a></li>';
	if ( $c['address'] ) { $out .= '<li><span class="wt-ico">' . wt_icon( 'pin' ) . '</span><span>' . esc_html( $c['address'] ) . '</span></li>'; }
	return $out . '</ul>';
}

/* ---------- jump-links: อ่าน H2 ที่มี id จากเนื้อหาหน้าปัจจุบัน ---------- */
function wt_render_jump_links( $attrs ) {
	$post = get_post();
	if ( ! $post ) { return ''; }
	if ( ! preg_match_all( '/<h2[^>]*\sid="([^"]+)"[^>]*>(.*?)<\/h2>/su', $post->post_content, $m, PREG_SET_ORDER ) ) { return ''; }
	$links = '';
	foreach ( $m as $h ) {
		$label = trim( wp_strip_all_tags( preg_replace( '/<span class="wt-flag">.*?<\/span>/su', '', $h[2] ) ) );
		if ( ! $label ) { continue; }
		$short = $attrs['short'] ?? array();
		$label = $short[ $h[1] ] ?? $label;
		$links .= '<a href="#' . esc_attr( $h[1] ) . '">' . esc_html( $label ) . '</a>';
	}
	if ( ! $links ) { return ''; }
	return '<nav class="wt-jump-links" aria-label="' . wt_t( 'ไปที่หัวข้อ', 'Jump to section' ) . '"><div class="wt-jump-desktop">' . $links . '</div><details class="wt-jump-mobile"><summary>' . wt_t( 'ไปที่หัวข้อ ▾', 'Jump to section ▾' ) . '</summary>' . $links . '</details></nav>';
}

/* ---------- "แสดงบนเว็บ" สำหรับ Group: ปิดแล้วไม่ออก HTML ---------- */
add_filter( 'render_block_core/group', function ( $content, $block ) {
	if ( isset( $block['attrs']['wtShow'] ) && false === $block['attrs']['wtShow'] ) { return ''; }
	return $content;
}, 10, 2 );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_script( 'wt-editor', WT_SITE_URL . 'assets/editor.js', array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-hooks', 'wp-compose', 'wp-server-side-render', 'wp-i18n' ), '0.1.0', true );
} );
