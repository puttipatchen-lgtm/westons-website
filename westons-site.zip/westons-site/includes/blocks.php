<?php
/**
 * บล็อกแสดงผล (server-rendered): product-grid, contact-buttons, jump-links
 * + ตัวเลือก "แสดงบนเว็บ" ของ Group block
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'init', function () {
	register_block_type( WT_SITE_DIR . 'blocks/product-grid' );
	register_block_type( WT_SITE_DIR . 'blocks/contact-buttons' );
	register_block_type( WT_SITE_DIR . 'blocks/jump-links' );
} );

/* ---------- ไอคอน (inline SVG) ---------- */
function wt_icon( $name ) {
	$paths = array(
		'line'  => '<path d="M21 12a8 8 0 0 1-8 8H8l-5 3 1.5-4.5A8 8 0 1 1 21 12z"/>',
		'phone' => '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/>',
		'mail'  => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
		'pin'   => '<path d="M12 21s7-6.5 7-11.5A7 7 0 0 0 5 9.5C5 14.5 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
	);
	return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ( $paths[ $name ] ?? '' ) . '</svg>';
}

/* ---------- product-grid ---------- */
function wt_render_product_grid( $attrs ) {
	$group   = sanitize_key( $attrs['group'] ?? '' );
	$cols    = max( 2, min( 6, (int) ( $attrs['columns'] ?? 4 ) ) );
	$use     = sanitize_key( $attrs['useIn'] ?? '' ); // hotel|hospital|''
	$limit   = (int) ( $attrs['limit'] ?? 24 );
	$prod    = (bool) wt_contact( 'production' );

	$args = array(
		'post_type'      => 'wt_product_card',
		'post_status'    => 'publish',
		'posts_per_page' => $limit,
		'orderby'        => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
		'no_found_rows'  => true,
		'meta_query'     => array( array( 'key' => 'wt_status', 'value' => $prod ? array( 'hidden', 'pending' ) : array( 'hidden' ), 'compare' => 'NOT IN' ) ),
	);
	if ( $group ) { $args['tax_query'] = array( array( 'taxonomy' => 'wt_product_group', 'field' => 'slug', 'terms' => $group ) ); }
	if ( in_array( $use, array( 'hotel', 'hospital' ), true ) ) { $args['meta_query'][] = array( 'key' => 'wt_use_' . $use, 'value' => '1' ); }

	$q = new WP_Query( $args );
	if ( ! $q->have_posts() ) { return ''; } // กลุ่มว่าง → ไม่ส่ง HTML

	$statuses = wt_product_statuses();
	$out = '<div class="wt-product-grid" style="--wt-cols:' . $cols . '">';
	foreach ( $q->posts as $p ) {
		$status = get_post_meta( $p->ID, 'wt_status', true ) ?: 'pending';
		$adj    = get_post_meta( $p->ID, 'wt_adjustable', true );
		$img    = has_post_thumbnail( $p ) ? get_the_post_thumbnail( $p, 'medium_large', array( 'loading' => 'lazy' ) ) : '<div class="wt-placeholder">ภาพ: ' . esc_html( $p->post_title ) . '</div>';
		$out .= '<article class="wt-product-card">' . $img;
		$out .= '<h3 class="wt-product-title">' . esc_html( $p->post_title ) . '</h3>';
		if ( $p->post_excerpt ) { $out .= '<p class="wt-product-excerpt">' . esc_html( $p->post_excerpt ) . '</p>'; }
		if ( $adj ) { $out .= '<p class="wt-product-adjust">ปรับได้: ' . esc_html( $adj ) . '</p>'; }
		if ( 'codev' === $status ) { $out .= '<span class="wt-product-status is-codev">' . esc_html( $statuses['codev'] ) . '</span>'; }
		if ( 'pending' === $status ) { $out .= '<span class="wt-product-status is-pending">รอยืนยัน' . ( get_post_meta( $p->ID, 'wt_note', true ) ? ' · ' . esc_html( get_post_meta( $p->ID, 'wt_note', true ) ) : '' ) . '</span>'; }
		$out .= '</article>';
	}
	wp_reset_postdata();
	return $out . '</div>';
}

/* ---------- contact-buttons ---------- */
function wt_render_contact_buttons( $attrs ) {
	$c = wt_contact();
	$v = $attrs['variant'] ?? 'list';
	$line  = $c['line_url'] ?: '#line-oa';
	$tel   = $c['phone'] ? 'tel:' . $c['phone'] : '#tel';
	$mail  = $c['email'] ? 'mailto:' . $c['email'] : '#email';
	$phone_txt = $c['phone_display'] ?: ( $c['phone'] ?: '[เบอร์โทร ต้องยืนยัน D-04]' );
	$mail_txt  = $c['email'] ?: '[อีเมล ต้องยืนยัน D-05]';
	$line_txt  = $c['line_url'] ? $c['line_label'] : $c['line_label'] . ' [LINE OA ขาด D-06]';

	if ( 'bar' === $v ) {
		return '<div class="wt-sticky-bar"><a class="is-line" href="' . esc_url( $line ) . '" data-wt-event="line_click">' . wt_icon( 'line' ) . esc_html( $c['line_label'] ) . '</a><a class="is-brief" href="' . esc_url( home_url( '/contact/' ) ) . '">เล่าโจทย์</a></div>';
	}
	if ( 'inline' === $v ) {
		return '<div class="wt-contact-inline"><a class="wp-block-button__link wp-element-button is-style-outline" href="' . esc_url( $line ) . '" data-wt-event="line_click">' . esc_html( $c['line_label'] ) . '</a><a class="wp-block-button__link wp-element-button is-style-outline" href="' . esc_url( $tel ) . '" data-wt-event="phone_click">โทร ' . esc_html( $phone_txt ) . '</a></div>';
	}
	if ( 'inline-text' === $v ) {
		return '<p class="has-small-font-size"><a href="' . esc_url( $tel ) . '" data-wt-event="phone_click">' . esc_html( $phone_txt ) . '</a> · <a href="' . esc_url( $mail ) . '" data-wt-event="email_click">' . esc_html( $mail_txt ) . '</a></p>';
	}
	if ( 'qr' === $v ) {
		$img = $c['qr_image'] ? '<img src="' . esc_url( $c['qr_image'] ) . '" alt="QR LINE Official Account Westons" width="96" height="96">' : '<div class="wt-placeholder" style="min-height:96px;width:96px;font-size:11px">QR LINE</div>';
		return '<div class="wt-desktop-only" style="gap:1rem;align-items:center;padding:1rem 1.25rem;border-radius:12px;background:var(--wp--preset--color--base)">' . $img . '<span class="has-small-font-size wt-muted">สแกนเพื่อคุยทาง LINE<br>(แสดงเฉพาะคอมพิวเตอร์)</span></div>';
	}
	// list
	$out  = '<ul class="wt-contact-list">';
	$out .= '<li><span class="wt-ico">' . wt_icon( 'line' ) . '</span><a href="' . esc_url( $line ) . '" data-wt-event="line_click">' . esc_html( $line_txt ) . '</a></li>';
	$out .= '<li><span class="wt-ico">' . wt_icon( 'phone' ) . '</span><a href="' . esc_url( $tel ) . '" data-wt-event="phone_click">โทร ' . esc_html( $phone_txt ) . '</a></li>';
	$out .= '<li><span class="wt-ico">' . wt_icon( 'mail' ) . '</span><a href="' . esc_url( $mail ) . '" data-wt-event="email_click">' . esc_html( $mail_txt ) . '</a></li>';
	if ( $c['address'] ) { $out .= '<li><span class="wt-ico">' . wt_icon( 'pin' ) . '</span><span>' . esc_html( $c['address'] ) . '</span></li>'; }
	return $out . '</ul>';
}

/* ---------- jump-links: อ่าน H2 ที่มี id จากเนื้อหาหน้าปัจจุบัน ---------- */
function wt_render_jump_links( $attrs ) {
	$post = get_post();
	if ( ! $post ) { return ''; }
	if ( ! preg_match_all( '/<h2[^>]*\sid="([^"]+)"[^>]*>(.*?)<\/h2>/su', $post->post_content, $m, PREG_SET_ORDER ) ) { return ''; }
	$links = '';
	foreach ( $m as $h ) {
		$label = trim( wp_strip_all_tags( preg_replace( '/<span class="wt-flag">.*?<\/span>/su', '', $h[2] ) ) );
		if ( ! $label ) { continue; }
		$short = $attrs['short'] ?? array();
		$label = $short[ $h[1] ] ?? $label;
		$links .= '<a href="#' . esc_attr( $h[1] ) . '">' . esc_html( $label ) . '</a>';
	}
	if ( ! $links ) { return ''; }
	return '<nav class="wt-jump-links" aria-label="ไปที่หัวข้อ"><div class="wt-jump-desktop">' . $links . '</div><details class="wt-jump-mobile"><summary>ไปที่หัวข้อ ▾</summary>' . $links . '</details></nav>';
}

/* ---------- "แสดงบนเว็บ" สำหรับ Group: ปิดแล้วไม่ออก HTML ---------- */
add_filter( 'render_block_core/group', function ( $content, $block ) {
	if ( isset( $block['attrs']['wtShow'] ) && false === $block['attrs']['wtShow'] ) { return ''; }
	return $content;
}, 10, 2 );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_script( 'wt-editor', WT_SITE_URL . 'assets/editor.js', array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-hooks', 'wp-compose', 'wp-server-side-render', 'wp-i18n' ), '0.1.0', true );
} );
