<?php
/**
 * หน้าเว็บ: body class โหมดเว็บจริง, GA4 events, noindex บนเว็บทดลอง, ตัดการ์ดออกจาก sitemap
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_filter( 'body_class', function ( $classes ) {
	if ( wt_contact( 'production' ) ) { $classes[] = 'wt-production'; }
	if ( wt_contact( 'motion' ) && ( is_front_page() || is_page( 'en' ) ) ) { $classes[] = 'wt-motion'; }
	return $classes;
} );

/** เว็บทดลอง: noindex เสมอจนกว่าจะเปิดโหมดเว็บจริง */
add_action( 'wp_head', function () {
	if ( ! wt_contact( 'production' ) ) { echo '<meta name="robots" content="noindex, nofollow">' . "\n"; }
}, 1 );

/** GA4: gtag + click events (line_click, phone_click, email_click, generate_lead, catalog_request) */
add_action( 'wp_head', function () {
	$id = wt_contact( 'ga4_id' );
	if ( ! $id ) { return; }
	printf( '<script async src="https://www.googletagmanager.com/gtag/js?id=%1$s"></script><script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag("js",new Date());gtag("config","%1$s");</script>' . "\n", esc_attr( $id ) );
}, 20 );

add_action( 'wp_footer', function () {
	?>
	<script>
	document.addEventListener('click',function(e){var a=e.target.closest('[data-wt-event]');if(a&&window.gtag){gtag('event',a.getAttribute('data-wt-event'),{link_url:a.href||''});}});
	document.addEventListener('submit',function(e){if(e.target.classList.contains('wt-form')&&window.gtag){gtag('event','generate_lead');}});
	</script>
	<?php
} );

/** ตัดการ์ดสินค้าและกลุ่มสินค้าออกจาก sitemap ของ WordPress */
add_filter( 'wp_sitemaps_post_types', function ( $types ) { unset( $types['wt_product_card'] ); return $types; } );
add_filter( 'wp_sitemaps_taxonomies', function ( $tax ) { unset( $tax['wt_product_group'] ); return $tax; } );

/** ฟอร์มตัวอย่าง: ยังไม่ส่งจริง (รอปลั๊กอินฟอร์ม + SMTP) — แสดงข้อความหลังกดส่ง */
add_action( 'template_redirect', function () {
	if ( isset( $_GET['wt-sent'] ) ) {
		add_filter( 'the_content', function ( $c ) {
			if ( wt_is_en() ) { return '<div class="wt-card is-tinted" style="margin-bottom:1.5rem"><p><strong>Thank you for telling us.</strong> We\'ll get back to you via the channel you gave <span class="wt-flag">reply time — MISSING C-12</span>. For a faster reply, message us on LINE.</p><p class="has-small-font-size wt-muted">(Staging: this form does not send yet.)</p></div>' . $c; }
			return '<div class="wt-card is-tinted" style="margin-bottom:1.5rem"><p><strong>ขอบคุณที่เล่าให้เราฟัง</strong> ทีมของเราจะติดต่อกลับทางช่องทางที่คุณให้ไว้ <span class="wt-flag">ระยะเวลา ขาด C-12</span> ถ้าต้องการคุยเร็วกว่านั้น ทัก LINE ได้เลย</p><p class="has-small-font-size wt-muted">(เว็บทดลอง: ฟอร์มนี้ยังไม่ส่งข้อมูลจริง จะเชื่อมปลั๊กอินฟอร์ม + อีเมลบริษัทตอนขึ้น staging)</p></div>' . $c;
		} );
	}
} );

/* ---------- SEO title / description ต่อหน้า (ใช้จนกว่าจะติดตั้ง Yoast/Rank Math) ---------- */
add_filter( 'pre_get_document_title', function ( $title ) {
	if ( is_singular() && ( $t = get_post_meta( get_queried_object_id(), 'wt_seo_title', true ) ) ) { return $t; }
	return $title;
} );
add_action( 'wp_head', function () {
	if ( is_singular() && ( $d = get_post_meta( get_queried_object_id(), 'wt_meta_description', true ) ) ) {
		echo '<meta name="description" content="' . esc_attr( $d ) . '">' . "\n";
	}
}, 2 );
add_action( 'add_meta_boxes', function () {
	add_meta_box( 'wt_seo', 'SEO (ชื่อในผลค้นหา / คำอธิบายสั้น)', function ( $post ) {
		wp_nonce_field( 'wt_seo', 'wt_seo_nonce' );
		printf( '<p><label><b>SEO Title</b><br><input type="text" name="wt_seo_title" value="%s" style="width:100%%"></label></p>', esc_attr( get_post_meta( $post->ID, 'wt_seo_title', true ) ) );
		printf( '<p><label><b>Meta description</b> (≤160 ตัวอักษร)<br><textarea name="wt_meta_description" rows="3" style="width:100%%">%s</textarea></label></p>', esc_textarea( get_post_meta( $post->ID, 'wt_meta_description', true ) ) );
		printf( '<p><label><b>หน้าคู่ภาษาอังกฤษ (URL)</b> — ใส่เมื่อมีหน้า EN ที่แปลโดยคนแล้วเท่านั้น ระบบจะใส่ hreflang ให้<br><input type="url" name="wt_en_url" value="%s" style="width:100%%" placeholder="https://westonsthai.com/en/products/"></label></p>', esc_attr( get_post_meta( $post->ID, 'wt_en_url', true ) ) );
		printf( '<p><label><input type="checkbox" name="wt_lang_en" value="1" %s> หน้านี้เป็นภาษาอังกฤษ (ใส่ lang="en") </label> &nbsp; <label>หน้าคู่ภาษาไทย (URL) <input type="url" name="wt_th_url" value="%s" style="width:60%%"></label></p>', checked( get_post_meta( $post->ID, 'wt_lang', true ), 'en', false ), esc_attr( get_post_meta( $post->ID, 'wt_th_url', true ) ) );
	}, 'page', 'normal', 'low' );
} );
add_action( 'save_post_page', function ( $post_id ) {
	if ( ! isset( $_POST['wt_seo_nonce'] ) || ! wp_verify_nonce( $_POST['wt_seo_nonce'], 'wt_seo' ) || ! current_user_can( 'edit_post', $post_id ) ) { return; }
	update_post_meta( $post_id, 'wt_seo_title', sanitize_text_field( $_POST['wt_seo_title'] ?? '' ) );
	update_post_meta( $post_id, 'wt_meta_description', sanitize_text_field( $_POST['wt_meta_description'] ?? '' ) );
	update_post_meta( $post_id, 'wt_lang', empty( $_POST['wt_lang_en'] ) ? 'th' : 'en' );
	update_post_meta( $post_id, 'wt_th_url', esc_url_raw( $_POST['wt_th_url'] ?? '' ) );
} );
