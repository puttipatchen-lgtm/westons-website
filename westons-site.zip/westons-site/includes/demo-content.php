<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function wt_install_demo_content() {
$log = array();
/**
 * เนื้อหาตัวอย่าง (mockup) สำหรับเว็บทดลอง — หน้า 8 หน้า การ์ดสินค้า 21 ใบ รูปจากเว็บเดิม 31 ไฟล์
 * เรียกจาก: เครื่องมือ → เนื้อหาตัวอย่าง Westons, หรือ wp eval 'wt_install_demo_content();'
 * - import old-site images as media (once)
 * - create product cards
 * - create pages from content/*.html (placeholders {{img:path}} / {{id:path}})
 */
$img_root = WT_SITE_DIR . 'demo/images';
$content_root = WT_SITE_DIR . 'demo/content';

require_once ABSPATH . 'wp-admin/includes/image.php';
require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/media.php';

/* ---------- media ---------- */
$alts = array(
	'products/tube-and-bottle-1.jpg' => 'หลอดผลิตภัณฑ์อาบน้ำสีดำสี่หลอดบนเคาน์เตอร์หิน',
	'products/tube-and-bottle-2.jpg' => 'ขวดแชมพูและครีมอาบน้ำสีดำวางบนถาดหินสีฟ้า',
	'products/tube-and-bottle-3.jpg' => 'ขวดแก้วแชมพูและครีมอาบน้ำสีอำพันสี่ขวด',
	'products/tube-and-bottle-4.jpg' => 'หลอดแชมพู ครีมนวด โลชัน และครีมอาบน้ำสีแดงเข้ม',
	'products/accessories-1.jpg' => 'แปรงสีฟัน มีดโกน หวี และของใช้ชิ้นเล็กจัดวางบนพื้นไม้',
	'products/accessories-2.jpg' => 'ถุงสุขอนามัยสีขาว',
	'products/accessories-3.jpg' => 'ชุดขัดรองเท้าและซองผ้า',
	'products/accessories-4.jpg' => 'ถุงซักผ้าพิมพ์โลโก้',
	'products/accessories-5.jpg' => 'ใยบวบธรรมชาติในตะกร้าหวาย',
	'products/accessories-6.jpg' => 'ของใช้ชิ้นเล็กในห้องพักจัดวางบนถาดพร้อมแก้ว',
	'products/amenity-set-1.jpg' => 'ชุด amenity ขวดเล็กและกล่องบนถาดรูปใบไม้',
	'products/amenity-set-2.jpg' => 'ชุด amenity กล่องสีแดงเข้มบนถาดในห้องน้ำโรงแรม',
	'products/amenity-set-3.jpg' => 'ชุด amenity หลอดสีทองและกล่องกระดาษบนเคาน์เตอร์',
	'products/kid-set-1.jpg' => 'ชุดของใช้สำหรับเด็กกับตุ๊กตาหมี',
	'products/kid-set-2.jpg' => 'ขวดผลิตภัณฑ์อาบน้ำสีขาวสี่ขวดวางเรียง',
	'products/kid-set-3.jpg' => 'ชุดของใช้สำหรับเด็ก ขวดเล็ก ผ้า และตุ๊กตา',
	'products/package-1.jpg' => 'ซองผลิตภัณฑ์สีเขียวและสบู่ก้อนบนถาดไม้',
	'products/package-2.jpg' => 'กล่องกระดาษคราฟท์สี่กล่องพิงผนังหิน',
	'products/package-3.jpg' => 'แปรงสีฟันและของใช้ชิ้นเล็กในถุงใสจัดเรียงในกล่องไม้',
	'products/package-4.jpg' => 'ซองกระดาษลอนสีน้ำตาลบนใบไม้',
	'products/package-5.jpg' => 'กล่องกระดาษสามกล่องพิมพ์โลโก้บนเคาน์เตอร์หิน',
	'products/towel-1.jpg' => 'ผ้าขนหนูพับซ้อนข้างอ่างล้างหน้า',
	'products/towel-2.jpg' => 'รองเท้าในห้องพักสีขาวกับชุดคลุมและของใช้',
	'products/towel-3.jpg' => 'ผ้าขนหนูสีขาวพับซ้อนกับดอกลีลาวดี',
	'services/specially-made-scent.jpg' => 'ขวดน้ำมันหอมระเหยสีอำพัน อบเชย และส้มแห้ง',
	'services/bespoke-packaging-design.jpg' => 'ขวดแก้วใสผลิตภัณฑ์อาบน้ำหลายขวดบนเคาน์เตอร์',
	'services/customer-relationship.jpg' => 'การจับมือระหว่างการประชุม',
	'services/imported-amenity-brand-agency.jpg' => 'ผลิตภัณฑ์สปานำเข้าจัดวางบนชั้น',
	'about/whoweare.jpg' => 'มือกำลังบีบโลชันจากหลอดสีดำที่อ่างล้างมือ',
	'about/production.jpg' => 'ถังผสมสเตนเลสในสายการผลิต',
	'about/vision.png' => 'หลอดผลิตภัณฑ์หลายสีกับดอกไม้',
);
$media = get_option( 'wt_seed_media', array() );
foreach ( $alts as $rel => $alt ) {
	if ( isset( $media[ $rel ] ) && get_post( $media[ $rel ] ) ) { continue; }
	$file = "$img_root/$rel";
	if ( ! file_exists( $file ) ) { $log[] = "missing $rel"; continue; }
	$tmp = wp_tempnam( basename( $file ) );
	copy( $file, $tmp );
	$id = media_handle_sideload( array( 'name' => 'old-site-' . str_replace( '/', '-', $rel ), 'tmp_name' => $tmp ), 0, $alt );
	if ( is_wp_error( $id ) ) { $log[] = $id->get_error_message(); continue; }
	update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	$media[ $rel ] = $id;
}
update_option( 'wt_seed_media', $media );
$log[] = 'media: ' . count( $media );

/* ---------- product cards ---------- */
$cards = array(
	// group, title, excerpt, adjustable, status, hotel, hospital, image, order, note
	array( 'bath-body', 'แชมพู', 'ล้างออกง่าย เลือกแนวกลิ่นให้เข้ากับห้องพัก', 'กลิ่น · สี · ขนาด', 'available', 1, 1, 'products/tube-and-bottle-3.jpg', 10, 'ต้องยืนยัน P-01' ),
	array( 'bath-body', 'ครีมนวดผม', 'ผมนุ่มจัดทรงง่าย กลิ่นชุดเดียวกับแชมพู', 'กลิ่น · สี · ขนาด', 'available', 1, 0, 'products/tube-and-bottle-4.jpg', 20, 'ต้องยืนยัน P-02' ),
	array( 'bath-body', 'ครีมอาบน้ำ', 'ฟองนุ่ม ผิวไม่แห้งตึงหลังอาบ', 'กลิ่น · สี · ขนาด', 'available', 1, 1, 'products/tube-and-bottle-2.jpg', 30, 'ต้องยืนยัน P-03' ),
	array( 'bath-body', 'โลชันบำรุงผิว', 'ซึมเร็ว ไม่เหนียว กลิ่นอ่อน', 'กลิ่น · สี · ขนาด', 'available', 1, 1, 'about/whoweare.jpg', 40, 'ต้องยืนยัน P-04' ),
	array( 'special-care', 'โฟมล้างหน้า', 'สำหรับห้องพักที่อยากให้แขกมีขั้นตอนดูแลผิวครบ', '', 'pending', 0, 0, 'products/kid-set-2.jpg', 10, 'P-06' ),
	array( 'special-care', 'ลิปบาล์ม', 'ของชิ้นเล็กสำหรับเมืองอากาศแห้งหรือเที่ยวบิน', '', 'pending', 0, 0, 'products/amenity-set-3.jpg', 20, 'P-07' ),
	array( 'special-care', 'น้ำยาบ้วนปาก', 'เติมชุดดูแลช่องปากในห้องพักหรือห้องผู้ป่วย', '', 'pending', 0, 0, 'products/kid-set-1.jpg', 30, 'P-08' ),
	array( 'special-care', 'ผลิตภัณฑ์กันยุง', 'สำหรับรีสอร์ตริมทะเลหรือใกล้ธรรมชาติ', '', 'pending', 0, 0, 'products/package-1.jpg', 40, 'P-09 อาจมีทะเบียนเฉพาะ' ),
	array( 'special-care', 'ครีมกันแดด', 'สำหรับรีสอร์ตที่แขกใช้เวลากลางแจ้ง', '', 'pending', 0, 0, 'about/vision.png', 50, 'P-10 ห้ามระบุ SPF' ),
	array( 'amenity-kits', 'ชุดดูแลช่องปาก', 'แปรงสีฟันและยาสีฟัน จัดซองให้เข้ากับห้อง', 'บรรจุภัณฑ์ · โลโก้', 'available', 1, 1, 'products/package-3.jpg', 10, 'ต้องยืนยัน P-11' ),
	array( 'amenity-kits', 'ชุดโกนหนวด', 'มีดโกนและครีมโกนหนวด', 'บรรจุภัณฑ์ · โลโก้', 'available', 1, 1, 'products/accessories-1.jpg', 20, 'ต้องยืนยัน P-12' ),
	array( 'amenity-kits', 'หวีและหมวกอาบน้ำ', 'ของใช้พื้นฐานที่แขกมองหาเสมอ', 'บรรจุภัณฑ์', 'available', 1, 1, 'products/accessories-6.jpg', 30, 'ต้องยืนยัน P-13' ),
	array( 'amenity-kits', 'สำลีและคอตตอนบัด', 'จัดกล่องเล็กให้เข้ากับชุด', 'บรรจุภัณฑ์', 'available', 1, 0, 'products/package-5.jpg', 40, 'ต้องยืนยัน P-14' ),
	array( 'amenity-kits', 'ชุดเย็บผ้า', 'ของชิ้นเล็กที่แสดงความใส่ใจ', 'บรรจุภัณฑ์', 'available', 1, 0, 'products/package-4.jpg', 50, 'ต้องยืนยัน P-15' ),
	array( 'slippers', 'รองเท้าในห้องพัก รุ่น A', '[ขาด: วัสดุ พื้นรองเท้า ขนาด]', 'โลโก้', 'pending', 1, 0, 'products/towel-2.jpg', 10, 'P-19' ),
	array( 'slippers', 'รองเท้าห้องผู้ป่วย รุ่น B', 'สวมง่าย [ขาด: วัสดุ พื้นรองเท้า]', 'โลโก้', 'pending', 0, 1, 'products/towel-1.jpg', 20, 'P-20' ),
	array( 'packaging', 'ขวดและหลอด', 'ขนาดเล็กสำหรับวางในห้องพัก', 'ทรง · ฝา · ขนาด', 'available', 1, 1, 'products/tube-and-bottle-1.jpg', 10, 'ต้องยืนยัน P-22' ),
	array( 'packaging', 'ซองและกล่อง', 'กระดาษหรือลวดลายตามสไตล์ห้องพัก', 'วัสดุ · ลวดลาย', 'available', 1, 1, 'products/package-2.jpg', 20, 'ต้องยืนยัน P-23' ),
	array( 'packaging', 'ระบบเติม / dispenser', 'ลดขวดใช้ครั้งเดียว [ขาด: รุ่นที่มี]', '', 'pending', 1, 0, 'services/bespoke-packaging-design.jpg', 30, 'P-24, C-07' ),
	array( 'imported-brands', 'Of the Islands', '[ขาด: รายการสินค้าที่นำเข้า]', '', 'pending', 1, 0, 'products/amenity-set-1.jpg', 10, 'รอสิทธิ์ใช้ชื่อ/ภาพ' ),
	array( 'imported-brands', "Margy's", '[ขาด: รายการสินค้าที่นำเข้า]', '', 'pending', 1, 0, 'products/amenity-set-2.jpg', 20, 'รอสิทธิ์ใช้ชื่อ/ภาพ' ),
);
$en_cards = array(
	'แชมพู' => array( 'Shampoo', 'Rinses easily; choose a scent to suit the room', 'scent · colour · size' ),
	'ครีมนวดผม' => array( 'Conditioner', 'Soft, manageable hair; scent matched to the shampoo', 'scent · colour · size' ),
	'ครีมอาบน้ำ' => array( 'Shower gel', 'Soft lather, skin not left tight', 'scent · colour · size' ),
	'โลชันบำรุงผิว' => array( 'Body lotion', 'Absorbs quickly, not sticky, light scent', 'scent · colour · size' ),
	'โฟมล้างหน้า' => array( 'Facial foam', 'For rooms where guests expect a full skincare routine', '' ),
	'ลิปบาล์ม' => array( 'Lip balm', 'A small item for dry-air cities and long flights', '' ),
	'น้ำยาบ้วนปาก' => array( 'Mouthwash', 'Completes the oral-care kit in guest and patient rooms', '' ),
	'ผลิตภัณฑ์กันยุง' => array( 'Mosquito repellent', 'For beach and nature resorts', '' ),
	'ครีมกันแดด' => array( 'Sunscreen', 'For resorts where guests spend time outdoors', '' ),
	'ชุดดูแลช่องปาก' => array( 'Oral-care kit', 'Toothbrush and toothpaste, packed to suit the room', 'packaging · logo' ),
	'ชุดโกนหนวด' => array( 'Shaving kit', 'Razor and shaving cream', 'packaging · logo' ),
	'หวีและหมวกอาบน้ำ' => array( 'Comb & shower cap', 'The basics guests always look for', 'packaging' ),
	'สำลีและคอตตอนบัด' => array( 'Cotton pads & buds', 'Small box matched to the kit', 'packaging' ),
	'ชุดเย็บผ้า' => array( 'Sewing kit', 'A small item that shows care', 'packaging' ),
	'รองเท้าในห้องพัก รุ่น A' => array( 'Guest-room slippers, model A', '[MISSING: material, sole, sizes]', 'logo' ),
	'รองเท้าห้องผู้ป่วย รุ่น B' => array( 'Patient-room slippers, model B', 'Easy to wear [MISSING: material, sole]', 'logo' ),
	'ขวดและหลอด' => array( 'Bottles & tubes', 'Small sizes for in-room placement', 'shape · cap · size' ),
	'ซองและกล่อง' => array( 'Sachets & boxes', 'Paper or patterned to suit the room style', 'material · pattern' ),
	'ระบบเติม / dispenser' => array( 'Refill / dispenser', 'Fewer single-use bottles [MISSING: available models]', '' ),
	'Of the Islands' => array( 'Of the Islands', '[MISSING: imported product list]', '' ),
	"Margy's" => array( "Margy's", '[MISSING: imported product list]', '' ),
);
$existing = get_posts( array( 'post_type' => 'wt_product_card', 'numberposts' => -1, 'post_status' => 'any', 'fields' => 'ids' ) );
foreach ( $existing as $pid ) { wp_delete_post( $pid, true ); }
foreach ( $cards as $c ) {
	list( $group, $title, $excerpt, $adj, $status, $hotel, $hosp, $img, $order, $note ) = $c;
	$pid = wp_insert_post( array( 'post_type' => 'wt_product_card', 'post_status' => 'publish', 'post_title' => $title, 'post_excerpt' => $excerpt, 'menu_order' => $order ) );
	wp_set_object_terms( $pid, $group, 'wt_product_group' );
	update_post_meta( $pid, 'wt_status', $status );
	update_post_meta( $pid, 'wt_adjustable', $adj );
	update_post_meta( $pid, 'wt_use_hotel', (bool) $hotel );
	update_post_meta( $pid, 'wt_use_hospital', (bool) $hosp );
	update_post_meta( $pid, 'wt_note', $note );
	if ( isset( $media[ $img ] ) ) { set_post_thumbnail( $pid, $media[ $img ] ); }
	if ( isset( $en_cards[ $title ] ) ) { update_post_meta( $pid, 'wt_title_en', $en_cards[ $title ][0] ); update_post_meta( $pid, 'wt_excerpt_en', $en_cards[ $title ][1] ); update_post_meta( $pid, 'wt_adjustable_en', $en_cards[ $title ][2] ); }
}
$log[] = 'cards: ' . count( $cards );

/* ---------- pages ---------- */
$pages = array(
	// slug => [title, file, template, seo title, meta]
	'home'                => array( 'หน้าแรก', 'home.html', 'page-hub', 'ผู้ผลิตชุด amenity โรงแรมและของใช้ผู้ป่วยโรงพยาบาล | Westons Thai', 'Westons พัฒนาแชมพู ครีมอาบน้ำ และโลชันสำหรับโรงแรมและโรงพยาบาล ปรับกลิ่นและสีให้เข้ากับแบรนด์ พร้อมของใช้ชิ้นเล็กที่จัดเป็นชุด เล่าโจทย์ของคุณได้เลย' ),
	'products'            => array( 'สินค้า', 'products.html', 'page-hub', 'ของใช้ในโรงแรมและห้องผู้ป่วย: ชุด amenity แชมพู ครีมอาบน้ำ รองเท้า | Westons Thai', 'ผลิตภัณฑ์อาบน้ำและดูแลผิว ของใช้และชุดจัดรวม รองเท้า และบรรจุภัณฑ์ สำหรับโรงแรมและโรงพยาบาล ปรับให้เข้ากับแบรนด์ได้' ),
	'hotels'              => array( 'สำหรับโรงแรม', 'hotels.html', 'page-hub', 'ชุด amenity โรงแรมและรีสอร์ต แชมพู ครีมอาบน้ำ ปรับกลิ่นตามแบรนด์ | Westons Thai', 'ออกแบบชุด amenity โรงแรม ตั้งแต่แนวกลิ่นของแชมพูและครีมอาบน้ำ ไปจนถึงของชิ้นเล็กในห้องน้ำ ให้เข้ากับบุคลิกของที่พัก' ),
	'hospitals'           => array( 'สำหรับโรงพยาบาล', 'hospitals.html', 'page-hub', 'ชุดของใช้ผู้ป่วยโรงพยาบาล ผลิตภัณฑ์ดูแลตัวและรองเท้า | Westons Thai', 'ชุดของใช้สำหรับผู้ป่วย ผลิตภัณฑ์ดูแลตัว และรองเท้า ที่ช่วยให้ผู้ป่วยรู้สึกได้รับการดูแลตั้งแต่เข้าห้อง' ),
	'product-development' => array( 'ร่วมพัฒนาผลิตภัณฑ์', 'product-development.html', 'page-hub', 'รับผลิตแชมพู ครีมอาบน้ำ OEM สำหรับโรงแรมและแบรนด์ | Westons Thai', 'รับพัฒนาแชมพู ครีมอาบน้ำ และผลิตภัณฑ์ดูแลตัวภายใต้แบรนด์ของคุณ เริ่มจากโจทย์ ทดลองตัวอย่าง แล้วผลิต' ),
	'about'               => array( 'เกี่ยวกับเรา', 'about.html', '', 'เกี่ยวกับ Westons (Thai) Co., Ltd.', 'ทีมที่ดูแลรายละเอียดของผลิตภัณฑ์ตั้งแต่สูตรจนถึงชุดที่ส่งถึงห้องพัก' ),
	'contact'             => array( 'เล่าโจทย์ของคุณ', 'contact.html', '', 'เล่าโจทย์ของคุณ ขอตัวอย่างหรือใบเสนอราคา | Westons Thai', 'ติดต่อ Westons ทางฟอร์ม LINE โทร หรืออีเมล เล่าโจทย์ของคุณแม้ยังไม่มีสเปกครบ' ),
	'privacy-policy'      => array( 'นโยบายความเป็นส่วนตัว', 'privacy-policy.html', '', 'นโยบายความเป็นส่วนตัว | Westons Thai', 'นโยบายการเก็บและใช้ข้อมูลส่วนบุคคลของเว็บไซต์ Westons Thai' ),
);
$h1 = array( 'about' => 'ทีมที่ดูแลรายละเอียดของผลิตภัณฑ์ตั้งแต่สูตรจนถึงชุดที่ส่งถึงห้องพัก', 'contact' => 'เล่าโจทย์ของคุณ แม้ยังไม่มีสเปกครบ' );
foreach ( $pages as $slug => $p ) {
	list( $title, $file, $template, $seo_title, $meta ) = $p;
	$html = file_get_contents( "$content_root/$file" );
	$html = preg_replace_callback( '/\{\{(img|id):([^}]+)\}\}/', function ( $m ) use ( $media ) {
		$id = $media[ $m[2] ] ?? 0;
		return 'img' === $m[1] ? ( $id ? wp_get_attachment_image_url( $id, 'large' ) : '' ) : $id;
	}, $html );
	$existing = get_page_by_path( $slug, OBJECT, 'page' );
	$args = array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug, 'post_title' => $h1[ $slug ] ?? $title, 'post_content' => $html );
	if ( $existing ) { $args['ID'] = $existing->ID; $pid = wp_update_post( $args ); } else { $pid = wp_insert_post( $args ); }
	if ( $template ) { update_post_meta( $pid, '_wp_page_template', $template ); } else { delete_post_meta( $pid, '_wp_page_template' ); }
	update_post_meta( $pid, 'wt_seo_title', $seo_title );
	update_post_meta( $pid, 'wt_meta_description', $meta );
	update_post_meta( $pid, 'wt_nav_title', $title );
	if ( 'home' === $slug ) { update_option( 'show_on_front', 'page' ); update_option( 'page_on_front', $pid ); }
}
$log[] = 'pages: ' . count( $pages );

/* ---------- หน้าภาษาอังกฤษใต้ /en/ (ร่างแปล รอตรวจ) + ผูกคู่หน้า ---------- */
$en_pages = array(
	'home'                => array( 'Home', 'page-hub-en', 'Hotel & Hospital Amenities Manufacturer in Thailand | Westons Thai', 'Westons develops and produces shampoo, shower gel and lotion for hotels and hospitals in Thailand, tuned to your scent and colour, with matching guest amenities.', 'The small details guests remember' ),
	'products'            => array( 'Products', 'page-hub-en', 'Hotel & Hospital Amenities: Shampoo, Shower Gel, Kits, Slippers | Westons Thai', 'Bath & body, guest amenities and kits, slippers and packaging for hotels and hospitals in Thailand, adaptable to your brand.', 'Products for guest rooms and patient rooms' ),
	'hotels'              => array( 'Hotels', 'page-hub-en', 'Hotel Amenities in Thailand, Scent and Colour Matched to Your Brand | Westons Thai', 'Hotel amenity sets designed to fit your property, from the scent of the shampoo to the small items in the bathroom.', 'Let the scent and amenities in the bathroom tell your property\'s story' ),
	'hospitals'           => array( 'Hospitals', 'page-hub-en', 'Patient Amenity Kits for Hospitals in Thailand | Westons Thai', 'Patient amenity kits, personal care and slippers that make patients feel cared for from the moment they arrive.', 'Amenities that make patients feel cared for from the moment they arrive' ),
	'product-development' => array( 'Co-development', 'page-hub-en', 'Private-Label Shampoo, Shower Gel and Amenities for Hotels and Brands | Westons Thai', 'Develop shampoo, shower gel and personal-care products under your own brand: brief, samples, refine, produce.', 'Start from the experience you want to create, and we\'ll develop the product together' ),
	'about'               => array( 'About', 'page-en', 'About Westons (Thai) Co., Ltd.', 'The team that looks after the details, from formula to the kit that reaches the room.', 'The team that looks after the details, from formula to the kit that reaches the room' ),
	'contact'             => array( 'Contact', 'page-en', 'Tell Us About Your Property, Request Samples or a Quote | Westons Thai', 'Contact Westons by form, LINE, phone or email. You don\'t need a full spec to start.', 'Tell us about your property, even without a full spec' ),
	'privacy-policy'      => array( 'Privacy policy', 'page-en', 'Privacy Policy | Westons Thai', 'How Westons Thai collects and uses personal data.', 'Privacy policy' ),
);
$en_root = get_page_by_path( 'en', OBJECT, 'page' );
$en_root_id = $en_root ? $en_root->ID : 0;
foreach ( $en_pages as $slug => $e ) {
	list( $nav, $template, $seo_title, $meta, $h1_en ) = $e;
	$file = "$content_root/en/$slug.html";
	if ( ! file_exists( $file ) ) { continue; }
	$html = preg_replace_callback( '/\{\{(img|id):([^}]+)\}\}/', function ( $m ) use ( $media ) {
		$id = $media[ $m[2] ] ?? 0;
		return 'img' === $m[1] ? ( $id ? wp_get_attachment_image_url( $id, 'large' ) : '' ) : $id;
	}, file_get_contents( $file ) );
	$path = 'home' === $slug ? 'en' : "en/$slug";
	$existing = get_page_by_path( $path, OBJECT, 'page' );
	$args = array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => 'home' === $slug ? 'en' : $slug, 'post_title' => $h1_en, 'post_content' => $html, 'post_parent' => 'home' === $slug ? 0 : $en_root_id );
	if ( $existing ) { $args['ID'] = $existing->ID; $pid = wp_update_post( $args ); } else { $pid = wp_insert_post( $args ); }
	if ( 'home' === $slug ) { $en_root_id = $pid; }
	update_post_meta( $pid, '_wp_page_template', $template );
	update_post_meta( $pid, 'wt_seo_title', $seo_title );
	update_post_meta( $pid, 'wt_meta_description', $meta );
	update_post_meta( $pid, 'wt_nav_title', $nav );
	update_post_meta( $pid, 'wt_lang', 'en' );
	$th = get_page_by_path( $slug, OBJECT, 'page' );
	if ( $th ) {
		update_post_meta( $pid, 'wt_th_url', get_permalink( $th ) );
		update_post_meta( $th->ID, 'wt_en_url', get_permalink( $pid ) );
	}
}
$log[] = 'en pages: ' . count( $en_pages );

/* ---------- บทความ: หน้า /articles/ + ร่าง 4 บทความ (draft) ---------- */
$art = get_page_by_path( 'articles', OBJECT, 'page' );
$art_id = $art ? $art->ID : wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => 'articles', 'post_title' => 'บทความ', 'post_content' => '' ) );
update_post_meta( $art_id, 'wt_seo_title', 'บทความ: วิธีเลือกของใช้ในโรงแรมและโรงพยาบาล | Westons Thai' );
update_post_meta( $art_id, 'wt_meta_description', 'คลังความรู้สำหรับผู้ดูแลที่พักและโรงพยาบาล วิธีเลือกแชมพู ครีมอาบน้ำ ชุดของใช้ และบรรจุภัณฑ์' );
update_post_meta( $art_id, 'wt_nav_title', 'บทความ' );
update_option( 'page_for_posts', $art_id );
$drafts = array(
	array( 'เช็กลิสต์ของใช้ในห้องพักโรงแรม ต้องมีอะไรบ้าง', 'amenity-checklist-hotel-room', 'คำค้นเป้าหมาย: amenity มีอะไรบ้าง / ของใช้ในห้องพักโรงแรม ต้องมีอะไรบ้าง', array( 'ของใช้ในห้องน้ำ (แชมพู ครีมอาบน้ำ ครีมนวด โลชัน สบู่)', 'ของใช้ส่วนตัวชิ้นเล็ก (แปรงสีฟัน หวี มีดโกน หมวกอาบน้ำ สำลี ชุดเย็บผ้า)', 'รองเท้าและของใช้ในห้องนอน', 'จัดชุดตามระดับห้องและระยะเวลาเข้าพัก', 'ตัวอย่างการจัดวางที่แม่บ้านเติมง่าย' ) ),
	array( 'เลือกแชมพูและครีมอาบน้ำสำหรับโรงแรมอย่างไรให้แขกจำได้', 'choose-hotel-shampoo-shower-gel', 'คำค้นเป้าหมาย: แชมพูโรงแรม / ครีมอาบน้ำโรงแรม / วิธีเลือกแชมพูโรงแรม', array( 'แนวกลิ่นกับบุคลิกของที่พัก', 'สีของเนื้อผลิตภัณฑ์และภาพรวมห้องน้ำ', 'ขนาดบรรจุ: ขวดเล็ก vs ระบบเติม', 'สิ่งที่ปรับได้และข้อจำกัดของสูตร', 'ขั้นตอนขอตัวอย่างและทดลอง' ) ),
	array( 'ชุดของใช้ผู้ป่วยในโรงพยาบาลควรมีอะไร และจัดอย่างไรให้ผู้ป่วยสบายใจ', 'hospital-patient-amenity-kit', 'คำค้นเป้าหมาย: ของใช้ผู้ป่วยโรงพยาบาล / ชุดของใช้ผู้ป่วย', array( 'วันแรกที่เข้าห้อง: ของที่ควรพร้อมบนโต๊ะข้างเตียง', 'ระหว่างพักรักษา: ผลิตภัณฑ์ที่ใช้ง่ายและกลิ่นไม่รบกวน', 'รองเท้าสำหรับห้องผู้ป่วย', 'จัดชุดตามประเภทห้อง (ห้องพิเศษ / หอผู้ป่วย)', 'สิ่งที่ฝ่ายจัดซื้อควรถามซัพพลายเออร์' ) ),
	array( 'ขวดเล็ก ขวดเติม หรือ dispenser แบบไหนเหมาะกับที่พักของคุณ', 'refill-vs-single-use-amenities', 'คำค้นเป้าหมาย: แชมพูรีฟิล / dispenser โรงแรม / ลดขวดพลาสติกโรงแรม', array( 'ภาพรวมและความรู้สึกของแขกในแต่ละแบบ', 'ภาระงานแม่บ้านและการเติมสต๊อก', 'ต้นทุนต่อห้องต่อคืนโดยประมาณ (ต้องยืนยันตัวเลข)', 'ทางเลือกวัสดุบรรจุภัณฑ์', 'วิธีตัดสินใจร่วมกับทีม' ) ),
);
foreach ( $drafts as $d ) {
	if ( get_page_by_path( $d[1], OBJECT, 'post' ) ) { continue; }
	$body = '<!-- wp:paragraph --><p><span class="wt-flag">ร่างโครงบทความ — ต้องเขียนเนื้อหาจริงและตรวจข้อเท็จจริงกับบริษัทก่อนเผยแพร่ · ' . esc_html( $d[2] ) . '</span></p><!-- /wp:paragraph -->';
	foreach ( $d[3] as $h ) { $body .= '<!-- wp:heading --><h2 class="wp-block-heading">' . esc_html( $h ) . '</h2><!-- /wp:heading --><!-- wp:paragraph --><p>[เขียนเนื้อหา 120–200 คำ จากงานจริงของ Westons ไม่ใส่ตัวเลขที่ยังไม่ยืนยัน]</p><!-- /wp:paragraph -->'; }
	wp_insert_post( array( 'post_type' => 'post', 'post_status' => 'draft', 'post_name' => $d[1], 'post_title' => $d[0], 'post_content' => $body, 'post_excerpt' => $d[2] ) );
}
$log[] = 'articles: page + 4 drafts';

/* ---------- contact defaults (ต้องยืนยันทั้งหมด) ---------- */
if ( ! get_option( 'wt_contact' ) ) {
	update_option( 'wt_contact', array_merge( wt_contact_defaults(), array(
		'phone' => '024154826', 'phone_display' => '02-415-4826', 'email' => 'admin@westonsthai.com',
		'address' => '87/198-199 ซอยเอกชัย 76 แยก 2 บางบอน กรุงเทพฯ (ต้องยืนยัน)', 'line_label' => 'คุยทาง LINE',
	) ) );
}
update_option( 'blogname', 'Westons Thai' );
update_option( 'blogdescription', 'ผลิตภัณฑ์ดูแลตัวสำหรับโรงแรมและโรงพยาบาล' );
update_option( 'blog_public', 0 );
update_option( 'timezone_string', 'Asia/Bangkok' );
/* ---------- รูปแบบหน้าตาเริ่มต้น: HD Editorial (สลับกลับได้ที่ Appearance → Editor → Styles) ---------- */
if ( class_exists( 'WP_Theme_JSON_Resolver' ) && ! get_option( 'wt_style_applied' ) ) {
	$vf = get_stylesheet_directory() . '/styles/hd.json';
	if ( file_exists( $vf ) ) {
		$v = json_decode( file_get_contents( $vf ), true );
		if ( is_array( $v ) ) {
			unset( $v['$schema'], $v['title'] );
			$v['isGlobalStylesUserThemeJSON'] = true;
			$gid = WP_Theme_JSON_Resolver::get_user_global_styles_post_id();
			if ( $gid ) { wp_update_post( array( 'ID' => $gid, 'post_content' => wp_slash( wp_json_encode( $v ) ) ) ); update_option( 'wt_style_applied', 'hd' ); $log[] = 'style: hd'; }
		}
	}
}
$log[] = 'seeded';
update_option( 'wt_demo_installed', current_time( 'mysql' ) );
flush_rewrite_rules();
return $log;
}

/* หน้าเครื่องมือ */
add_action( 'admin_menu', function () {
	add_management_page( 'เนื้อหาตัวอย่าง Westons', 'เนื้อหาตัวอย่าง Westons', 'manage_options', 'wt-demo', function () {
		echo '<div class="wrap"><h1>เนื้อหาตัวอย่าง Westons</h1>';
		if ( isset( $_POST['wt_demo_nonce'] ) && wp_verify_nonce( $_POST['wt_demo_nonce'], 'wt_demo' ) && current_user_can( 'manage_options' ) ) {
			$log = wt_install_demo_content();
			echo '<div class="notice notice-success"><p>นำเข้าแล้ว: ' . esc_html( implode( ' · ', $log ) ) . '</p></div>';
		}
		$done = get_option( 'wt_demo_installed' );
		echo '<p>สร้างหน้า 8 หน้า (หน้าแรก สินค้า โรงแรม โรงพยาบาล ร่วมพัฒนา เกี่ยวกับเรา ติดต่อ นโยบาย) การ์ดสินค้า 21 ใบ และรูป mockup จากเว็บเดิม ข้อความจาก COPY-DECK-TH 0.1 พร้อมป้าย “ต้องยืนยัน”</p>';
		echo '<p><strong>คำเตือน:</strong> การ์ดสินค้าเดิมทั้งหมดจะถูกลบและสร้างใหม่ หน้าที่ slug ซ้ำจะถูกเขียนทับ' . ( $done ? ' · นำเข้าล่าสุด ' . esc_html( $done ) : '' ) . '</p>';
		echo '<form method="post">'; wp_nonce_field( 'wt_demo', 'wt_demo_nonce' ); submit_button( $done ? 'นำเข้าซ้ำ (เขียนทับ)' : 'นำเข้าเนื้อหาตัวอย่าง' ); echo '</form></div>';
	} );
} );
