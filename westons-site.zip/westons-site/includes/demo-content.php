<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function wt_install_demo_content() {
$log = array();
/**
 * เนื้อหาตัวอย่าง (mockup) สำหรับเว็บทดลอง — หน้า 8 หน้า การ์ดสินค้า 21 ใบ รูปจากเว็บเดิม 31 ไฟล์
 * เรียกจาก: เครื่องมือ → เนื้อหาตัวอย่าง Westons, หรือ wp eval 'wt_install_demo_content();'
 * - import old-site images as media (once)
 * - create product cards
 * - create pages from content/*.html (placeholders {{img:path}} / {{id:path}})
 */
$img_root = WT_SITE_DIR . 'demo/images';
$content_root = WT_SITE_DIR . 'demo/content';

require_once ABSPATH . 'wp-admin/includes/image.php';
require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/media.php';

/* ---------- media ---------- */
$alts = array(
	'products/tube-and-bottle-1.jpg' => 'หลอดผลิตภัณฑ์อาบน้ำสีดำสี่หลอดบนเคาน์เตอร์หิน',
	'products/tube-and-bottle-2.jpg' => 'ขวดแชมพูและครีมอาบน้ำสีดำวางบนถาดหินสีฟ้า',
	'products/tube-and-bottle-3.jpg' => 'ขวดแก้วแชมพูและครีมอาบน้ำสีอำพันสี่ขวด',
	'products/tube-and-bottle-4.jpg' => 'หลอดแชมพู ครีมนวด โลชัน และครีมอาบน้ำสีแดงเข้ม',
	'products/accessories-1.jpg' => 'แปรงสีฟัน มีดโกน หวี และของใช้ชิ้นเล็กจัดวางบนพื้นไม้',
	'products/accessories-2.jpg' => 'ถุงสุขอนามัยสีขาว',
	'products/accessories-3.jpg' => 'ชุดขัดรองเท้าและซองผ้า',
	'products/accessories-4.jpg' => 'ถุงซักผ้าพิมพ์โลโก้',
	'products/accessories-5.jpg' => 'ใยบวบธรรมชาติในตะกร้าหวาย',
	'products/accessories-6.jpg' => 'ของใช้ชิ้นเล็กในห้องพักจัดวางบนถาดพร้อมแก้ว',
	'products/amenity-set-1.jpg' => 'ชุด amenity ขวดเล็กและกล่องบนถาดรูปใบไม้',
	'products/amenity-set-2.jpg' => 'ชุด amenity กล่องสีแดงเข้มบนถาดในห้องน้ำโรงแรม',
	'products/amenity-set-3.jpg' => 'ชุด amenity หลอดสีทองและกล่องกระดาษบนเคาน์เตอร์',
	'products/kid-set-1.jpg' => 'ชุดของใช้สำหรับเด็กกับตุ๊กตาหมี',
	'products/kid-set-2.jpg' => 'ขวดผลิตภัณฑ์อาบน้ำสีขาวสี่ขวดวางเรียง',
	'products/kid-set-3.jpg' => 'ชุดของใช้สำหรับเด็ก ขวดเล็ก ผ้า และตุ๊กตา',
	'products/package-1.jpg' => 'ซองผลิตภัณฑ์สีเขียวและสบู่ก้อนบนถาดไม้',
	'products/package-2.jpg' => 'กล่องกระดาษคราฟท์สี่กล่องพิงผนังหิน',
	'products/package-3.jpg' => 'แปรงสีฟันและของใช้ชิ้นเล็กในถุงใสจัดเรียงในกล่องไม้',
	'products/package-4.jpg' => 'ซองกระดาษลอนสีน้ำตาลบนใบไม้',
	'products/package-5.jpg' => 'กล่องกระดาษสามกล่องพิมพ์โลโก้บนเคาน์เตอร์หิน',
	'products/towel-1.jpg' => 'ผ้าขนหนูพับซ้อนข้างอ่างล้างหน้า',
	'products/towel-2.jpg' => 'รองเท้าในห้องพักสีขาวกับชุดคลุมและของใช้',
	'products/towel-3.jpg' => 'ผ้าขนหนูสีขาวพับซ้อนกับดอกลีลาวดี',
	'services/specially-made-scent.jpg' => 'ขวดน้ำมันหอมระเหยสีอำพัน อบเชย และส้มแห้ง',
	'services/bespoke-packaging-design.jpg' => 'ขวดแก้วใสผลิตภัณฑ์อาบน้ำหลายขวดบนเคาน์เตอร์',
	'services/customer-relationship.jpg' => 'การจับมือระหว่างการประชุม',
	'services/imported-amenity-brand-agency.jpg' => 'ผลิตภัณฑ์สปานำเข้าจัดวางบนชั้น',
	'about/whoweare.jpg' => 'มือกำลังบีบโลชันจากหลอดสีดำที่อ่างล้างมือ',
	'about/production.jpg' => 'ถังผสมสเตนเลสในสายการผลิต',
	'about/vision.png' => 'หลอดผลิตภัณฑ์หลายสีกับดอกไม้',
	'illus/refill-dispenser.jpg' => 'ภาพตัวอย่าง: ขวดปั๊มแบบเติมในชั้นวางติดผนังห้องอาบน้ำ (รูปสต็อก Pexels รอรูปถ่ายจริง)',
	'illus/facial-foam.jpg' => 'ภาพตัวอย่าง: ขวดผลิตภัณฑ์ล้างหน้าฉลากเรียบบนโต๊ะสีครีม (รูปสต็อก Pexels รอรูปถ่ายจริง)',
	'illus/lip-balm.jpg' => 'ภาพตัวอย่าง: มือถือลิปบาล์มแท่งสีขาว (รูปสต็อก Pexels รอรูปถ่ายจริง)',
	'illus/mouthwash.jpg' => 'ภาพตัวอย่าง: แปรงสีฟันสีขาวในแก้วเซรามิกริมหน้าต่าง ชุดดูแลช่องปาก (รูปสต็อก Pexels รอรูปถ่ายจริง)',
	'illus/mosquito-repellent.jpg' => 'ภาพตัวอย่าง: มือถือขวดสเปรย์สีขาวเรียบ (รูปสต็อก Pexels รอรูปถ่ายจริง)',
	'illus/sunscreen.jpg' => 'ภาพตัวอย่าง: หลอดครีมสีขาวเรียบบนพื้นหลังนุ่ม (รูปสต็อก Pexels รอรูปถ่ายจริง)',
	'illus/slippers-hotel.jpg' => 'ภาพตัวอย่าง: รองเท้าโรงแรมสีขาวบนพื้นไม้ข้างเตียง (รูปสต็อก Pexels รอรูปถ่ายจริง)',
	'illus/slippers-hospital.jpg' => 'ภาพตัวอย่าง: พนักงานจัดวางรองเท้าสีขาวข้างเตียง (รูปสต็อก Pexels รอรูปถ่ายจริง)',
	'illus/ready-bath-set.jpg' => 'ภาพตัวอย่าง: ขวดและหลอดสีขาวไม่มีฉลาก 3 ชิ้น (รูปสต็อก Pexels รอรูปถ่ายจริง)',
	'illus/ready-kit.jpg' => 'ภาพตัวอย่าง: ชุดของใช้โรงแรม กล่องแปรงสีฟันและชุดโกนหนวดในตะกร้า (รูปสต็อก Pexels รอรูปถ่ายจริง)',
	'illus/hospital-set.jpg' => 'ภาพตัวอย่าง: ห้องผู้ป่วยเงียบสงบมีแสงแดดยามเช้า (รูปสต็อก Pexels รอรูปถ่ายจริง)',
	'illus/cert-gmp.jpg' => 'ภาพตัวอย่างใบรับรองมาตรฐานการผลิตเครื่องสำอาง (mockup รอเอกสารจริง)',
	'illus/cert-fda.jpg' => 'ภาพตัวอย่างใบรับจดแจ้งเครื่องสำอาง (mockup รอเอกสารจริง)',
	'illus/cert-dermscan.jpg' => 'ตัวอย่างใบรายงานผลทดสอบความระคายเคืองผิว (mockup รอเอกสารจริง)',
	'illus/cert-eco.jpg' => 'ตัวอย่างใบรับรองวัสดุย่อยสลายได้ (mockup รอเอกสารจริง)',
	'illus/cert-iso.jpg' => 'ภาพตัวอย่างใบรับรองระบบคุณภาพ (mockup รอเอกสารจริง)',
	'eco/eco-toothbrush.jpg' => 'แปรงสีฟันด้ามไม้ไผ่ ฟางข้าวสาลี และแป้งข้าวโพด วางเรียงบนพื้นสีเทา',
	'eco/eco-comb.jpg' => 'หวีพลาสติกและหวีวัสดุธรรมชาติหลายแบบวางเรียงบนพื้นสีเทา',
	'eco/eco-razor.jpg' => 'มีดโกนด้ามไม้ไผ่และด้ามพลาสติกวางเรียงบนพื้นสีเทา',
	'eco/eco-shower-cap.jpg' => 'หมวกอาบน้ำพลาสติกและแป้งข้าวโพดพับเป็นวงกลม 4 แบบ',
	'eco/eco-cotton-bud.jpg' => 'คอตตอนบัดก้านกระดาษ ก้านพลาสติก และก้านไม้ไผ่',
	'eco/eco-cotton-pad.jpg' => 'สำลีแผ่นกลมและแผ่นเหลี่ยมวางเรียงบนพื้นสีเทา',
	'eco/eco-nail-file.jpg' => 'ตะไบเล็บสีดำ สีขาว และแบบไม้',
	'eco/eco-sewing-kit.jpg' => 'ชุดเย็บผ้าด้ายหลายสีพร้อมกระดุม 3 แบบ',
	'eco/eco-laundry-bag.jpg' => 'ถุงซักรีดผ้าสีขาวแบบหูรูด พิมพ์คำว่า Laundry Bag',
	'eco/eco-slippers.jpg' => 'รองเท้าในห้องพักแบบใช้ครั้งเดียว สีขาวและสีเทาเข้ม 3 คู่',
	'eco/eco-sugarcane-set.jpg' => 'ชุด Amenity ในกล่องกระดาษชานอ้อยสีครีม แปรงสีฟัน มีดโกน หวี และใยขัดตัว',
	'eco/eco-kraft-set.jpg' => 'ชุด Amenity ในซองกระดาษคราฟท์ แปรงสีฟัน มีดโกน และหวี',
	'eco/eco-cotton-paper-set.jpg' => 'ชุด Amenity ในซองกระดาษสีขาว แปรงสีฟัน มีดโกน และหวี',
	'eco/eco-dispenser.jpg' => 'ขายึดขวดปั๊มติดผนังสีขาว พร้อมระยะขนาด',
	'eco/eco-refill-pouch.jpg' => 'ถุงเติมพลาสติกสีขาวมีหูหิ้วและจุกเท',
	'eco/eco-straw-tube-bottle.jpg' => 'ขวดผลิตภัณฑ์อาบน้ำวัสดุผสมฟางข้าวสาลีโทนครีม 4 ขวด',
	'eco/eco-tubes.jpg' => 'หลอดแชมพู ครีมนวด เจลอาบน้ำ และโลชัน ฝาดำ',
	'eco/eco-mini-bottles.jpg' => 'ขวดเล็กแชมพู ครีมนวด เจลอาบน้ำ และโลชัน ฝาดำ 4 สี',
	'eco/eco-pump-bottles-amber.jpg' => 'ขวดปั๊มขนาดใหญ่สีเทาใสและสีชา',
	'eco/eco-pump-bottles-cream.jpg' => 'ขวดปั๊มสีเขียวเข้มและสีครีม',
	'eco/eco-pump-bottles-black.jpg' => 'ขวดปั๊มสีดำและสีน้ำตาลใส',
	'eco/eco-pump-bottles-green.jpg' => 'ขวดปั๊มสีเขียวเข้มและสีน้ำเงินเข้ม',
	'eco/eco-aluminium-bottles.jpg' => 'ขวดอะลูมิเนียมขนาดเล็กคาดสีต่างกัน 4 ขวด',
	'eco/eco-refill-barrels.jpg' => 'แกลลอนเติมพลาสติกสีขาวขนาด 5 ลิตร 4 ใบ',
	'eco/eco-soap.jpg' => 'สบู่ก้อนกลมห่อพลีตสีขาว 3 ขนาด',
	'eco/eco-slipper-cloth.jpg' => 'รองเท้าผ้าสีขาว พื้นปุ่มนูน',
	'eco/eco-slipper-velour.jpg' => 'รองเท้ากำมะหยี่สีครีม พื้นสีน้ำตาล',
	'eco/eco-slipper-pearl-cotton.jpg' => 'รองเท้าผ้าฝ้ายสีขาว พื้นสีน้ำตาล',
	'eco/eco-slipper-sugarcane.jpg' => 'รองเท้าผ้าเส้นใยชานอ้อยสีครีม',
	'eco/eco-slipper-water-wave.jpg' => 'รองเท้าผ้าสีขาวลายคลื่น',
	'eco/eco-slipper-terry.jpg' => 'รองเท้าผ้าขนหนูสีขาว',
	'eco/eco-slipper-cork.jpg' => 'รองเท้าผ้าสีน้ำตาลลายไม้ก๊อก',
	'eco/eco-slipper-duck-kids.jpg' => 'รองเท้าเด็กสีเหลืองลายเป็ด',
	'eco/eco-slipper-velvet.jpg' => 'รองเท้ากำมะหยี่สีขาว',
	'eco/eco-slipper-waffle.jpg' => 'รองเท้าผ้าวาฟเฟิลสีขาว',
	'eco/eco-dispenser-steel.jpg' => 'ขาแขวนขวดปั๊มสเตนเลสสีเงิน พร้อมระยะขนาด',
	'eco/eco-dispenser-black-steel.jpg' => 'ขาแขวนขวดปั๊มสเตนเลสสีดำ พร้อมระยะขนาด',
	'eco/eco-dispenser-abs-lock.jpg' => 'ขาแขวนขวดปั๊มพลาสติก ABS สีดำแบบล็อกได้',
	'eco/eco-dispenser-wire.jpg' => 'ขาแขวนขวดปั๊มแบบโครงลวดสีดำ',
	'eco/eco-dispenser-shelf.jpg' => 'ชั้นวางขวดติดผนังสีดำแบบ 1 และ 2 ช่อง',
	'eco/eco-dispenser-frame.jpg' => 'โครงแขวนขวดปั๊มคู่สีดำและสีขาว',
	'eco/eco-kraft-bag-set.jpg' => 'ชุด Amenity ในถุงกระดาษคราฟท์ แปรงสีฟัน มีดโกน และยาสีฟัน',
	'eco/eco-stone-paper-set.jpg' => 'ชุด Amenity ในซองกระดาษหินสีดำ แปรงสีฟันไม้ไผ่และมีดโกน',
	'eco/eco-white-box-set.jpg' => 'ชุด Amenity ในกล่องกระดาษสีขาว แปรงสีฟันไม้ไผ่ มีดโกน และหวี',
	'eco/eco-shaving-cream.jpg' => 'หลอดครีมโกนหนวดสีขาว 2 หลอด',
	'eco/eco-shoe-horn.jpg' => 'ที่ช้อนรองเท้าพลาสติกและวัสดุธรรมชาติ 3 แบบ',
	'eco/eco-loofah.jpg' => 'ใยขัดตัวทรงกลมและทรงรีจากใยบวบ',
	'eco/eco-ballpen.jpg' => 'ปากกาลูกลื่นด้ามดำ น้ำเงิน และขาว',
	'eco/eco-pencil.jpg' => 'ดินสอไม้หลายสี 5 แท่ง',
	'illus/special-care.jpg' => 'ภาพตัวอย่าง: หลอดและขวดสีขาวขนาดพกพากับฟองน้ำและผ้าขนหนู (รูปสต็อก Pexels รอรูปถ่ายจริง)',
);
$media = get_option( 'wt_seed_media', array() );
foreach ( $alts as $rel => $alt ) {
	if ( isset( $media[ $rel ] ) && get_post( $media[ $rel ] ) ) { continue; }
	$file = "$img_root/$rel";
	if ( ! file_exists( $file ) ) { $log[] = "missing $rel"; continue; }
	$tmp = wp_tempnam( basename( $file ) );
	copy( $file, $tmp );
	$id = media_handle_sideload( array( 'name' => 'old-site-' . str_replace( '/', '-', $rel ), 'tmp_name' => $tmp ), 0, $alt );
	if ( is_wp_error( $id ) ) { $log[] = $id->get_error_message(); continue; }
	update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	$media[ $rel ] = $id;
}
update_option( 'wt_seed_media', $media );
$log[] = 'media: ' . count( $media );

/* ---------- product cards ---------- */
foreach ( wt_default_groups() as $gslug => $gname ) { $gt = get_term_by( 'slug', $gslug, 'wt_product_group' ); if ( ! $gt ) { wp_insert_term( $gname, 'wt_product_group', array( 'slug' => $gslug ) ); } elseif ( $gt->name === $gslug || in_array( $gt->name, array( 'บรรจุภัณฑ์และการเติม', 'สินค้าพร้อมส่ง ไม่ติดโลโก้' ), true ) ) { wp_update_term( $gt->term_id, 'wt_product_group', array( 'name' => $gname ) ); } }
$cards = array(
	// group, title, excerpt, adjustable, status, hotel, hospital, image, order, note
	array( 'bath-body', 'แชมพู', 'ล้างออกง่าย เลือกกลิ่นให้เข้ากับห้องพักได้', 'กลิ่น · สี · ขนาด', 'available', 1, 1, 'products/tube-and-bottle-3.jpg', 10, '' ),
	array( 'bath-body', 'ครีมนวดผม', 'ผมนุ่ม จัดทรงง่าย กลิ่นเดียวกับแชมพู', 'กลิ่น · สี · ขนาด', 'available', 1, 0, 'products/tube-and-bottle-4.jpg', 20, '' ),
	array( 'bath-body', 'ครีมอาบน้ำ', 'ฟองนุ่ม อาบแล้วผิวไม่แห้งตึง', 'กลิ่น · สี · ขนาด', 'available', 1, 1, 'products/tube-and-bottle-2.jpg', 30, '' ),
	array( 'bath-body', 'โลชันบำรุงผิว', 'ซึมไว ไม่เหนอะหนะ กลิ่นอ่อนๆ', 'กลิ่น · สี · ขนาด', 'available', 1, 1, 'about/whoweare.jpg', 40, '' ),
	array( 'amenity-kits', 'ชุด Amenity ติดโลโก้ของคุณ', 'จัดของใช้ในห้องน้ำเป็นชุด บรรจุซองหรือกล่องที่พิมพ์โลโก้ของที่พักหรือโรงพยาบาล', 'รายการในชุด · วัสดุซอง · โลโก้', 'available', 1, 1, 'products/package-2.jpg', 10, '' ),
	array( 'amenity-kits', 'แปรงสีฟัน', 'ด้ามพลาสติก ไม้ไผ่ แป้งข้าวโพด หรือฟางข้าวสาลี', 'วัสดุ · ซอง · โลโก้', 'available', 1, 1, 'eco/eco-toothbrush.jpg', 20, '' ),
	array( 'amenity-kits', 'ยาสีฟัน', 'หลอดเล็กสำหรับห้องพัก บรรจุซองกระดาษ', 'ซอง', 'available', 1, 1, 'products/package-3.jpg', 30, '' ),
	array( 'amenity-kits', 'หวี', 'พลาสติก ไม้ไผ่ แป้งข้าวโพด หรือฟางข้าวสาลี', 'วัสดุ · ซอง · โลโก้', 'available', 1, 1, 'eco/eco-comb.jpg', 40, '' ),
	array( 'amenity-kits', 'มีดโกน', 'ด้ามพลาสติก ไม้ไผ่ แป้งข้าวโพด หรือฟางข้าวสาลี', 'วัสดุ · ซอง · โลโก้', 'available', 1, 1, 'eco/eco-razor.jpg', 50, '' ),
	array( 'amenity-kits', 'ครีมโกนหนวด', 'หลอดพลาสติกขนาดพกพา ใช้คู่กับมีดโกน', 'ซอง', 'available', 1, 1, 'eco/eco-shaving-cream.jpg', 60, '' ),
	array( 'amenity-kits', 'หมวกอาบน้ำ', 'พลาสติก หรือแป้งข้าวโพด', 'วัสดุ · ซอง', 'available', 1, 1, 'eco/eco-shower-cap.jpg', 70, '' ),
	array( 'amenity-kits', 'คอตตอนบัด', 'ก้านพลาสติก หรือก้านกระดาษ', 'วัสดุ · ซอง', 'available', 1, 1, 'eco/eco-cotton-bud.jpg', 80, '' ),
	array( 'amenity-kits', 'สำลี', 'แผ่นเหลี่ยม แผ่นกลม หรือสำลีก้อน', 'รูปทรง · ซอง', 'available', 1, 1, 'eco/eco-cotton-pad.jpg', 90, '' ),
	array( 'amenity-kits', 'ตะไบเล็บ', 'ไม้ไผ่หรือไม้', 'ซอง', 'available', 1, 0, 'eco/eco-nail-file.jpg', 100, '' ),
	array( 'amenity-kits', 'ชุดเย็บผ้า', 'ด้ายหลายสีพร้อมเข็ม บรรจุซองกระดาษ', 'ซอง', 'available', 1, 0, 'eco/eco-sewing-kit.jpg', 110, '' ),
	array( 'amenity-kits', 'สบู่ก้อน', 'ขนาดสำหรับห้องพัก ห่อพลาสติกหรือกระดาษ', 'การห่อ · โลโก้', 'available', 1, 1, 'eco/eco-soap.jpg', 120, '' ),
	array( 'amenity-kits', 'ถุงอนามัย', 'ถุงพลาสติกหรือกระดาษสำหรับทิ้งผ้าอนามัย', 'วัสดุ', 'available', 1, 1, 'products/accessories-2.jpg', 130, '' ),
	array( 'amenity-kits', 'แป้งฝุ่น', 'ไม่มีโลโก้ สกรีนโลโก้ หรือติดสติกเกอร์โลโก้', 'โลโก้', 'available', 1, 1, '', 140, '' ),
	array( 'amenity-kits', 'ถุงซักรีด', 'ถุงผ้าหูรูดสำหรับใส่เสื้อผ้าส่งซัก', 'วัสดุ · โลโก้', 'available', 1, 0, 'eco/eco-laundry-bag.jpg', 150, '' ),
	array( 'amenity-kits', 'ชุดล้างจาน', 'สำหรับห้องพักที่มีครัว เช่น วิลล่าหรือเซอร์วิสอพาร์ตเมนต์', '', 'available', 1, 0, '', 160, '' ),
	array( 'kids', 'ชุดของใช้สำหรับเด็ก', 'แปรงสีฟัน ยาสีฟัน หวี และผลิตภัณฑ์อาบน้ำสำหรับแขกตัวเล็ก เลือกแบบไม่มีโลโก้ หรือติดโลโก้ของที่พัก', 'รายการในชุด · โลโก้', 'available', 1, 1, 'products/kid-set-1.jpg', 10, '' ),
	array( 'kids', 'แปรงสีฟันเด็ก', 'ขนาดสำหรับเด็ก มีแบบไม่มีโลโก้และแบบมีแบรนด์', 'โลโก้', 'available', 1, 1, '', 20, '' ),
	array( 'kids', 'ยาสีฟันเด็ก', 'ยาสีฟันสำหรับเด็ก แบบมีแบรนด์', '', 'available', 1, 1, '', 30, '' ),
	array( 'kids', 'หวีเด็ก', 'ขนาดเล็ก จับถนัดมือเด็ก', '', 'available', 1, 1, '', 40, '' ),
	array( 'kids', 'ผลิตภัณฑ์อาบน้ำสำหรับเด็ก', 'แชมพูและสบู่เหลวสำหรับเด็ก มีแบบไม่มีโลโก้และแบบมีแบรนด์', 'โลโก้', 'available', 1, 1, 'products/kid-set-2.jpg', 50, '' ),
	array( 'special-care', 'โฟมล้างหน้า', 'ให้แขกดูแลผิวได้ครบขั้นตอน', '', 'request', 1, 0, 'illus/facial-foam.jpg', 10, '' ),
	array( 'special-care', 'ลิปบาล์ม', 'ของชิ้นเล็กสำหรับเมืองอากาศแห้ง หรือแขกที่เพิ่งลงเครื่อง', '', 'request', 1, 1, 'illus/lip-balm.jpg', 20, '' ),
	array( 'special-care', 'น้ำยาบ้วนปาก', 'เติมชุดดูแลช่องปากในห้องพักหรือห้องผู้ป่วยให้ครบ', '', 'request', 1, 1, 'illus/mouthwash.jpg', 30, '' ),
	array( 'special-care', 'ผลิตภัณฑ์กันยุง', 'สำหรับรีสอร์ตริมทะเล หรือที่พักใกล้ธรรมชาติ', '', 'request', 1, 0, 'illus/mosquito-repellent.jpg', 40, '' ),
	array( 'special-care', 'ครีมกันแดด', 'สำหรับรีสอร์ตที่แขกใช้เวลากลางแจ้ง', '', 'request', 1, 0, 'illus/sunscreen.jpg', 50, '' ),
	array( 'special-care', 'ใยขัดตัว', 'ใยขัดผิวสำหรับห้องอาบน้ำและสปา', '', 'request', 1, 0, 'eco/eco-loofah.jpg', 60, '' ),
	array( 'special-care', 'เกลือแช่ตัว', 'สำหรับห้องที่มีอ่างอาบน้ำ หรือห้องทรีตเมนต์สปา', '', 'request', 1, 0, '', 70, '' ),
	array( 'special-care', 'ที่อุดหู', 'ช่วยให้แขกหรือผู้ป่วยนอนหลับได้สบายขึ้น', '', 'request', 1, 1, '', 80, '' ),
	array( 'special-care', 'แผ่นเช็ดเครื่องสำอาง', 'แผ่นเช็ดทำความสะอาดเครื่องสำอางสำหรับห้องพัก', '', 'request', 1, 0, 'eco/eco-cotton-pad.jpg', 90, '' ),
	array( 'slippers', 'รองเท้าแบบใช้ครั้งเดียว', 'น้ำหนักเบา แบบเปิดหรือปิดหัว เลือกผ้าและพื้นรองเท้าได้หลายแบบ', 'วัสดุ · พื้นรองเท้า · โลโก้', 'available', 1, 1, 'eco/eco-slippers.jpg', 10, '' ),
	array( 'slippers', 'รองเท้าแบบซักใช้ซ้ำได้', 'ผ้าหนาขึ้น เช่น ผ้าขนหนูหรือกำมะหยี่ ซักแล้วนำกลับมาใช้ได้', 'วัสดุ · พื้นรองเท้า · โลโก้', 'available', 1, 1, 'eco/eco-slipper-velour.jpg', 20, '' ),
	array( 'packaging', 'ขวดและหลอด', 'ขวด PET HDPE PETG แก้ว หรืออะลูมิเนียม และหลอดบีบ ขนาดประมาณ 30–500 มล.', 'ทรง · ฝา · ขนาด · การพิมพ์', 'available', 1, 1, 'eco/eco-mini-bottles.jpg', 10, '' ),
	array( 'packaging', 'ซองและกล่องสำหรับชุด Amenity', 'กระดาษคราฟท์ กระดาษคอตตอน กระดาษหินสีดำ หรือกล่องชานอ้อย พิมพ์ ปั๊มทอง-เงิน หรือปั๊มนูนโลโก้ได้', 'วัสดุ · โลโก้', 'available', 1, 1, 'eco/eco-sugarcane-set.jpg', 20, '' ),
	array( 'packaging', 'ขวดกดติดผนัง', 'ขายึดแบบล็อกกุญแจ ขันสกรู หรือติดเทปกาว ใช้กับขวดปั๊มขนาดใหญ่', 'รุ่นขายึด · สี', 'available', 1, 1, 'eco/eco-dispenser.jpg', 30, '' ),
	array( 'packaging', 'แกลลอนและถุงเติม', 'แกลลอน 3.8–5 ลิตร และถุงเติมมีจุก 1–2.5 ลิตร สำหรับเติมขวดกด', 'ขนาด', 'available', 1, 1, 'eco/eco-refill-barrels.jpg', 40, '' ),
	array( 'packaging', 'กระเป๋าใส่ชุด Amenity', 'PVC ผ้าแคนวาส หรือผ้าสปันบอนด์ (non-woven)', 'วัสดุ · โลโก้', 'available', 1, 1, '', 50, '' ),
	array( 'imported-brands', 'Of the Islands', '[ขาด: รายการสินค้าที่นำเข้า]', '', 'pending', 1, 0, 'products/amenity-set-1.jpg', 10, 'รอสิทธิ์ใช้ชื่อ/ภาพ' ),
	array( 'imported-brands', 'Margy\'s', '[ขาด: รายการสินค้าที่นำเข้า]', '', 'pending', 1, 0, 'products/amenity-set-2.jpg', 20, 'รอสิทธิ์ใช้ชื่อ/ภาพ' ),
	array( 'ready-line', 'Friss', 'ซองกระดาษคราฟท์ · แปรงสีฟันพร้อมยาสีฟัน ชุดโกนหนวด หวี หมวกอาบน้ำ คอตตอนบัด สำลี ชุดเย็บผ้า ถุงอนามัย ใยขัดตัว', '', 'available', 1, 1, 'eco/eco-kraft-set.jpg', 10, 'ต้องยืนยัน R-01 รายการในชุด' ),
	array( 'ready-line', 'The Pure', 'ซองสีขาว · แปรงสีฟันพร้อมยาสีฟัน ชุดโกนหนวด หวี หมวกอาบน้ำ คอตตอนบัด สำลี ชุดเย็บผ้า ถุงอนามัย', '', 'available', 1, 1, 'eco/eco-cotton-paper-set.jpg', 20, 'ต้องยืนยัน R-01 รายการในชุด' ),
	array( 'ready-line', 'Picasso', 'ซอง CPE โทนเทาและเงิน หรือ HDPE · แปรงสีฟันพร้อมยาสีฟัน ชุดโกนหนวด หวี หมวกอาบน้ำ คอตตอนบัด ถุงอนามัย', '', 'available', 1, 1, 'products/package-3.jpg', 30, 'ต้องยืนยัน R-01 รายการในชุด' ),
	array( 'amenity-kits', 'ชุดดูแลรองเท้า', 'ที่ช้อนรองเท้า ฟองน้ำขัดรองเท้า และผ้าเช็ดรองเท้า', 'วัสดุ · โลโก้', 'available', 1, 0, 'eco/eco-shoe-horn.jpg', 155, '' ),
	array( 'amenity-kits', 'ปากกาและดินสอ', 'ปากกาลูกลื่นและดินสอไม้สำหรับโต๊ะทำงานในห้องพัก พิมพ์โลโก้ได้', 'สี · โลโก้', 'available', 1, 0, 'eco/eco-ballpen.jpg', 158, '' ),
	array( 'kids', 'รองเท้าเด็ก', 'รองเท้าลายการ์ตูนขนาดเด็ก สำหรับแขกตัวเล็ก', '', 'available', 1, 1, 'eco/eco-slipper-duck-kids.jpg', 45, '' ),
	array( 'slippers', 'รองเท้าผ้าวาฟเฟิล', 'ผ้าลายวาฟเฟิลสีขาว ดูสะอาดเรียบร้อย', 'พื้นรองเท้า · โลโก้', 'available', 1, 1, 'eco/eco-slipper-waffle.jpg', 30, '' ),
	array( 'slippers', 'รองเท้าผ้าขนหนู', 'ผ้าขนหนูนุ่ม เข้าชุดกับผ้าเช็ดตัวในห้อง', 'พื้นรองเท้า · โลโก้', 'available', 1, 1, 'eco/eco-slipper-terry.jpg', 40, '' ),
	array( 'slippers', 'รองเท้าผ้าเส้นใยชานอ้อย', 'โทนธรรมชาติสีครีม สำหรับที่พักที่เน้นวัสดุธรรมชาติ', 'พื้นรองเท้า · โลโก้', 'available', 1, 0, 'eco/eco-slipper-sugarcane.jpg', 50, '' ),
	array( 'slippers', 'รองเท้าโทนน้ำตาล', 'ผ้าสีน้ำตาลลายไม้ก๊อก ให้บรรยากาศอบอุ่น', 'พื้นรองเท้า · โลโก้', 'available', 1, 0, 'eco/eco-slipper-cork.jpg', 60, '' ),
	array( 'packaging', 'ขวดปั๊ม 300–500 มล.', 'ขวดปั๊มขนาดใหญ่ใส ขุ่น หรือสีชา สำหรับวางในห้องอาบน้ำหรือใส่ขาแขวน', 'สี · ขนาด · การพิมพ์', 'available', 1, 1, 'eco/eco-pump-bottles-amber.jpg', 12, '' ),
	array( 'packaging', 'ขวดอะลูมิเนียม', 'ขวดโลหะดูพรีเมียม ขนาดเล็กและขวดปั๊ม', 'ขนาด · การพิมพ์', 'available', 1, 0, 'eco/eco-aluminium-bottles.jpg', 14, '' ),
	array( 'packaging', 'ขวดและหลอดผสมฟางข้าวสาลี', 'วัสดุผสมเส้นใยฟางข้าวสาลี โทนธรรมชาติ', 'ขนาด · การพิมพ์', 'available', 1, 0, 'eco/eco-straw-tube-bottle.jpg', 16, '' ),
	array( 'packaging', 'ขาแขวนสเตนเลส', 'ขาแขวนขวดปั๊มสเตนเลส สีเงินหรือสีดำ แบบ 1–3 ขวด', 'สี · จำนวนขวด', 'available', 1, 1, 'eco/eco-dispenser-steel.jpg', 32, '' ),
	array( 'packaging', 'ขาแขวน ABS แบบล็อก', 'ขาแขวนพลาสติก ABS ล็อกขวดด้วยกุญแจ กันขวดหาย', 'จำนวนขวด', 'available', 1, 1, 'eco/eco-dispenser-abs-lock.jpg', 34, '' ),
	array( 'packaging', 'ชั้นวางขวดติดผนัง', 'ชั้นวางขวดแบบ 1–3 ช่อง หรือโครงแขวนคู่', 'จำนวนช่อง', 'available', 1, 0, 'eco/eco-dispenser-shelf.jpg', 36, '' ),
	array( 'ready-line', 'ขวดเล็กพร้อมส่ง', 'แชมพู ครีมนวด ครีมอาบน้ำ และโลชัน ขวดเล็ก 30–40 มล. ไม่ติดโลโก้', '', 'available', 1, 1, 'eco/eco-mini-bottles.jpg', 40, '' ),
	array( 'ready-line', 'หลอดพร้อมส่ง', 'แชมพู ครีมนวด ครีมอาบน้ำ และโลชัน แบบหลอดบีบ ไม่ติดโลโก้', '', 'available', 1, 1, 'eco/eco-tubes.jpg', 50, '' ),
	array( 'ready-line', 'สบู่ก้อนพร้อมส่ง', 'สบู่ก้อนกลมขนาดห้องพัก ห่อพลาสติกหรือกระดาษ', '', 'available', 1, 1, 'eco/eco-soap.jpg', 60, '' ),
	array( 'ready-line', 'ของใช้ชิ้นเดี่ยวพร้อมส่ง', 'แปรงสีฟัน หวี มีดโกน หมวกอาบน้ำ คอตตอนบัด สั่งแยกชิ้นตามที่ต้องการ', 'วัสดุ', 'available', 1, 1, 'eco/eco-toothbrush.jpg', 70, '' ),
	array( 'ready-line', 'รองเท้าพร้อมส่ง', 'รองเท้าแบบใช้ครั้งเดียวสีขาว ไม่ติดโลโก้', '', 'available', 1, 1, 'eco/eco-slipper-cloth.jpg', 80, '' ),
	array( 'ready-line', 'แกลลอนเติมพร้อมส่ง', 'แชมพูและครีมอาบน้ำแกลลอน 3.8–5 ลิตร สำหรับเติมขวดกด', '', 'available', 1, 1, 'eco/eco-refill-barrels.jpg', 90, '' ),
);
$en_cards = array(
	'แชมพู' => array( 'Shampoo', 'Rinses easily, in a scent chosen for your rooms', 'scent · colour · size' ),
	'ครีมนวดผม' => array( 'Conditioner', 'Soft, manageable hair; scent matched to the shampoo', 'scent · colour · size' ),
	'ครีมอาบน้ำ' => array( 'Shower gel', 'Soft lather that leaves skin comfortable', 'scent · colour · size' ),
	'โลชันบำรุงผิว' => array( 'Body lotion', 'Absorbs quickly, never sticky, lightly scented', 'scent · colour · size' ),
	'ชุด Amenity ติดโลโก้ของคุณ' => array( 'Amenity set with your logo', 'Bathroom items assembled as a set, in sleeves or boxes printed with your property or hospital logo', 'set contents · sleeve material · logo' ),
	'แปรงสีฟัน' => array( 'Toothbrush', 'Plastic, bamboo, corn-starch or wheat-straw handle', 'material · sleeve · logo' ),
	'ยาสีฟัน' => array( 'Toothpaste', 'Small tube for guest rooms, in a paper sleeve', 'sleeve' ),
	'หวี' => array( 'Comb', 'Plastic, bamboo, corn starch or wheat straw', 'material · sleeve · logo' ),
	'มีดโกน' => array( 'Razor', 'Plastic, bamboo, corn-starch or wheat-straw handle', 'material · sleeve · logo' ),
	'ครีมโกนหนวด' => array( 'Shaving cream', 'Travel-size plastic tube to go with the razor', 'sleeve' ),
	'หมวกอาบน้ำ' => array( 'Shower cap', 'Plastic or corn starch', 'material · sleeve' ),
	'คอตตอนบัด' => array( 'Cotton buds', 'Plastic or paper stems', 'material · sleeve' ),
	'สำลี' => array( 'Cotton pads & balls', 'Square pads, round pads or cotton balls', 'shape · sleeve' ),
	'ตะไบเล็บ' => array( 'Nail file', 'Bamboo or wood', 'sleeve' ),
	'ชุดเย็บผ้า' => array( 'Sewing kit', 'Several thread colours with needles, in a paper sleeve', 'sleeve' ),
	'สบู่ก้อน' => array( 'Bar soap', 'Guest-room size, plastic or paper wrap', 'wrap · logo' ),
	'ถุงอนามัย' => array( 'Sanitary bag', 'Plastic or paper disposal bag', 'material' ),
	'แป้งฝุ่น' => array( 'Talcum powder', 'Plain, screen-printed logo or logo sticker', 'logo' ),
	'ถุงซักรีด' => array( 'Laundry bag', 'Drawstring bag for guest laundry', 'material · logo' ),
	'ชุดล้างจาน' => array( 'Dishwashing set', 'For rooms with a kitchen, such as villas and serviced apartments', '' ),
	'ชุดของใช้สำหรับเด็ก' => array( 'Kids amenity set', 'Toothbrush, toothpaste, comb and bath products for young guests, plain or with your logo', 'set contents · logo' ),
	'แปรงสีฟันเด็ก' => array( 'Kids toothbrush', 'Child size, plain or branded', 'logo' ),
	'ยาสีฟันเด็ก' => array( 'Kids toothpaste', 'Toothpaste for children, branded', '' ),
	'หวีเด็ก' => array( 'Kids comb', 'Small, easy for children to hold', '' ),
	'ผลิตภัณฑ์อาบน้ำสำหรับเด็ก' => array( 'Kids bath products', 'Shampoo and body wash for children, plain or branded', 'logo' ),
	'โฟมล้างหน้า' => array( 'Facial foam', 'So guests can follow their full skincare routine', '' ),
	'ลิปบาล์ม' => array( 'Lip balm', 'A small comfort for dry climates or guests fresh off a flight', '' ),
	'น้ำยาบ้วนปาก' => array( 'Mouthwash', 'Completes the oral-care kit in guest and patient rooms', '' ),
	'ผลิตภัณฑ์กันยุง' => array( 'Mosquito repellent', 'For beach and nature resorts', '' ),
	'ครีมกันแดด' => array( 'Sunscreen', 'For resorts where guests spend time outdoors', '' ),
	'ใยขัดตัว' => array( 'Loofah', 'Body scrubber for bathrooms and spas', '' ),
	'เกลือแช่ตัว' => array( 'Bath salt', 'For rooms with a bathtub or spa treatment rooms', '' ),
	'ที่อุดหู' => array( 'Earplugs', 'Helps guests and patients sleep more comfortably', '' ),
	'แผ่นเช็ดเครื่องสำอาง' => array( 'Makeup remover pads', 'Cleansing pads for removing makeup in the room', '' ),
	'รองเท้าแบบใช้ครั้งเดียว' => array( 'Single-use slippers', 'Lightweight, open or closed toe, in a choice of fabrics and soles', 'material · sole · logo' ),
	'รองเท้าแบบซักใช้ซ้ำได้' => array( 'Washable slippers', 'Thicker fabric such as terry or velour, washable and reusable', 'material · sole · logo' ),
	'ขวดและหลอด' => array( 'Bottles & tubes', 'PET, HDPE, PETG, glass or aluminium bottles and squeeze tubes, roughly 30–500 ml', 'shape · cap · size · print' ),
	'ซองและกล่องสำหรับชุด Amenity' => array( 'Sleeves & boxes for amenity sets', 'Kraft, cotton paper, black stone paper or sugarcane board, with printed, gold/silver foil or embossed logo', 'material · logo' ),
	'ขวดกดติดผนัง' => array( 'Wall dispensers', 'Lockable, screw-fixed or adhesive holders for large pump bottles', 'holder type · colour' ),
	'แกลลอนและถุงเติม' => array( 'Refill gallons & pouches', '3.8–5 L gallons and 1–2.5 L spouted pouches for refilling dispensers', 'size' ),
	'กระเป๋าใส่ชุด Amenity' => array( 'Amenity bags', 'PVC, canvas or non-woven', 'material · logo' ),
	'Of the Islands' => array( 'Of the Islands', '[MISSING: imported product list]', '' ),
	'Margy\'s' => array( 'Margy\'s', '[MISSING: imported product list]', '' ),
	'Friss' => array( 'Friss', 'Kraft sachets · toothbrush with toothpaste, shaving kit, comb, shower cap, cotton buds, cotton pads, sewing kit, sanitary bag, loofah', '' ),
	'The Pure' => array( 'The Pure', 'White sachets · toothbrush with toothpaste, shaving kit, comb, shower cap, cotton buds, cotton pads, sewing kit, sanitary bag', '' ),
	'Picasso' => array( 'Picasso', 'Grey or silver CPE sachets, or HDPE · toothbrush with toothpaste, shaving kit, comb, shower cap, cotton buds, sanitary bag', '' ),
	'ชุดดูแลรองเท้า' => array( 'Shoe care', 'Shoe horn, shoe-shine sponge and shoe mitt', 'material · logo' ),
	'ปากกาและดินสอ' => array( 'Pens & pencils', 'Ballpoint pens and wooden pencils for the room desk, logo printing available', 'colour · logo' ),
	'รองเท้าเด็ก' => array( 'Kids slippers', 'Child-size slippers with a playful design', '' ),
	'รองเท้าผ้าวาฟเฟิล' => array( 'Waffle slippers', 'White waffle fabric for a clean, crisp look', 'sole · logo' ),
	'รองเท้าผ้าขนหนู' => array( 'Terry slippers', 'Soft terry that matches the towels in the room', 'sole · logo' ),
	'รองเท้าผ้าเส้นใยชานอ้อย' => array( 'Sugarcane-fibre slippers', 'Natural cream tone for properties that favour natural materials', 'sole · logo' ),
	'รองเท้าโทนน้ำตาล' => array( 'Cork-look slippers', 'Brown cork-look fabric for a warmer feel', 'sole · logo' ),
	'ขวดปั๊ม 300–500 มล.' => array( 'Pump bottles 300–500 ml', 'Large clear, frosted or amber pump bottles for the shower or wall holders', 'colour · size · print' ),
	'ขวดอะลูมิเนียม' => array( 'Aluminium bottles', 'Premium metal bottles, minis and pump sizes', 'size · print' ),
	'ขวดและหลอดผสมฟางข้าวสาลี' => array( 'Wheat-straw bottles & tubes', 'Bottles and tubes blended with wheat-straw fibre in a natural tone', 'size · print' ),
	'ขาแขวนสเตนเลส' => array( 'Stainless-steel holders', 'Silver or black stainless holders for 1–3 pump bottles', 'colour · bottle count' ),
	'ขาแขวน ABS แบบล็อก' => array( 'Lockable ABS holders', 'ABS holders that lock the bottle with a key', 'bottle count' ),
	'ชั้นวางขวดติดผนัง' => array( 'Wall bottle shelves', 'Shelves for 1–3 bottles, or double hanging frames', 'slots' ),
	'ขวดเล็กพร้อมส่ง' => array( 'Ready-to-ship minis', 'Shampoo, conditioner, shower gel and lotion in 30–40 ml unbranded bottles', '' ),
	'หลอดพร้อมส่ง' => array( 'Ready-to-ship tubes', 'Shampoo, conditioner, shower gel and lotion in unbranded squeeze tubes', '' ),
	'สบู่ก้อนพร้อมส่ง' => array( 'Ready-to-ship bar soap', 'Round guest-room soap, plastic or paper wrap', '' ),
	'ของใช้ชิ้นเดี่ยวพร้อมส่ง' => array( 'Ready-to-ship single items', 'Toothbrushes, combs, razors, shower caps and cotton buds, ordered item by item', 'material' ),
	'รองเท้าพร้อมส่ง' => array( 'Ready-to-ship slippers', 'White single-use slippers, unbranded', '' ),
	'แกลลอนเติมพร้อมส่ง' => array( 'Ready-to-ship refill gallons', 'Shampoo and shower gel in 3.8–5 L gallons for refilling dispensers', '' ),
);
$existing = get_posts( array( 'post_type' => 'wt_product_card', 'numberposts' => -1, 'post_status' => 'any', 'fields' => 'ids' ) );
foreach ( $existing as $pid ) { wp_delete_post( $pid, true ); }
foreach ( $cards as $c ) {
	list( $group, $title, $excerpt, $adj, $status, $hotel, $hosp, $img, $order, $note ) = $c;
	$pid = wp_insert_post( array( 'post_type' => 'wt_product_card', 'post_status' => 'publish', 'post_title' => $title, 'post_excerpt' => $excerpt, 'menu_order' => $order ) );
	wp_set_object_terms( $pid, $group, 'wt_product_group' );
	update_post_meta( $pid, 'wt_status', $status );
	update_post_meta( $pid, 'wt_adjustable', $adj );
	update_post_meta( $pid, 'wt_use_hotel', (bool) $hotel );
	update_post_meta( $pid, 'wt_use_hospital', (bool) $hosp );
	update_post_meta( $pid, 'wt_note', $note );
	if ( isset( $media[ $img ] ) ) { set_post_thumbnail( $pid, $media[ $img ] ); }
	if ( isset( $en_cards[ $title ] ) ) { update_post_meta( $pid, 'wt_title_en', $en_cards[ $title ][0] ); update_post_meta( $pid, 'wt_excerpt_en', $en_cards[ $title ][1] ); update_post_meta( $pid, 'wt_adjustable_en', $en_cards[ $title ][2] ); }
}
$log[] = 'cards: ' . count( $cards );

/* ---------- pages ---------- */
$pages = array(
	// slug => [title, file, template, seo title, meta]
	'home'                => array( 'หน้าแรก', 'home.html', 'page-hub', 'ของใช้ในโรงแรมและโรงพยาบาล พร้อมส่ง ผลิตในไทย | Westons Thai', 'ชุด Amenity แชมพู ครีมอาบน้ำ ของใช้ในห้องน้ำ และรองเท้า สำหรับฝ่ายจัดซื้อโรงแรม รีสอร์ต สปา และโรงพยาบาล มีสินค้าพร้อมส่งไม่ติดโลโก้ และชุดติดโลโก้ที่ผลิตในไทย' ),
	'products'            => array( 'สินค้า', 'products.html', 'page-hub', 'สินค้า amenity โรงแรมและโรงพยาบาล แชมพู ชุดของใช้ รองเท้า | Westons', 'ผลิตภัณฑ์อาบน้ำและดูแลผิว ชุด amenity รองเท้า บรรจุภัณฑ์ และสินค้าพร้อมส่งไม่ติดโลโก้ สำหรับโรงแรม รีสอร์ต สปา โรงพยาบาล และที่พักขนาดเล็กในไทย' ),
	'hotels'              => array( 'โรงแรมและโรงพยาบาล', 'hotels.html', 'page-hub', 'ชุด Amenity โรงแรม สปา และชุดของใช้ผู้ป่วยโรงพยาบาล | Westons', 'ชุด Amenity สำหรับโรงแรม รีสอร์ต และสปา ปรับกลิ่นและสีตามแบรนด์ พร้อมชุดของใช้ผู้ป่วยและรองเท้าสำหรับโรงพยาบาล ให้ผู้ป่วยรู้สึกได้รับการดูแลตั้งแต่วันแรก' ),
	'ready-to-ship'       => array( 'สินค้าพร้อมส่ง', 'ready-to-ship.html', 'page-hub', 'ของใช้ในโรงแรมพร้อมส่ง ชุด Amenity โรงแรม โรงพยาบาล | Westons', 'ของใช้ในโรงแรมและโรงพยาบาลพร้อมส่ง ชุด Amenity ไม่ติดโลโก้ แปรงสีฟัน หวี สบู่ ขวดเล็ก และรองเท้า ไม่ต้องรอผลิต ขอใบเสนอราคาทาง LINE โทร หรือฟอร์ม' ),
	'eco-friendly'        => array( 'Eco-friendly', 'eco-friendly.html', 'page-hub', 'ของใช้ในโรงแรม Eco-friendly ไม้ไผ่ ซองกระดาษ ระบบเติม | Westons', 'ของใช้ในโรงแรมและโรงพยาบาลที่ลดพลาสติก แปรงสีฟันไม้ไผ่ หวีฟางข้าวสาลี หมวกอาบน้ำแป้งข้าวโพด ซองกระดาษ กล่องชานอ้อย และระบบเติมลดขวดเล็ก จาก Westons' ),
	'product-development' => array( 'ร่วมพัฒนาผลิตภัณฑ์ (OEM)', 'product-development.html', 'page-hub', 'รับผลิตแชมพู ครีมอาบน้ำ OEM ตั้งแต่สูตรถึงบรรจุภัณฑ์ | Westons', 'รับพัฒนาและผลิตแชมพู ครีมอาบน้ำ และผลิตภัณฑ์ดูแลผิวภายใต้แบรนด์ของคุณ ตั้งแต่สูตร กลิ่น สี ตัวอย่าง บรรจุภัณฑ์ ฉลาก จนถึงการผลิต' ),
	'about'               => array( 'เกี่ยวกับเรา', 'about.html', '', 'เกี่ยวกับ Westons (Thai) Co., Ltd.', 'รู้จัก Westons (Thai) Co., Ltd. ผู้พัฒนาและผลิตผลิตภัณฑ์ดูแลผิวและชุด Amenity สำหรับโรงแรมและโรงพยาบาลในไทย ดูแลตั้งแต่สูตรจนถึงชุดที่วางในห้องพัก' ),
	'contact'             => array( 'ติดต่อเรา', 'contact.html', '', 'ติดต่อ Westons ขอตัวอย่างหรือใบเสนอราคา | Westons Thai', 'ติดต่อ Westons ทางฟอร์ม LINE โทร หรืออีเมล ขอตัวอย่างหรือใบเสนอราคาได้ แม้ยังไม่มีสเปกครบ' ),
	'privacy-policy'      => array( 'นโยบายความเป็นส่วนตัว', 'privacy-policy.html', '', 'นโยบายความเป็นส่วนตัว | Westons Thai', 'นโยบายการเก็บ ใช้ และคุ้มครองข้อมูลส่วนบุคคลที่ส่งผ่านเว็บไซต์ของ Westons (Thai) Co., Ltd. และช่องทางติดต่อเรื่องข้อมูลส่วนบุคคล' ),
);
$h1 = array( 'about' => 'ดูแลทุกรายละเอียด ตั้งแต่สูตรจนถึงชุดที่วางในห้องพัก', 'contact' => 'คุยกับเราได้เลย แม้ยังไม่มีสเปกครบ' );
foreach ( $pages as $slug => $p ) {
	list( $title, $file, $template, $seo_title, $meta ) = $p;
	$html = file_get_contents( "$content_root/$file" );
	$html = preg_replace_callback( '/\{\{(img|id):([^}]+)\}\}/', function ( $m ) use ( $media ) {
		$id = $media[ $m[2] ] ?? 0;
		return 'img' === $m[1] ? ( $id ? wp_get_attachment_image_url( $id, 'large' ) : '' ) : $id;
	}, $html );
	$existing = get_page_by_path( $slug, OBJECT, 'page' );
	$args = array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug, 'post_title' => $h1[ $slug ] ?? $title, 'post_content' => $html );
	if ( $existing ) { $args['ID'] = $existing->ID; $pid = wp_update_post( $args ); } else { $pid = wp_insert_post( $args ); }
	if ( $template ) { update_post_meta( $pid, '_wp_page_template', $template ); } else { delete_post_meta( $pid, '_wp_page_template' ); }
	update_post_meta( $pid, 'wt_seo_title', $seo_title );
	update_post_meta( $pid, 'wt_meta_description', $meta );
	update_post_meta( $pid, 'wt_nav_title', $title );
	if ( 'home' === $slug ) { update_option( 'show_on_front', 'page' ); update_option( 'page_on_front', $pid ); }
}
foreach ( array( 'hospitals', 'en/hospitals' ) as $old ) { $o = get_page_by_path( $old, OBJECT, 'page' ); if ( $o ) { wp_trash_post( $o->ID ); } } // v0.14 รวมเข้ากับหน้าโรงแรม
$log[] = 'pages: ' . count( $pages );

/* ---------- หน้าภาษาอังกฤษใต้ /en/ (ร่างแปล รอตรวจ) + ผูกคู่หน้า ---------- */
$en_pages = array(
	'home'                => array( 'Home', 'page-hub-en', 'Hotel & Hospital Amenities, Ready to Ship, Made in Thailand | Westons', 'Amenity sets, shampoo, shower gel, bathroom items and slippers for hotel and hospital procurement: ready-to-ship unbranded items or branded sets made in Thailand.', 'Room amenities, ready to ship, no production wait' ),
	'products'            => array( 'Products', 'page-hub-en', 'Hotel & Hospital Amenities: Shampoo, Kits, Slippers | Westons', 'Bath & body, amenity kits, slippers, packaging and ready-to-ship unbranded items for hotels, resorts, spas and hospitals in Thailand.', 'Products for guest rooms and patient rooms' ),
	'hotels'              => array( 'Hotels & Hospitals', 'page-hub-en', 'Hotel & Spa Amenities and Patient Amenity Kits for Hospitals | Westons', 'Amenity sets for hotels, resorts and spas matched to your brand, plus patient amenity kits and slippers for hospitals, so patients feel cared for from day one.', 'Room amenities guests remember and patients can rely on' ),
	'ready-to-ship'       => array( 'Ready to ship', 'page-hub-en', 'Ready-to-Ship Hotel & Hospital Amenities in Thailand | Westons', 'Unbranded hotel and hospital amenities ready to ship: amenity sets, toothbrushes, combs, soap, minis and slippers with no production wait. Request a quote.', 'Hotel & Hospital Amenities, Ready to Ship' ),
	'eco-friendly'        => array( 'Eco-friendly', 'page-hub-en', 'Eco-friendly Hotel Amenities: Bamboo, Paper Sleeves, Refill | Westons', 'Hotel and hospital amenities with less plastic: bamboo toothbrushes, wheat-straw combs, corn-starch shower caps, paper sleeves and a refill system, from Westons.', 'Hotel amenities with less plastic, and guests who feel just as looked after' ),
	'product-development' => array( 'Co-development (OEM)', 'page-hub-en', 'Private-Label Shampoo & Amenities, Formula to Packaging | Westons', 'Develop shampoo, shower gel and skin care under your own brand, from formula, scent and colour to samples, packaging, labels and production.', 'Start from how you want guests to feel, and develop the product together' ),
	'about'               => array( 'About', 'page-en', 'About Westons (Thai) Co., Ltd.', 'Meet Westons (Thai) Co., Ltd., developing skin care and amenity kits for hotels and hospitals in Thailand, from the formula to the kit in the room.', 'Every detail, from the formula to the kit in the room' ),
	'contact'             => array( 'Contact', 'page-en', 'Request Samples or a Quote for Your Property | Westons', 'Contact Westons by form, LINE, phone or email to request samples or a quote. You don\'t need a full spec to start.', 'Talk to us, even without a full spec' ),
	'privacy-policy'      => array( 'Privacy policy', 'page-en', 'Privacy Policy, Westons (Thai) Co., Ltd. | Westons', 'How Westons (Thai) Co., Ltd. collects, uses and protects personal data submitted through this website, and how to contact us about it.', 'Privacy policy' ),
);
$en_root = get_page_by_path( 'en', OBJECT, 'page' );
$en_root_id = $en_root ? $en_root->ID : 0;
foreach ( $en_pages as $slug => $e ) {
	list( $nav, $template, $seo_title, $meta, $h1_en ) = $e;
	$file = "$content_root/en/$slug.html";
	if ( ! file_exists( $file ) ) { continue; }
	$html = preg_replace_callback( '/\{\{(img|id):([^}]+)\}\}/', function ( $m ) use ( $media ) {
		$id = $media[ $m[2] ] ?? 0;
		return 'img' === $m[1] ? ( $id ? wp_get_attachment_image_url( $id, 'large' ) : '' ) : $id;
	}, file_get_contents( $file ) );
	$path = 'home' === $slug ? 'en' : "en/$slug";
	$existing = get_page_by_path( $path, OBJECT, 'page' );
	$args = array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => 'home' === $slug ? 'en' : $slug, 'post_title' => $h1_en, 'post_content' => $html, 'post_parent' => 'home' === $slug ? 0 : $en_root_id );
	if ( $existing ) { $args['ID'] = $existing->ID; $pid = wp_update_post( $args ); } else { $pid = wp_insert_post( $args ); }
	if ( 'home' === $slug ) { $en_root_id = $pid; }
	update_post_meta( $pid, '_wp_page_template', $template );
	update_post_meta( $pid, 'wt_seo_title', $seo_title );
	update_post_meta( $pid, 'wt_meta_description', $meta );
	update_post_meta( $pid, 'wt_nav_title', $nav );
	update_post_meta( $pid, 'wt_lang', 'en' );
	$th = get_page_by_path( $slug, OBJECT, 'page' );
	if ( $th ) {
		update_post_meta( $pid, 'wt_th_url', get_permalink( $th ) );
		update_post_meta( $th->ID, 'wt_en_url', get_permalink( $pid ) );
	}
}
$log[] = 'en pages: ' . count( $en_pages );

/* ---------- บทความ: หน้า /articles/ + ร่าง 4 บทความ (draft) ---------- */
$art = get_page_by_path( 'articles', OBJECT, 'page' );
$art_id = $art ? $art->ID : wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => 'articles', 'post_title' => 'บทความ', 'post_content' => '' ) );
update_post_meta( $art_id, 'wt_seo_title', 'บทความ: วิธีเลือกของใช้ในโรงแรมและโรงพยาบาล | Westons Thai' );
update_post_meta( $art_id, 'wt_meta_description', 'คลังความรู้สำหรับผู้ดูแลที่พักและโรงพยาบาล วิธีเลือกแชมพู ครีมอาบน้ำ ชุดของใช้ และบรรจุภัณฑ์' );
update_post_meta( $art_id, 'wt_nav_title', 'บทความ' );
update_option( 'page_for_posts', $art_id );
$drafts = array(
	array( 'เช็กลิสต์ของใช้ในห้องพักโรงแรม ต้องมีอะไรบ้าง', 'amenity-checklist-hotel-room', 'คำค้นเป้าหมาย: amenity มีอะไรบ้าง / ของใช้ในห้องพักโรงแรม ต้องมีอะไรบ้าง', array( 'ของใช้ในห้องน้ำ (แชมพู ครีมอาบน้ำ ครีมนวด โลชัน สบู่)', 'ของใช้ส่วนตัวชิ้นเล็ก (แปรงสีฟัน หวี มีดโกน หมวกอาบน้ำ สำลี ชุดเย็บผ้า)', 'รองเท้าและของใช้ในห้องนอน', 'จัดชุดตามระดับห้องและระยะเวลาเข้าพัก', 'ตัวอย่างการจัดวางที่แม่บ้านเติมง่าย' ) ),
	array( 'เลือกแชมพูและครีมอาบน้ำสำหรับโรงแรมอย่างไรให้แขกจำได้', 'choose-hotel-shampoo-shower-gel', 'คำค้นเป้าหมาย: แชมพูโรงแรม / ครีมอาบน้ำโรงแรม / วิธีเลือกแชมพูโรงแรม', array( 'แนวกลิ่นกับบุคลิกของที่พัก', 'สีของเนื้อผลิตภัณฑ์และภาพรวมห้องน้ำ', 'ขนาดบรรจุ: ขวดเล็ก vs ระบบเติม', 'สิ่งที่ปรับได้และข้อจำกัดของสูตร', 'ขั้นตอนขอตัวอย่างและทดลอง' ) ),
	array( 'ชุดของใช้ผู้ป่วยในโรงพยาบาลควรมีอะไร และจัดอย่างไรให้ผู้ป่วยสบายใจ', 'hospital-patient-amenity-kit', 'คำค้นเป้าหมาย: ของใช้ผู้ป่วยโรงพยาบาล / ชุดของใช้ผู้ป่วย', array( 'วันแรกที่เข้าห้อง: ของที่ควรพร้อมบนโต๊ะข้างเตียง', 'ระหว่างพักรักษา: ผลิตภัณฑ์ที่ใช้ง่ายและกลิ่นไม่รบกวน', 'รองเท้าสำหรับห้องผู้ป่วย', 'จัดชุดตามประเภทห้อง (ห้องพิเศษ / หอผู้ป่วย)', 'สิ่งที่ฝ่ายจัดซื้อควรถามซัพพลายเออร์' ) ),
	array( 'ขวดเล็ก ขวดเติม หรือ dispenser แบบไหนเหมาะกับที่พักของคุณ', 'refill-vs-single-use-amenities', 'คำค้นเป้าหมาย: แชมพูรีฟิล / dispenser โรงแรม / ลดขวดพลาสติกโรงแรม', array( 'ภาพรวมและความรู้สึกของแขกในแต่ละแบบ', 'ภาระงานแม่บ้านและการเติมสต๊อก', 'ต้นทุนต่อห้องต่อคืนโดยประมาณ (ต้องยืนยันตัวเลข)', 'ทางเลือกวัสดุบรรจุภัณฑ์', 'วิธีตัดสินใจร่วมกับทีม' ) ),
);
foreach ( $drafts as $d ) {
	if ( get_page_by_path( $d[1], OBJECT, 'post' ) ) { continue; }
	$body = '<!-- wp:paragraph --><p><span class="wt-flag">ร่างโครงบทความ — ต้องเขียนเนื้อหาจริงและตรวจข้อเท็จจริงกับบริษัทก่อนเผยแพร่ · ' . esc_html( $d[2] ) . '</span></p><!-- /wp:paragraph -->';
	foreach ( $d[3] as $h ) { $body .= '<!-- wp:heading --><h2 class="wp-block-heading">' . esc_html( $h ) . '</h2><!-- /wp:heading --><!-- wp:paragraph --><p>[เขียนเนื้อหา 120–200 คำ จากงานจริงของ Westons ไม่ใส่ตัวเลขที่ยังไม่ยืนยัน]</p><!-- /wp:paragraph -->'; }
	wp_insert_post( array( 'post_type' => 'post', 'post_status' => 'draft', 'post_name' => $d[1], 'post_title' => $d[0], 'post_content' => $body, 'post_excerpt' => $d[2] ) );
}
$log[] = 'articles: page + 4 drafts';

/* ---------- contact defaults (ต้องยืนยันทั้งหมด) ---------- */
if ( ! get_option( 'wt_contact' ) ) {
	update_option( 'wt_contact', array_merge( wt_contact_defaults(), array(
		'phone' => '024154826', 'phone_display' => '02-415-4826', 'email' => 'admin@westonsthai.com',
		'address' => '87/198-199 ซอยเอกชัย 76 แยก 2 บางบอน กรุงเทพฯ (ต้องยืนยัน)', 'line_label' => 'คุยทาง LINE',
	) ) );
}
update_option( 'blogname', 'Westons Thai' );
update_option( 'blogdescription', 'ผลิตภัณฑ์ดูแลตัวสำหรับโรงแรมและโรงพยาบาล' );
update_option( 'blog_public', 0 );
update_option( 'timezone_string', 'Asia/Bangkok' );
/* ---------- รูปแบบหน้าตาเริ่มต้น: A Westons Cream/Serif (theme.json) — สลับเป็น B/C ได้ที่ Appearance → Editor → Styles
 * ตั้ง define('WT_DEMO_STYLE','hd') ใน wp-config.php ก่อนนำเข้า ถ้าต้องการเริ่มด้วย C: HD Editorial ---------- */
if ( defined( 'WT_DEMO_STYLE' ) && class_exists( 'WP_Theme_JSON_Resolver' ) && ! get_option( 'wt_style_applied' ) ) {
	$vf = get_stylesheet_directory() . '/styles/' . sanitize_key( WT_DEMO_STYLE ) . '.json';
	if ( file_exists( $vf ) ) {
		$v = json_decode( file_get_contents( $vf ), true );
		if ( is_array( $v ) ) {
			unset( $v['$schema'], $v['title'] );
			$v['isGlobalStylesUserThemeJSON'] = true;
			$gid = WP_Theme_JSON_Resolver::get_user_global_styles_post_id();
			if ( $gid ) { wp_update_post( array( 'ID' => $gid, 'post_content' => wp_slash( wp_json_encode( $v ) ) ) ); update_option( 'wt_style_applied', 'hd' ); $log[] = 'style: hd'; }
		}
	}
}
/* ---------- เนื้อหาหน้าคอลเลกชัน (เติมเฉพาะช่องที่ยังว่าง เพื่อไม่ทับที่ทีมแก้แล้ว) ---------- */
$cols = include WT_SITE_DIR . 'demo/collections.php';
foreach ( (array) $cols as $slug => $fields ) {
	$term = get_term_by( 'slug', $slug, 'wt_product_group' );
	if ( ! $term ) { continue; }
	foreach ( $fields as $k => $v ) { if ( '' === (string) get_term_meta( $term->term_id, $k, true ) ) { update_term_meta( $term->term_id, $k, $v ); } }
}
$log[] = 'collections: ' . count( (array) $cols );
$log[] = 'seeded';
update_option( 'wt_demo_installed', current_time( 'mysql' ) );
flush_rewrite_rules();
return $log;
}

/* หน้าเครื่องมือ */
add_action( 'admin_menu', function () {
	add_management_page( 'เนื้อหาตัวอย่าง Westons', 'เนื้อหาตัวอย่าง Westons', 'manage_options', 'wt-demo', function () {
		echo '<div class="wrap"><h1>เนื้อหาตัวอย่าง Westons</h1>';
		if ( isset( $_POST['wt_demo_nonce'] ) && wp_verify_nonce( $_POST['wt_demo_nonce'], 'wt_demo' ) && current_user_can( 'manage_options' ) ) {
			$log = wt_install_demo_content();
			echo '<div class="notice notice-success"><p>นำเข้าแล้ว: ' . esc_html( implode( ' · ', $log ) ) . '</p></div>';
		}
		$done = get_option( 'wt_demo_installed' );
		echo '<p>สร้างหน้า 9 หน้า (หน้าแรก สินค้า สินค้าพร้อมส่ง Eco-friendly โรงแรมและโรงพยาบาล ร่วมพัฒนา เกี่ยวกับเรา ติดต่อ นโยบาย) การ์ดสินค้า 65 ใบ และรูป mockup จากเว็บเดิม ข้อความจาก COPY-DECK-TH 0.1 พร้อมป้าย “ต้องยืนยัน”</p>';
		echo '<p><strong>คำเตือน:</strong> การ์ดสินค้าเดิมทั้งหมดจะถูกลบและสร้างใหม่ หน้าที่ slug ซ้ำจะถูกเขียนทับ' . ( $done ? ' · นำเข้าล่าสุด ' . esc_html( $done ) : '' ) . '</p>';
		echo '<form method="post">'; wp_nonce_field( 'wt_demo', 'wt_demo_nonce' ); submit_button( $done ? 'นำเข้าซ้ำ (เขียนทับ)' : 'นำเข้าเนื้อหาตัวอย่าง' ); echo '</form></div>';
	} );
} );
