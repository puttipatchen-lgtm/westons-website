<?php
/**
 * หน้าคอลเลกชัน = หน้าของกลุ่มสินค้า (wt_product_group) ที่ /products/<slug>/ และ /en/products/<slug>/
 * โครงตามหน้าคอลเลกชันของ HD Fragrances: hero → เรื่องราว → แกลเลอรี → รูปแบบ/ขนาด → สินค้าในกลุ่ม → FAQ → ติดต่อ → คอลเลกชันอื่น
 * ทีมแก้ได้ที่ การ์ดสินค้า → กลุ่มสินค้า → แก้ไขกลุ่ม (ช่องด้านล่างคำอธิบาย)
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ---------- เปิดให้กลุ่มสินค้ามี URL ---------- */
add_filter( 'register_taxonomy_args', function ( $args, $taxonomy ) {
	if ( 'wt_product_group' !== $taxonomy ) { return $args; }
	$args['public']             = true;
	$args['publicly_queryable'] = true;
	$args['query_var']          = 'wt_product_group';
	$args['rewrite']            = array( 'slug' => 'products', 'with_front' => false, 'hierarchical' => false );
	return $args;
}, 10, 2 );

/* ---------- เส้นทางภาษาอังกฤษ /en/products/<slug>/ ---------- */
add_filter( 'query_vars', function ( $vars ) { $vars[] = 'wt_en'; return $vars; } );
add_action( 'init', function () {
	add_rewrite_rule( '^en/products/([^/]+)/?$', 'index.php?wt_product_group=$matches[1]&wt_en=1', 'top' );
}, 20 );

/** URL ของคอลเลกชันตามภาษา */
function wt_collection_url( $term, $en = false ) {
	$term = is_object( $term ) ? $term : get_term_by( 'slug', $term, 'wt_product_group' );
	if ( ! $term ) { return ''; }
	return home_url( ( $en ? '/en' : '' ) . '/products/' . $term->slug . '/' );
}

/* ---------- ช่องข้อมูลของกลุ่ม (term meta) ---------- */
function wt_collection_fields() {
	return array(
		'wt_intro'       => array( 'ประโยคเปิด (ไทย)', 'textarea', 'ประโยคสั้นใต้ชื่อคอลเลกชัน' ),
		'wt_story'       => array( 'เรื่องราวของคอลเลกชัน (ไทย)', 'textarea', '2–3 ย่อหน้า เว้นบรรทัดว่างระหว่างย่อหน้า' ),
		'wt_formats'     => array( 'รูปแบบและขนาด (ไทย)', 'textarea', 'บรรทัดละ 1 รายการ รูปแบบ: ชื่อรูปแบบ | รายละเอียด | หมายเหตุ/ป้ายต้องยืนยัน' ),
		'wt_faq'         => array( 'คำถามที่พบบ่อย (ไทย)', 'textarea', 'บรรทัดละ 1 ข้อ รูปแบบ: คำถาม | คำตอบ' ),
		'wt_seo_title'   => array( 'SEO Title (ไทย)', 'text', '' ),
		'wt_meta_desc'   => array( 'Meta description (ไทย)', 'textarea', '' ),
		'wt_name_en'     => array( 'Collection name (EN)', 'text', '' ),
		'wt_intro_en'    => array( 'Intro (EN)', 'textarea', '' ),
		'wt_story_en'    => array( 'Story (EN)', 'textarea', '' ),
		'wt_formats_en'  => array( 'Formats & sizes (EN)', 'textarea', 'One per line: name | detail | note' ),
		'wt_faq_en'      => array( 'FAQ (EN)', 'textarea', 'One per line: question | answer' ),
		'wt_seo_title_en'=> array( 'SEO Title (EN)', 'text', '' ),
		'wt_meta_desc_en'=> array( 'Meta description (EN)', 'textarea', '' ),
		'wt_hero_image'  => array( 'รูป hero (attachment ID; ว่าง = ใช้รูปการ์ดใบแรก)', 'text', '' ),
	);
}
add_action( 'wt_product_group_edit_form_fields', function ( $term ) {
	wp_nonce_field( 'wt_collection_fields', 'wt_collection_nonce' );
	echo '<tr><th colspan="2"><h3 style="margin:1em 0 0">หน้าคอลเลกชัน (' . esc_html( wt_collection_url( $term ) ) . ')</h3><p class="description">ใช้คำอธิบายด้านบนเป็นเรื่องราวได้ ถ้าช่อง "เรื่องราว" ว่าง · ทุกช่องใส่ป้ายได้ด้วย [ต้องยืนยัน X-00]</p></th></tr>';
	foreach ( wt_collection_fields() as $key => $f ) {
		$v = get_term_meta( $term->term_id, $key, true );
		echo '<tr class="form-field"><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $f[0] ) . '</label></th><td>';
		if ( 'textarea' === $f[1] ) { echo '<textarea name="' . esc_attr( $key ) . '" id="' . esc_attr( $key ) . '" rows="4" style="width:100%">' . esc_textarea( $v ) . '</textarea>'; }
		else { echo '<input type="text" name="' . esc_attr( $key ) . '" id="' . esc_attr( $key ) . '" value="' . esc_attr( $v ) . '" style="width:100%">'; }
		if ( $f[2] ) { echo '<p class="description">' . esc_html( $f[2] ) . '</p>'; }
		echo '</td></tr>';
	}
} );
add_action( 'edited_wt_product_group', function ( $term_id ) {
	if ( ! isset( $_POST['wt_collection_nonce'] ) || ! wp_verify_nonce( $_POST['wt_collection_nonce'], 'wt_collection_fields' ) ) { return; }
	foreach ( wt_collection_fields() as $key => $f ) {
		if ( isset( $_POST[ $key ] ) ) { update_term_meta( $term_id, $key, 'textarea' === $f[1] ? sanitize_textarea_field( wp_unslash( $_POST[ $key ] ) ) : sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) ); }
	}
} );

/* ---------- helpers ---------- */
/** แปลงข้อความที่มี [ต้องยืนยัน ...] / [VERIFY ...] / [ขาด ...] / [MISSING ...] เป็นป้าย */
function wt_flagify( $text ) {
	$text = esc_html( $text );
	return preg_replace( '/\[((?:ต้องยืนยัน|ขาด|VERIFY|MISSING)[^\]]*)\]/u', '<span class="wt-flag">$1</span>', $text );
}
function wt_collection_meta( $term, $key, $en ) {
	$v = $en ? get_term_meta( $term->term_id, $key . '_en', true ) : '';
	if ( '' === $v || null === $v ) { $v = get_term_meta( $term->term_id, $key, true ); }
	return (string) $v;
}
function wt_collection_name( $term, $en ) {
	if ( $en ) { return get_term_meta( $term->term_id, 'wt_name_en', true ) ?: ( function_exists( 'wt_group_name_en' ) ? ( wt_group_name_en( $term->slug ) ?: $term->name ) : $term->name ); }
	return $term->name;
}
function wt_collection_cards( $term, $limit = 12 ) {
	$prod = (bool) wt_contact( 'production' );
	return get_posts( array( 'post_type' => 'wt_product_card', 'posts_per_page' => $limit, 'orderby' => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
		'meta_query' => array( array( 'key' => 'wt_status', 'value' => $prod ? array( 'hidden', 'pending' ) : array( 'hidden' ), 'compare' => 'NOT IN' ) ),
		'tax_query' => array( array( 'taxonomy' => 'wt_product_group', 'field' => 'term_id', 'terms' => $term->term_id ) ) ) );
}
function wt_collection_hero_id( $term ) {
	$id = (int) get_term_meta( $term->term_id, 'wt_hero_image', true );
	if ( $id && get_post( $id ) ) { return $id; }
	foreach ( wt_collection_cards( $term, 6 ) as $p ) { if ( has_post_thumbnail( $p ) ) { return get_post_thumbnail_id( $p ); } }
	return 0;
}

/* ---------- บล็อก: ส่วนหัว/ท้ายตามภาษา (ใช้ใน template ของคอลเลกชัน) ---------- */
function wt_render_auto_part( $attrs ) {
	$slug = sanitize_key( $attrs['part'] ?? 'header' );
	if ( wt_is_en() ) { $slug .= '-en'; }
	ob_start(); block_template_part( $slug ); return ob_get_clean();
}

/* ---------- บล็อก: เนื้อหาหน้าคอลเลกชัน ---------- */
function wt_render_collection( $attrs ) {
	$term = get_queried_object();
	if ( ! $term || empty( $term->taxonomy ) || 'wt_product_group' !== $term->taxonomy ) { return '<p class="wt-flag">บล็อกนี้แสดงผลเฉพาะบนหน้ากลุ่มสินค้า</p>'; }
	$en    = wt_is_en();
	$name  = wt_collection_name( $term, $en );
	$intro = wt_collection_meta( $term, 'wt_intro', $en );
	$story = wt_collection_meta( $term, 'wt_story', $en ) ?: ( $en ? '' : $term->description );
	$formats = array_filter( array_map( 'trim', explode( "\n", wt_collection_meta( $term, 'wt_formats', $en ) ) ) );
	$faq     = array_filter( array_map( 'trim', explode( "\n", wt_collection_meta( $term, 'wt_faq', $en ) ) ) );
	$cards   = wt_collection_cards( $term, 24 );
	$hero_id = wt_collection_hero_id( $term );
	$contact = home_url( $en ? '/en/contact/' : '/contact/' );
	$products = home_url( $en ? '/en/products/' : '/products/' );
	$t = function ( $th, $enTxt ) use ( $en ) { return $en ? $enTxt : $th; };

	$o  = '';
	/* 1 hero */
	$o .= '<section class="wt-section wt-collection wt-hero-split is-white alignfull"><div class="wt-inner"><div class="wp-block-columns are-vertically-aligned-center wt-collection-hero is-layout-flex wp-block-columns-is-layout-flex"><div class="wp-block-column is-vertically-aligned-center is-layout-flow wp-block-column-is-layout-flow" style="flex-basis:42%">';
	$o .= '<p class="wt-eyebrow"><a href="' . esc_url( $products ) . '">' . $t( 'สินค้า', 'Products' ) . '</a> · ' . $t( 'คอลเลกชัน', 'Collection' ) . '</p>';
	$o .= '<h1>' . esc_html( $name ) . '</h1>';
	if ( $intro ) { $o .= '<p class="wt-muted has-large-font-size">' . wt_flagify( $intro ) . '</p>'; }
	$o .= '<div class="wp-block-buttons is-layout-flex wp-block-buttons-is-layout-flex"><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $contact . '?collection=' . rawurlencode( $name ) ) . '">' . $t( 'ขอตัวอย่างและราคา', 'Request samples & pricing' ) . '</a></div><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#items">' . $t( 'ดูสินค้าในคอลเลกชัน', 'See the products' ) . '</a></div></div>';
	$o .= '</div><div class="wp-block-column is-vertically-aligned-center is-layout-flow wp-block-column-is-layout-flow" style="flex-basis:58%">';
	$o .= $hero_id ? '<figure class="wp-block-image wt-hero-img">' . wp_get_attachment_image( $hero_id, 'large', false, array( 'fetchpriority' => 'high' ) ) . '</figure>' : '<div class="wt-placeholder" style="aspect-ratio:4/3">' . $t( 'รูปคอลเลกชัน (ขาด)', 'Collection image (missing)' ) . '</div>';
	$o .= '</div></div></div></section>';
	/* 2 story */
	if ( $story ) {
		$o .= '<section class="wt-section wt-collection is-white alignfull"><div class="wt-inner"><div class="wt-collection-story">';
		foreach ( preg_split( '/\n\s*\n/', $story ) as $i => $para ) { $para = trim( $para ); if ( ! $para ) { continue; } $o .= ( 0 === $i ? '<p class="wt-tagline has-text-align-center">' : '<p class="wt-muted has-text-align-center">' ) . wt_flagify( $para ) . '</p>'; }
		$o .= '<hr class="wp-block-separator has-alpha-channel-opacity wt-hairline"/></div></div></section>';
	}
	/* 3 gallery */
	$imgs = array();
	foreach ( $cards as $p ) { if ( has_post_thumbnail( $p ) ) { $imgs[] = '<div class="wt-slide"><figure class="wp-block-image">' . get_the_post_thumbnail( $p, 'large', array( 'loading' => 'lazy' ) ) . '</figure><h3 class="wt-slide-title has-text-align-center">' . esc_html( $en && get_post_meta( $p->ID, 'wt_title_en', true ) ? get_post_meta( $p->ID, 'wt_title_en', true ) : $p->post_title ) . '</h3></div>'; } }
	if ( count( $imgs ) > 1 ) { $o .= '<section class="wt-section wt-collection is-dark wt-on-dark alignfull"><div class="wt-inner"><h2 class="wp-block-heading has-text-align-center">' . $t( 'ภาพรวมคอลเลกชัน', 'Collection gallery' ) . '</h2><div class="wt-carousel">' . implode( '', $imgs ) . '</div></div></section>'; }
	/* 4 formats */
	if ( $formats ) {
		$o .= '<section class="wt-section wt-collection is-white alignfull"><div class="wt-inner"><h2 class="wp-block-heading has-text-align-center">' . $t( 'รูปแบบและขนาดบรรจุ', 'Formats & sizes' ) . '</h2><div class="wt-formats">';
		foreach ( $formats as $line ) { $c = array_map( 'trim', explode( '|', $line ) ) + array( '', '', '' ); $o .= '<div class="wt-format"><h3>' . wt_flagify( $c[0] ) . '</h3>' . ( $c[1] ? '<p>' . wt_flagify( $c[1] ) . '</p>' : '' ) . ( $c[2] ? '<p class="wt-muted has-small-font-size">' . wt_flagify( $c[2] ) . '</p>' : '' ) . '</div>'; }
		$o .= '</div></div></section>';
	}
	/* 5 products */
	$o .= '<section class="wt-section wt-collection is-white alignfull" id="items"><div class="wt-inner"><h2 class="wp-block-heading">' . $t( 'สินค้าในคอลเลกชัน', 'Products in this collection' ) . '</h2>' . wt_render_product_grid( array( 'group' => $term->slug, 'columns' => 4, 'limit' => 24, 'noLink' => true ) ) . '</div></section>';
	/* 6 faq */
	if ( $faq ) {
		$o .= '<section class="wt-section wt-collection is-white alignfull"><div class="wt-inner"><h2 class="wp-block-heading has-text-align-center">' . $t( 'คำถามที่พบบ่อย', 'Frequently asked questions' ) . '</h2><div class="wt-faq wt-collection-faq">';
		foreach ( $faq as $line ) { $c = array_map( 'trim', explode( '|', $line ) ) + array( '', '' ); $o .= '<details class="wp-block-details"><summary>' . esc_html( $c[0] ) . '</summary><p>' . wt_flagify( $c[1] ) . '</p></details>'; }
		$o .= '</div></div></section>';
	}
	/* 7 contact */
	$o .= '<section class="wt-section wt-collection is-dark wt-on-dark alignfull"><div class="wt-inner"><div class="wp-block-columns are-vertically-aligned-center is-layout-flex wp-block-columns-is-layout-flex"><div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow"><h2 class="wp-block-heading">' . $t( 'อยากลองของจริงก่อนตัดสินใจ', 'Want to try the real thing first?' ) . '</h2><p class="wt-muted">' . wt_flagify( $t( 'เล่าเรื่องที่พักให้เราฟัง ทีมจะเลือกตัวอย่างจากคอลเลกชันนี้ที่ใกล้เคียงที่สุดให้ [ต้องยืนยัน C-06 เงื่อนไขตัวอย่าง]', 'Tell us about your property and the team will pick the closest samples from this collection for you [VERIFY C-06 sample terms]' ) ) . '</p><div class="wp-block-buttons is-layout-flex wp-block-buttons-is-layout-flex"><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $contact . '?collection=' . rawurlencode( $name ) ) . '">' . $t( 'คุยกับทีมเรา', 'Talk to our team' ) . '</a></div></div>' . wt_render_contact_buttons( array( 'variant' => 'list' ) ) . '</div><div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow">' . wt_render_contact_buttons( array( 'variant' => 'qr' ) ) . '</div></div></div></section>';
	/* 8 related */
	$others = get_terms( array( 'taxonomy' => 'wt_product_group', 'hide_empty' => true, 'exclude' => array( $term->term_id ) ) );
	if ( $others && ! is_wp_error( $others ) ) {
		$o .= '<section class="wt-section wt-collection is-white alignfull"><div class="wt-inner"><h2 class="wp-block-heading">' . $t( 'คอลเลกชันอื่น', 'Other collections' ) . '</h2><div class="wt-carousel">';
		foreach ( $others as $ot ) { $hid = wt_collection_hero_id( $ot ); $o .= '<div class="wt-slide"><a class="wt-collection-link" href="' . esc_url( wt_collection_url( $ot, $en ) ) . '">' . ( $hid ? '<figure class="wp-block-image">' . wp_get_attachment_image( $hid, 'medium_large', false, array( 'loading' => 'lazy' ) ) . '</figure>' : '' ) . '<h3 class="wt-slide-title has-text-align-center">' . esc_html( wt_collection_name( $ot, $en ) ) . '</h3></a></div>'; }
		$o .= '</div></div></section>';
	}
	return $o;
}

/* ---------- SEO: title, description, hreflang, breadcrumb ---------- */
add_filter( 'pre_get_document_title', function ( $title ) {
	if ( ! is_tax( 'wt_product_group' ) ) { return $title; }
	$term = get_queried_object(); $en = wt_is_en();
	$custom = $en ? get_term_meta( $term->term_id, 'wt_seo_title_en', true ) : get_term_meta( $term->term_id, 'wt_seo_title', true );
	return $custom ?: wt_collection_name( $term, $en ) . ( $en ? ' | Hotel & hospital amenities | Westons Thai' : ' | ของใช้โรงแรมและโรงพยาบาล | Westons Thai' );
}, 20 );
add_action( 'wp_head', function () {
	if ( ! is_tax( 'wt_product_group' ) ) { return; }
	$term = get_queried_object(); $en = wt_is_en();
	$desc = ( $en ? get_term_meta( $term->term_id, 'wt_meta_desc_en', true ) : get_term_meta( $term->term_id, 'wt_meta_desc', true ) ) ?: wp_strip_all_tags( wt_collection_meta( $term, 'wt_intro', $en ) );
	if ( $desc ) { echo '<meta name="description" content="' . esc_attr( preg_replace( '/\[[^\]]*\]/u', '', $desc ) ) . '">' . "\n"; }
	$th = wt_collection_url( $term, false ); $enu = wt_collection_url( $term, true );
	echo '<link rel="alternate" hreflang="th" href="' . esc_url( $th ) . '">' . "\n" . '<link rel="alternate" hreflang="en" href="' . esc_url( $enu ) . '">' . "\n" . '<link rel="alternate" hreflang="x-default" href="' . esc_url( $th ) . '">' . "\n";
	$home = home_url( $en ? '/en/' : '/' ); $products = home_url( $en ? '/en/products/' : '/products/' );
	$graph = array(
		array( '@type' => 'BreadcrumbList', 'itemListElement' => array(
			array( '@type' => 'ListItem', 'position' => 1, 'name' => $en ? 'Home' : 'หน้าแรก', 'item' => $home ),
			array( '@type' => 'ListItem', 'position' => 2, 'name' => $en ? 'Products' : 'สินค้า', 'item' => $products ),
			array( '@type' => 'ListItem', 'position' => 3, 'name' => wt_collection_name( $term, $en ), 'item' => $en ? $enu : $th ) ) ),
		array( '@type' => 'CollectionPage', 'url' => $en ? $enu : $th, 'name' => wt_collection_name( $term, $en ), 'inLanguage' => $en ? 'en' : 'th', 'isPartOf' => array( '@id' => home_url( '/#website' ) ), 'description' => preg_replace( '/\[[^\]]*\]/u', '', $desc ) ),
	);
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
}, 4 );
/* canonical ของหน้าอังกฤษให้ชี้ตัวเอง */
add_filter( 'get_canonical_url', function ( $url ) { return $url; } );
add_filter( 'term_link', function ( $link, $term, $taxonomy ) {
	if ( 'wt_product_group' === $taxonomy && wt_is_en() ) { return wt_collection_url( $term, true ); }
	return $link;
}, 10, 3 );
