<?php
/**
 * Title: ฟอร์มเล่าโจทย์ (ตัวอย่าง — แทนที่ด้วยปลั๊กอินฟอร์มบน staging)
 * Slug: westons-block/contact-form
 * Categories: westons
 * Inserter: true
 */
?>
<!-- wp:html -->
<form class="wt-form" method="get" action="/contact/">
<input type="hidden" name="wt-sent" value="1">
<div><span style="font-size:.875rem;font-weight:500;display:block;margin-bottom:.35rem">ประเภทองค์กร</span>
<div class="wt-chips"><label><input type="radio" name="org_type" value="hotel" checked> โรงแรม / รีสอร์ต</label><label><input type="radio" name="org_type" value="hospital"> โรงพยาบาล / คลินิก</label><label><input type="radio" name="org_type" value="spa"> สปา</label><label><input type="radio" name="org_type" value="brand"> แบรนด์ / ผู้พัฒนาสินค้า</label><label><input type="radio" name="org_type" value="other"> อื่นๆ</label></div></div>
<div class="wt-two"><div><label for="wt-org">ชื่อองค์กร *</label><input id="wt-org" name="org" type="text" required></div><div><label for="wt-name">ชื่อผู้ติดต่อ *</label><input id="wt-name" name="name" type="text" required></div></div>
<div class="wt-two"><div><label for="wt-email">อีเมล</label><input id="wt-email" name="email" type="email"></div><div><label for="wt-phone">เบอร์โทร / LINE ID</label><input id="wt-phone" name="phone" type="text"></div></div>
<div><span style="font-size:.875rem;font-weight:500;display:block;margin-bottom:.35rem">สินค้าที่สนใจ</span>
<div class="wt-chips"><label><input type="checkbox" name="interest[]" value="bath"> ผลิตภัณฑ์อาบน้ำและดูแลผิว</label><label><input type="checkbox" name="interest[]" value="kits"> ของใช้และชุดจัดรวม</label><label><input type="checkbox" name="interest[]" value="slippers"> รองเท้า</label><label><input type="checkbox" name="interest[]" value="oem"> ร่วมพัฒนาผลิตภัณฑ์ใหม่</label><label><input type="checkbox" name="interest[]" value="imported"> แบรนด์นำเข้า</label><label><input type="checkbox" name="interest[]" value="unsure"> ยังไม่แน่ใจ</label></div></div>
<div class="wt-two"><div><label for="wt-qty">จำนวนโดยประมาณ</label><select id="wt-qty" name="qty"><option>ยังไม่ทราบ</option><option>[ขาด: ช่วงจำนวนที่ฝ่ายขายใช้]</option></select></div><div><label for="wt-date">วันที่ต้องการใช้</label><input id="wt-date" name="date" type="text" placeholder="เดือน/ปี"></div></div>
<div><label for="wt-msg">อยากคุยเรื่องอะไร</label><textarea id="wt-msg" name="message" placeholder="เช่น รีสอร์ต 60 ห้อง อยากได้กลิ่นที่ให้ความรู้สึกสดชื่นแบบทะเล"></textarea></div>
<label class="wt-consent"><input type="checkbox" name="consent" required> ฉันยอมรับให้ Westons ใช้ข้อมูลนี้เพื่อติดต่อกลับเรื่องที่สอบถาม ตาม <a href="/privacy-policy/">นโยบายความเป็นส่วนตัว</a></label>
<button type="submit">ส่งข้อมูล</button>
<p style="margin:0;font-size:.8125rem;color:#5A6560">อีเมลหรือเบอร์โทร กรอกอย่างน้อยหนึ่งช่อง</p>
</form>
<!-- /wp:html -->
