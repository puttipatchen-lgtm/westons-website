<?php
/**
 * Title: Brief form (EN sample — replace with the form plugin on staging)
 * Slug: westons-block/contact-form-en
 * Categories: westons
 * Inserter: true
 */
?>
<!-- wp:html -->
<form class="wt-form" method="get" action="/en/contact/">
<input type="hidden" name="wt-sent" value="1">
<div><span style="font-size:.875rem;font-weight:500;display:block;margin-bottom:.35rem">Organisation type</span>
<div class="wt-chips"><label><input type="radio" name="org_type" value="hotel" checked> Hotel / resort</label><label><input type="radio" name="org_type" value="hospital"> Hospital / clinic</label><label><input type="radio" name="org_type" value="spa"> Spa</label><label><input type="radio" name="org_type" value="brand"> Brand / product developer</label><label><input type="radio" name="org_type" value="other"> Other</label></div></div>
<div class="wt-two"><div><label for="wt-org">Organisation *</label><input id="wt-org" name="org" type="text" required></div><div><label for="wt-name">Contact name *</label><input id="wt-name" name="name" type="text" required></div></div>
<div class="wt-two"><div><label for="wt-email">Email</label><input id="wt-email" name="email" type="email"></div><div><label for="wt-phone">Phone / LINE ID</label><input id="wt-phone" name="phone" type="text"></div></div>
<div><span style="font-size:.875rem;font-weight:500;display:block;margin-bottom:.35rem">Products of interest</span>
<div class="wt-chips"><label><input type="checkbox" name="interest[]" value="bath"> Bath & body</label><label><input type="checkbox" name="interest[]" value="kits"> Amenities & kits</label><label><input type="checkbox" name="interest[]" value="slippers"> Slippers</label><label><input type="checkbox" name="interest[]" value="oem"> Co-develop a new product</label><label><input type="checkbox" name="interest[]" value="imported"> Imported brands</label><label><input type="checkbox" name="interest[]" value="unsure"> Not sure yet</label></div></div>
<div class="wt-two"><div><label for="wt-qty">Approximate quantity</label><select id="wt-qty" name="qty"><option>Not known yet</option><option>[MISSING: quantity ranges used by sales]</option></select></div><div><label for="wt-date">Needed by</label><input id="wt-date" name="date" type="text" placeholder="month / year"></div></div>
<div><label for="wt-msg">What would you like to talk about?</label><textarea id="wt-msg" name="message" placeholder="e.g. 60-room beach resort looking for a fresh, sea-air scent"></textarea></div>
<label class="wt-consent"><input type="checkbox" name="consent" required> I agree that Westons may use this information to reply to my enquiry, per the <a href="/en/privacy-policy/">Privacy policy</a></label>
<button type="submit">Send enquiry</button>
<p style="margin:0;font-size:.8125rem;color:#5A6560">Email or phone: please fill in at least one</p>
</form>
<!-- /wp:html -->
