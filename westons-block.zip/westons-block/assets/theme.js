/* Westons theme.js — animation และ carousel แบบเบา ไม่พึ่ง library */
(function () {
	var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	/* 1) fade-in เมื่อเลื่อนถึง: ลูกโดยตรงของทุก section */
	var targets = [];
	var motion = document.body.classList.contains('wt-motion');
	document.querySelectorAll('.wt-section').forEach(function (s) {
		if (motion && (s.classList.contains('wt-hero-motion') || s.classList.contains('wt-words-section'))) { return; }
		Array.prototype.forEach.call(s.children, function (c) { c.classList.add('wt-reveal'); targets.push(c); });
	});
	/* เปิดหน้าด้วย #anchor: โชว์ส่วนที่อยู่ในจอทันที ไม่ต้องรอ animation */
	var revealVisible = function () { var vh = window.innerHeight; targets.forEach(function (t) { var r = t.getBoundingClientRect(); if (r.bottom > 0 && r.top < vh) { t.classList.add('is-in'); } }); };
	if (location.hash) { revealVisible(); setTimeout(revealVisible, 300); setTimeout(revealVisible, 1200); }
	window.addEventListener('hashchange', function () { setTimeout(revealVisible, 50); });
	if (reduce || !('IntersectionObserver' in window)) { targets.forEach(function (t) { t.classList.add('is-in'); }); }
	else {
		var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); } }); }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
		targets.forEach(function (t) { io.observe(t); });
		setTimeout(function () { targets.forEach(function (t) { if (t.getBoundingClientRect().top < window.innerHeight) t.classList.add('is-in'); }); }, 60);
	}

	/* 2) รูปขยายเมื่อชี้ */
	document.querySelectorAll('.wt-card .wp-block-image, .wt-product-card, .wt-slide .wp-block-image, .wt-mega-img, .wt-split .wp-block-image, .wt-hero-img').forEach(function (el) { el.classList.add('wt-zoom'); });

	/* 3) หัวเว็บย่อเมื่อเลื่อน */
	var mega = document.querySelector('.wt-mega');
	if (mega) {
		var onScroll = function () { mega.classList.toggle('is-shrunk', window.scrollY > 90); };
		window.addEventListener('scroll', onScroll, { passive: true }); onScroll();
	}

	/* 4) carousel: Group.wt-carousel > .wt-slide */
	document.querySelectorAll('.wt-carousel').forEach(function (c) {
		var slides = Array.prototype.filter.call(c.children, function (x) { return x.classList.contains('wt-slide'); });
		if (slides.length < 2) { c.classList.add('is-single'); }
		var track = document.createElement('div'); track.className = 'wt-carousel-track';
		slides.forEach(function (s) { track.appendChild(s); });
		c.appendChild(track);
		var single = c.classList.contains('is-single') || c.closest('.wt-split');
		if (single) { c.classList.add('is-single'); }
		var dots = document.createElement('div'); dots.className = 'wt-carousel-dots';
		var perView = function () { return single ? 1 : (window.innerWidth < 600 ? 1 : window.innerWidth < 1024 ? 2 : 3); };
		var pages = function () { return Math.max(1, Math.ceil(slides.length / perView())); };
		var goTo = function (i) { var w = track.scrollWidth / slides.length; track.scrollTo({ left: i * perView() * w, behavior: reduce ? 'auto' : 'smooth' }); };
		var build = function () {
			dots.innerHTML = '';
			for (var i = 0; i < pages(); i++) { var b = document.createElement('button'); b.type = 'button'; b.setAttribute('aria-label', 'slide ' + (i + 1)); (function (i) { b.addEventListener('click', function () { goTo(i); }); })(i); dots.appendChild(b); }
			update();
		};
		var update = function () {
			var w = track.scrollWidth / slides.length; var idx = Math.round(track.scrollLeft / (w * perView()));
			Array.prototype.forEach.call(dots.children, function (d, i) { d.classList.toggle('is-active', i === idx); });
		};
		c.appendChild(dots); build();
		track.addEventListener('scroll', update, { passive: true }); window.addEventListener('resize', build);
		if (!single) {
			['prev', 'next'].forEach(function (dir) {
				var a = document.createElement('button'); a.type = 'button'; a.className = 'wt-carousel-arrow is-' + dir; a.setAttribute('aria-label', dir);
				a.innerHTML = dir === 'prev' ? '&#8249;' : '&#8250;';
				a.addEventListener('click', function () { var w = track.scrollWidth / slides.length; track.scrollBy({ left: (dir === 'next' ? 1 : -1) * w * perView(), behavior: 'smooth' }); });
				c.appendChild(a);
			});
		}
		/* autoplay เหมือน HD (3–5 วิ) หยุดเมื่อชี้/แตะ */
		if (!reduce && slides.length > 1) {
			var timer, delay = single ? 5000 : 3500;
			var step = function () { var w = track.scrollWidth / slides.length; var max = track.scrollWidth - track.clientWidth; var next = track.scrollLeft + w * perView(); track.scrollTo({ left: next > max + 4 ? 0 : next, behavior: 'smooth' }); };
			var start = function () { stop(); timer = setInterval(step, delay); }; var stop = function () { if (timer) clearInterval(timer); };
			c.addEventListener('mouseenter', stop); c.addEventListener('mouseleave', start); c.addEventListener('touchstart', stop, { passive: true });
			document.addEventListener('visibilitychange', function () { document.hidden ? stop() : start(); });
			start();
		}
	});

	/* 5) Lightbox รูปสินค้า */
	var cards = Array.prototype.slice.call(document.querySelectorAll('.wt-product-card.has-lightbox'));
	if (cards.length) {
		var lb = null, idx = 0;
		var build = function () {
			lb = document.createElement('div'); lb.className = 'wt-lightbox'; lb.setAttribute('role', 'dialog'); lb.setAttribute('aria-modal', 'true');
			lb.innerHTML = '<button class="wt-lightbox-close" aria-label="close">&times;</button><button class="wt-lightbox-prev" aria-label="previous">&#8249;</button><button class="wt-lightbox-next" aria-label="next">&#8250;</button><div class="wt-lightbox-inner"><img class="wt-lightbox-img" alt=""><div class="wt-lightbox-text"><h3></h3><p class="wt-lightbox-excerpt"></p><p class="wt-lightbox-adjust"></p><a class="wt-lightbox-cta" href="#"></a> <a class="wt-lightbox-col" href="#"></a></div></div><div class="wt-lightbox-count"></div>';
			document.body.appendChild(lb);
			lb.querySelector('.wt-lightbox-close').addEventListener('click', close);
			lb.querySelector('.wt-lightbox-prev').addEventListener('click', function () { show(idx - 1); });
			lb.querySelector('.wt-lightbox-next').addEventListener('click', function () { show(idx + 1); });
			lb.addEventListener('click', function (e) { if (e.target === lb) close(); });
			document.addEventListener('keydown', function (e) { if (!lb.classList.contains('is-open')) return; if (e.key === 'Escape') close(); if (e.key === 'ArrowRight') show(idx + 1); if (e.key === 'ArrowLeft') show(idx - 1); });
			var sx = 0; lb.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true }); lb.addEventListener('touchend', function (e) { var dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 50) show(idx + (dx < 0 ? 1 : -1)); });
		};
		var show = function (i) {
			if (!lb) build();
			idx = (i + cards.length) % cards.length; var c = cards[idx];
			var img = lb.querySelector('.wt-lightbox-img'); img.src = c.getAttribute('data-full'); img.alt = c.getAttribute('data-title');
			lb.querySelector('h3').textContent = c.getAttribute('data-title');
			lb.querySelector('.wt-lightbox-excerpt').textContent = c.getAttribute('data-excerpt') || '';
			lb.querySelector('.wt-lightbox-adjust').textContent = c.getAttribute('data-adjust') || '';
			var cta = lb.querySelector('.wt-lightbox-cta'); cta.textContent = c.getAttribute('data-cta'); cta.href = c.getAttribute('data-cta-url') + '?product=' + encodeURIComponent(c.getAttribute('data-title'));
			var col = lb.querySelector('.wt-lightbox-col'); if (c.getAttribute('data-col')) { col.style.display = ''; col.href = c.getAttribute('data-col'); col.textContent = c.getAttribute('data-col-label') + ' \u2192'; } else { col.style.display = 'none'; }
			lb.querySelector('.wt-lightbox-count').textContent = (idx + 1) + ' / ' + cards.length;
			document.body.classList.add('wt-lightbox-open'); lb.style.display = 'flex'; requestAnimationFrame(function () { lb.classList.add('is-open'); });
		};
		var close = function () { if (!lb) return; lb.classList.remove('is-open'); document.body.classList.remove('wt-lightbox-open'); setTimeout(function () { lb.style.display = 'none'; }, 250); };
		cards.forEach(function (c, i) { c.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('a')) return; show(i); }); c.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); show(i); } }); });
	}

	/* 6) v0.13 Motion หน้าแรก — ทำงานเฉพาะ body.wt-motion (สวิตช์ในตั้งค่า) */
	if (motion) {
		/* 6a) hero: แยกคำใน h1 ให้เผยทีละคำ */
		var h1 = document.querySelector('.wt-hero-motion h1');
		if (h1 && !reduce) {
			var words = h1.textContent.trim().split(/\s+/); h1.textContent = '';
			words.forEach(function (w, i) { var o = document.createElement('span'); o.className = 'wt-w'; var sp = document.createElement('span'); sp.textContent = w; sp.style.setProperty('--i', i); o.appendChild(sp); h1.appendChild(o); });
		}
		/* 6b) อารมณ์พื้นหลังตาม section ที่อยู่กลางจอ + หัวเว็บทึบเมื่อพ้น hero */
		var body = document.body;
		var moodOf = function (s) { return s.classList.contains('is-dark') ? 'dark' : s.classList.contains('is-tint') || s.classList.contains('wt-band') ? 'tint' : s.classList.contains('is-white') ? 'white' : 'light'; };
		var setMood = function (m) { ['dark', 'tint', 'white', 'light'].forEach(function (x) { body.classList.toggle('wt-mood-' + x, x === m); }); };
		var secs = Array.prototype.slice.call(document.querySelectorAll('.wt-section'));
		if ('IntersectionObserver' in window) {
			var mo = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) setMood(moodOf(e.target)); }); }, { rootMargin: '-52% 0px -40% 0px' });
			secs.forEach(function (s) { mo.observe(s); });
		}
		var hero = document.querySelector('.wt-hero-motion');
		var navSolid = function () { var y = hero ? hero.getBoundingClientRect().bottom - 80 : 1; body.classList.toggle('wt-nav-solid', y < 0); };
		window.addEventListener('scroll', navSolid, { passive: true }); navSolid();
		if (hero) setMood('dark');
		/* 6c) คำใหญ่โผล่ทีละคำ: สร้างจากรายการ .wt-word ที่ทีมแก้ในหลังบ้าน */
		var wsec = document.querySelector('.wt-words-section'), wl = [], wd = [], wp = [], wbar = null;
		if (wsec) {
			var head = wsec.querySelector('.wt-words-head'), list = wsec.querySelector('.wt-words');
			var items = Array.prototype.slice.call(list.querySelectorAll('.wt-word'));
			var stage = document.createElement('div'); stage.className = 'wt-words-stage'; stage.style.setProperty('--n', items.length);
			var sticky = document.createElement('div'); sticky.className = 'wt-words-sticky';
			if (head) { var hh = document.createElement('div'); hh.className = 'wt-words-headin'; Array.prototype.forEach.call(head.querySelectorAll('.wt-eyebrow, h2'), function (x) { var c = x.cloneNode(true); c.removeAttribute('id'); hh.appendChild(c); }); sticky.appendChild(hh); }
			var cols = document.createElement('div'); cols.className = 'wt-words-cols';
			var pic = document.createElement('div'); pic.className = 'wt-words-pic';
			var desc = document.createElement('div'); desc.className = 'wt-words-desc';
			var big = document.createElement('div'); big.className = 'wt-words-list'; big.setAttribute('aria-hidden', 'true');
			items.forEach(function (it) { desc.appendChild(it); var t = it.querySelector('.wt-word-title'); var sp = document.createElement('span'); sp.textContent = t ? t.textContent : ''; big.appendChild(sp); wl.push(sp); wd.push(it); var im = it.querySelector('.wt-word-img img'); var c = im ? im.cloneNode(true) : document.createElement('img'); pic.appendChild(c); wp.push(c); });
			cols.appendChild(pic); cols.appendChild(desc); cols.appendChild(big); sticky.appendChild(cols);
			var bar = document.createElement('div'); bar.className = 'wt-words-bar'; wbar = document.createElement('i'); bar.appendChild(wbar); sticky.appendChild(bar);
			stage.appendChild(sticky); list.replaceWith(stage);
			if (reduce) { wl.forEach(function (s) { s.classList.add('is-on'); }); wd.forEach(function (d) { d.classList.add('is-on'); }); if (wp[0]) wp[0].classList.add('is-on'); }
		}
		/* 6d) parallax เบา ๆ กับรูป .wt-px + ความคืบหน้าของคำใหญ่ */
		var px = Array.prototype.slice.call(document.querySelectorAll('.wt-drift .wt-px img'));
		var cur = -1;
		var tick = function () {
			if (reduce) return;
			var vh = window.innerHeight;
			if (wsec && wl.length) {
				var stg = wsec.querySelector('.wt-words-stage'); var r = stg.getBoundingClientRect();
				var p = Math.min(1, Math.max(0, -r.top / (r.height - vh)));
				var idx = Math.min(wl.length - 1, Math.floor(p * wl.length));
				if (r.top > vh || r.bottom < 0) idx = -1;
				if (idx !== cur) { cur = idx; wl.forEach(function (s, i) { s.classList.toggle('is-on', i === idx); s.classList.toggle('is-past', i < idx); }); wd.forEach(function (d, i) { d.classList.toggle('is-on', i === idx); }); var pi = idx < 0 ? 0 : idx; wp.forEach(function (im, i) { im.classList.toggle('is-on', i === pi); }); }
				wbar.style.transform = 'scaleX(' + p + ')';
			}
			px.forEach(function (im) { var b = im.getBoundingClientRect(); if (b.bottom < 0 || b.top > vh) return; var t = (b.top + b.height / 2 - vh / 2) / vh; im.style.transform = 'scale(1.1) translateY(' + (t * -6) + '%)'; });
		};
		window.addEventListener('scroll', function () { window.requestAnimationFrame(tick); }, { passive: true }); window.addEventListener('resize', tick); tick();
	}
})();