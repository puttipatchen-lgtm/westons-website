/* Westons theme.js — animation และ carousel แบบเบา ไม่พึ่ง library */
(function () {
	var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	/* 1) fade-in เมื่อเลื่อนถึง: ลูกโดยตรงของทุก section */
	var targets = [];
	document.querySelectorAll('.wt-section').forEach(function (s) {
		Array.prototype.forEach.call(s.children, function (c) { c.classList.add('wt-reveal'); targets.push(c); });
	});
	if (reduce || !('IntersectionObserver' in window)) { targets.forEach(function (t) { t.classList.add('is-in'); }); }
	else {
		var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); } }); }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
		targets.forEach(function (t) { io.observe(t); });
		setTimeout(function () { targets.forEach(function (t) { if (t.getBoundingClientRect().top < window.innerHeight) t.classList.add('is-in'); }); }, 60);
	}

	/* 2) รูปขยายเมื่อชี้ */
	document.querySelectorAll('.wt-card .wp-block-image, .wt-product-card, .wt-slide .wp-block-image, .wt-mega-img, .wt-split .wp-block-image, .wt-hero-img').forEach(function (el) { el.classList.add('wt-zoom'); });

	/* 3) หัวเว็บย่อเมื่อเลื่อน */
	var mega = document.querySelector('.wt-mega');
	if (mega) {
		var onScroll = function () { mega.classList.toggle('is-shrunk', window.scrollY > 90); };
		window.addEventListener('scroll', onScroll, { passive: true }); onScroll();
	}

	/* 4) carousel: Group.wt-carousel > .wt-slide */
	document.querySelectorAll('.wt-carousel').forEach(function (c) {
		var slides = Array.prototype.filter.call(c.children, function (x) { return x.classList.contains('wt-slide'); });
		if (slides.length < 2) { c.classList.add('is-single'); }
		var track = document.createElement('div'); track.className = 'wt-carousel-track';
		slides.forEach(function (s) { track.appendChild(s); });
		c.appendChild(track);
		var single = c.classList.contains('is-single') || c.closest('.wt-split');
		if (single) { c.classList.add('is-single'); }
		var dots = document.createElement('div'); dots.className = 'wt-carousel-dots';
		var perView = function () { return single ? 1 : (window.innerWidth < 600 ? 1 : window.innerWidth < 1024 ? 2 : 3); };
		var pages = function () { return Math.max(1, Math.ceil(slides.length / perView())); };
		var goTo = function (i) { var w = track.scrollWidth / slides.length; track.scrollTo({ left: i * perView() * w, behavior: reduce ? 'auto' : 'smooth' }); };
		var build = function () {
			dots.innerHTML = '';
			for (var i = 0; i < pages(); i++) { var b = document.createElement('button'); b.type = 'button'; b.setAttribute('aria-label', 'slide ' + (i + 1)); (function (i) { b.addEventListener('click', function () { goTo(i); }); })(i); dots.appendChild(b); }
			update();
		};
		var update = function () {
			var w = track.scrollWidth / slides.length; var idx = Math.round(track.scrollLeft / (w * perView()));
			Array.prototype.forEach.call(dots.children, function (d, i) { d.classList.toggle('is-active', i === idx); });
		};
		c.appendChild(dots); build();
		track.addEventListener('scroll', update, { passive: true }); window.addEventListener('resize', build);
		if (!single) {
			['prev', 'next'].forEach(function (dir) {
				var a = document.createElement('button'); a.type = 'button'; a.className = 'wt-carousel-arrow is-' + dir; a.setAttribute('aria-label', dir);
				a.innerHTML = dir === 'prev' ? '&#8249;' : '&#8250;';
				a.addEventListener('click', function () { var w = track.scrollWidth / slides.length; track.scrollBy({ left: (dir === 'next' ? 1 : -1) * w * perView(), behavior: 'smooth' }); });
				c.appendChild(a);
			});
		}
		/* autoplay เหมือน HD (3–5 วิ) หยุดเมื่อชี้/แตะ */
		if (!reduce && slides.length > 1) {
			var timer, delay = single ? 5000 : 3500;
			var step = function () { var w = track.scrollWidth / slides.length; var max = track.scrollWidth - track.clientWidth; var next = track.scrollLeft + w * perView(); track.scrollTo({ left: next > max + 4 ? 0 : next, behavior: 'smooth' }); };
			var start = function () { stop(); timer = setInterval(step, delay); }; var stop = function () { if (timer) clearInterval(timer); };
			c.addEventListener('mouseenter', stop); c.addEventListener('mouseleave', start); c.addEventListener('touchstart', stop, { passive: true });
			document.addEventListener('visibilitychange', function () { document.hidden ? stop() : start(); });
			start();
		}
	});
})();
