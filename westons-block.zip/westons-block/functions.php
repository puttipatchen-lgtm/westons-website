<?php
/**
 * Westons Block theme.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'after_setup_theme', function () {
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/theme.css' );
	load_theme_textdomain( 'westons-block', get_template_directory() . '/languages' );
} );

/** Google Fonts (ไทย) + theme CSS. */
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'westons-fonts', 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Thai:wght@300;400;500;600&family=Noto+Serif+Thai:wght@400;500;600&display=swap', array(), null );
	wp_enqueue_style( 'westons-theme', get_template_directory_uri() . '/assets/theme.css', array(), wp_get_theme()->get( 'Version' ) );
} );
add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'westons-fonts-editor', 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Thai:wght@300;400;500;600&family=Noto+Serif+Thai:wght@400;500;600&display=swap', array(), null );
} );

/** lang="th" ตามแผน. */
add_filter( 'language_attributes', function ( $output ) {
	return preg_replace( '/lang="[^"]*"/', 'lang="th"', $output ) ?: 'lang="th"';
} );

/** Pattern categories. */
add_action( 'init', function () {
	register_block_pattern_category( 'westons', array( 'label' => __( 'Westons', 'westons-block' ) ) );
} );

/** อนุญาตให้ SVG icon เล็กใน HTML block. */
add_filter( 'wp_kses_allowed_html', function ( $tags, $context ) {
	if ( 'post' === $context ) {
		$tags['svg']  = array( 'width' => true, 'height' => true, 'viewbox' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true, 'stroke-linejoin' => true, 'aria-hidden' => true, 'class' => true );
		$tags['path'] = array( 'd' => true );
		$tags['rect'] = array( 'x' => true, 'y' => true, 'width' => true, 'height' => true, 'rx' => true );
		$tags['circle'] = array( 'cx' => true, 'cy' => true, 'r' => true );
	}
	return $tags;
}, 10, 2 );
